# VOLTIX validation matrix results

Machine: Linux-6.18.44-fc-v153-x86_64-with-glibc2.39, Python 3.13.16, torch 2.14.1+cu130, no GPU

Rows: 11 defined, 7 executed (6 PASS, 1 FAIL), 4 NOT RUN.

A PASS means only: every repeat completed, the repeats were judged comparable, and throughput of two identical repeats agreed within 15%. It is not a performance claim. `tiny` is a random-weight pipeline-check model; its speed says nothing about real models.

| Row | Configuration | Result | Throughput tok/s (repeats) | Detail |
|---|---|---|---|---|
| cpu-tiny-fp32-b1-p32 | tiny fp32 b1 p32/o16 | **PASS** | 651.5, 691.0 | 2 repeats completed; throughput spread 5.9% |
| cpu-tiny-fp32-b1-p128 | tiny fp32 b1 p128/o16 | **PASS** | 711.8, 695.1 | 2 repeats completed; throughput spread 2.4% |
| cpu-tiny-fp32-b2-p32 | tiny fp32 b2 p32/o16 | **PASS** | 1,323.9, 1,266.5 | 2 repeats completed; throughput spread 4.4% |
| cpu-tiny-fp32-b2-p128 | tiny fp32 b2 p128/o16 | **FAIL** | 1,418.2, 1,163.0 | repeat throughput differs by 19.8% (limit 15%) |
| cpu-tiny-fp32-b4-p32 | tiny fp32 b4 p32/o16 | **PASS** | 2,225.9, 2,304.3 | 2 repeats completed; throughput spread 3.5% |
| cpu-tiny-fp32-b4-p128 | tiny fp32 b4 p128/o16 | **PASS** | 1,844.7, 1,899.7 | 2 repeats completed; throughput spread 2.9% |
| cpu-tiny-bf16-b1-p32 | tiny bf16 b1 p32/o16 | **PASS** | 525.2, 508.5 | 2 repeats completed; throughput spread 3.2% |
| gpu-qwen05b-fp16-b1 | Qwen/Qwen2.5-0.5B fp16 b1 p128/o64 | **NOT RUN** | – | no CUDA GPU on this machine |
| gpu-qwen05b-fp16-b8 | Qwen/Qwen2.5-0.5B fp16 b8 p128/o64 | **NOT RUN** | – | no CUDA GPU on this machine |
| gpu-qwen05b-bf16-b1 | Qwen/Qwen2.5-0.5B bf16 b1 p128/o64 | **NOT RUN** | – | no CUDA GPU on this machine |
| cpu-qwen05b-fp32-b1 | Qwen/Qwen2.5-0.5B fp32 b1 p64/o16 | **NOT RUN** | – | model Qwen/Qwen2.5-0.5B is not in the local cache and downloads are not used by the matrix |

## Evidence behind the iteration count (same machine, tiny CPU model, 6 identical runs per setting)
| Iterations per run | Throughput max-min spread | Run-to-run CV |
|---|---|---|
| 20 | 26.3 % | 10.6 % |
| 60 | 16.5 % | 7.7 % |
| 120 | 11.0 % | 4.9 % |

The first matrix pass used 20 iterations per row and **4 of 7 executed rows FAILED** the 15 % repeat-agreement check (spreads 15.0–22.6 %). The matrix was changed to 100 iterations because the table above shows noise falling with iteration count — not by loosening the 15 % threshold. At 100 iterations, 6 of 7 pass and 1 still fails (19.8 %): short CPU benchmarks on a shared machine are noisy, and one repeat is not enough to trust a difference below roughly 10–20 %. This says nothing about GPUs, which have not been measured here.

Real-model and GPU rows are NOT RUN here (no GPU, no cached model). The only real-GPU data point is the single Colab T4 session you ran (Qwen2.5-0.5B fp16, b1: 34.4 and 34.1 tok/s across two repeats, i.e. 0.9 % apart); those files are not in this sandbox, so it is user-reported, not re-verified here.
