# Phase 5: your first real GPU benchmark

**Status of this path:** the GPU code (CUDA timing, `max_memory_allocated`, precision rules) is written and tested only against a *fake* GPU and on CPU. **It has never run on a real GPU.** Your first run is the first real test. If something fails, copy the exact message; do not work around it by switching to simulated data.

## What the existing code already does

- Real inference with Hugging Face Transformers (`AutoModelForCausalLM`), on CPU or CUDA, in fp32 / fp16 / bf16.
- Downloads a model from the Hub **only if** you allow it. No login token is supported, so **gated or private models will not work**. `trust_remote_code` is off.
- Measures per-iteration latency (CUDA-synchronised), time to first token, throughput, and GPU memory (`torch.cuda.max_memory_allocated`: the peak of tensors held by PyTorch since just before loading; it excludes the CUDA context and cached memory, so `nvidia-smi` will show more).
- The prompt is random token ids, so no tokenizer is needed and any causal language model works. This measures speed, not text quality.
- Records the GPU name, memory, compute capability, the torch / CUDA-build / transformers versions and the exact settings with every run (the NVIDIA driver version is not recorded).
- Anything it cannot measure is shown as n/a with the reason (for example p99 needs 100+ iterations).

Added in this phase: `run_real_benchmark.py` (headless runner), an **Import** panel on Benchmark History, and `VOLTIX_GPU_benchmark.ipynb` (a ready Colab notebook).

## Requirements

| Item | Needed |
|---|---|
| GPU | Any NVIDIA GPU with a working driver. For the model below, about 2 GB of GPU memory is enough (fp16 weights ≈ 1 GB; fp32 ≈ 2 GB). |
| Precision | fp16 works on all NVIDIA GPUs. **bf16 needs an Ampere (compute capability 8.x) or newer GPU**; VOLTIX refuses bf16 on older GPUs such as the T4. |
| Python | 3.10 or newer |
| Libraries | `torch>=2.6` (a CUDA build), `transformers>=4.50`, `numpy`. The web app additionally needs streamlit, plotly and pandas, but the GPU runner does not. |
| Internet | Only for the first download of the model (about 1 GB). |

AMD GPUs and Apple GPUs are not supported by this build.

## The model for the first test: `Qwen/Qwen2.5-0.5B`

- About 0.5 billion parameters; `model.safetensors` is 988 MB (checked on its Hugging Face page on 2026-10-24).
- Public (no access request), license shown as Apache-2.0, safetensors format (no pickle risk).
- Small enough for any GPU, but large enough to be a real transformer rather than a toy.
- I have **not** run it myself (no GPU or Hub access in my environment). It is a standard causal language model, which the backend is designed to load, so this is expected to work, but it is untested.

## Cheapest practical setups

1. **Google Colab, free tier (recommended first try).** Free, no installation. Colab does not guarantee a particular GPU or that one is available: pick GPU in the runtime settings and check what you were given (the notebook prints it). Free sessions have time limits and can disconnect. Notebook GPUs are shared infrastructure, so expect run-to-run variation; that is why the notebook repeats the first run.
2. **Another free notebook service** (for example Kaggle) can work the same way with the same commands; I have not checked their current limits or tested VOLTIX there.
3. **Rent a GPU machine by the hour** if free notebooks are unavailable. Prices change often and I have not looked them up; check the provider's current price before starting, and shut the machine down afterwards.
4. **Your own NVIDIA GPU:** install a CUDA build of PyTorch from https://pytorch.org/get-started/locally/, then `python -m pip install "transformers>=4.50"`, and either use the app's Run Benchmark page (choose Transformers, device `cuda`) or the command below.

## Step by step (Colab)

1. Go to https://colab.research.google.com, sign in, **File > Upload notebook**, choose `VOLTIX_GPU_benchmark.ipynb` from the project folder.
2. **Runtime > Change runtime type**, choose a GPU, **Save**.
3. Run the cells in order (click the play button on each).
   - Cell 1 prints the GPU. If it stops with "No GPU", fix the runtime type and restart the session.
   - Cell 2 asks for `voltix-runtime.zip` (the project zip). Upload it.
   - Cell 3 checks library versions.
   - Cells 4 and 5 run the benchmarks: Qwen2.5-0.5B in fp16 (twice, to measure noise), then fp32, then fp16 with batch 8. Each run changes **one** setting from the first, so the Optimize page can compare them fairly.
   - Cell 6 verifies the results (re-reads every file, recomputes the metrics from the raw samples, and checks each ran on a CUDA GPU).
   - Cell 7 downloads `voltix_gpu_results.zip`.
4. On your computer, unzip it. Start VOLTIX (see `SETUP.md`), open **Benchmark History**, expand **Import runs from JSON files**, select all the `.json` files, click **Import**.
5. Open **Optimize** and choose the first fp16 batch-1 run as the baseline. You should see the repeat as a noise floor and the fp32 and batch-8 runs as comparisons.

## The same thing from any terminal with a GPU

```
python check_setup.py --core
python run_real_benchmark.py --model Qwen/Qwen2.5-0.5B --allow-download --device cuda --precision fp16 --batch-size 1 --prompt-tokens 128 --output-tokens 128 --iterations 30 --repeats 2
```
Files go to `voltix_results/`. Add `--save-db data/voltix.db` to save straight into the app's database when the app runs on the same machine.

## How to tell that it worked

- The runner prints `device : <your GPU name> (cuda)` and then throughput, time to first token, latency and GPU memory, and ends with `Done: N of N run(s) completed`.
- If the run lands on the CPU, the runner stops and saves nothing ("this ran on 'cpu', not a GPU"). It will never save a CPU run as a GPU benchmark.
- In the app, imported runs show **MEASURED**, the GPU name, and "Peak GPU memory" (a CPU run says "Peak process RAM").
- If a number is unavailable it says `n/a (reason)`; it is never filled in from the simulation.

## Reading the results honestly

- 30 iterations give a usable mean but no p99 (needs 100+). Use `--iterations 100` or more if you want p99.
- Differences smaller than the repeat-to-repeat difference are reported as noise, not as improvements.
- Results describe this GPU, this driver stack and this moment. A shared notebook GPU may behave differently tomorrow.
- Import validation catches damaged or edited files, but cannot prove a file came from a real GPU. Only import files you produced.

## If something fails

| Message | Meaning |
|---|---|
| `No GPU` / `CUDA requested but not available` | The runtime has no GPU, or the torch build is CPU-only. |
| `bf16 needs a GPU with compute capability 8.0 or newer` | The GPU is older than Ampere (for example a T4). Use fp16. |
| `Out of GPU memory ...` | Lower the batch size or sequence length, or use a smaller model. |
| `not in the local Hugging Face cache and downloading is turned off` | Add `--allow-download`. |
| `can't open file '/content/run_real_benchmark.py'` | The notebook is in the wrong folder (the session restarted or the zip was not unpacked). Run `%cd /content/voltix-runtime`; if that fails, re-run cell 2 and upload the zip again (a restart of a free session can delete uploaded files). |
| Download errors | No internet or the Hub is unreachable from that machine. |
| `The stored metric ... does not match` on import | The file was edited or damaged. Re-export it. |
