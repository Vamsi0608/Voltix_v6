"""Check that this computer is ready to run VOLTIX Runtime.

Run it from the VOLTIX folder with the same Python you use for the app:

    python check_setup.py          (add --core on a headless GPU machine/notebook that only runs run_real_benchmark.py)

It changes nothing except creating (then removing) a small test file next to the database.
Exit code 0 means every REQUIRED check passed; optional checks only add information.
"""

from __future__ import annotations

import importlib.metadata as md
import os
import socket
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OK, WARN, FAIL = "[ ok ]", "[warn]", "[FAIL]"


def version(pkg: str) -> str | None:
    try:
        return md.version(pkg)
    except md.PackageNotFoundError:
        return None


def check_python() -> tuple[str, str]:
    v = sys.version_info
    if v < (3, 10):
        return FAIL, f"Python {v.major}.{v.minor} is too old; VOLTIX needs 3.10 or newer (3.11 or 3.12 recommended)."
    return OK, f"Python {v.major}.{v.minor}.{v.micro}"


def check_venv() -> tuple[str, str]:
    in_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
    if in_venv:
        return OK, "running inside a virtual environment"
    return WARN, "not inside a virtual environment. Activate .venv first (Windows: .venv\\Scripts\\activate, Mac/Linux: source .venv/bin/activate)."


def check_required(core_only: bool = False) -> list[tuple[str, str]]:
    out = []
    for pkg in (("numpy",) if core_only else ("streamlit", "plotly", "pandas", "numpy")):
        v = version(pkg)
        out.append((OK, f"{pkg} {v}") if v else (FAIL, f"{pkg} is not installed. Run: pip install -r requirements.txt"))
    return out


def check_optional() -> list[tuple[str, str]]:
    tv, fv = version("torch"), version("transformers")
    if tv and fv:
        msg = f"torch {tv}, transformers {fv}: real Hugging Face inference is available"
        try:
            import torch  # noqa: PLC0415

            msg += "; CUDA GPU " + ("detected" if torch.cuda.is_available() else "not detected (runs will use the CPU)")
        except Exception as exc:  # noqa: BLE001
            return [(WARN, f"torch is installed but fails to import: {type(exc).__name__}: {exc}")]
        return [(OK, msg)]
    missing = [n for n, v in (("torch", tv), ("transformers", fv)) if not v]
    return [(WARN, f"{', '.join(missing)} not installed: only the simulated demo mode will work. "
                   "For real inference run: pip install -r requirements-hf.txt")]


def check_database() -> tuple[str, str]:
    path = Path(os.environ.get("VOLTIX_DB_PATH") or ROOT / "data" / "voltix.db")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        probe = path.parent / ".voltix_write_test"
        probe.write_text("ok")
        probe.unlink()
    except OSError as exc:
        return FAIL, f"cannot write next to the database ({path.parent}): {exc}. Set VOLTIX_DB_PATH to a writable file."
    return OK, f"database location is writable: {path}"


def check_port(port: int = 8501) -> tuple[str, str]:
    with socket.socket() as s:
        s.settimeout(0.5)
        busy = s.connect_ex(("127.0.0.1", port)) == 0
    if busy:
        return WARN, f"port {port} is already in use (maybe VOLTIX is already running). Use: streamlit run app.py --server.port 8502"
    return OK, f"port {port} is free"


def check_gpu() -> tuple[str, str]:
    try:
        import torch  # noqa: PLC0415

        if torch.cuda.is_available():
            p = torch.cuda.get_device_properties(0)
            return OK, f"GPU: {p.name}, {p.total_memory / 1e9:.1f} GB, compute capability {p.major}.{p.minor}"
        return WARN, "no CUDA GPU visible to PyTorch (on Colab: Runtime > Change runtime type > GPU, then restart)"
    except Exception:  # noqa: BLE001
        return WARN, "GPU not checked (torch is not usable)"


def main(argv: list[str] | None = None) -> int:
    core = "--core" in (argv if argv is not None else sys.argv[1:])
    if core:  # for a headless GPU runner (e.g. a notebook): the web app's packages are not needed
        rows = [check_python(), *check_required(core_only=True), *check_optional(), check_gpu(), check_database()]
    else:
        rows = [check_python(), check_venv(), *check_required(), *check_optional(), check_database(), check_port()]
    for status, msg in rows:
        print(f"{status} {msg}")
    failed = [m for s, m in rows if s == FAIL]
    print()
    if failed:
        print(f"{len(failed)} required check(s) failed. Fix them, then run this again.")
        return 1
    print("Ready." + ("" if core else " Start the app with:  python -m streamlit run app.py"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
