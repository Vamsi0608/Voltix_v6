"""Host memory helpers across platforms. The Windows ctypes calls cannot run here; only struct layout and
fallback logic are tested, so Windows/macOS memory figures remain unverified until run on those systems."""

import ctypes

from voltix import hostmem


def test_windows_struct_layouts_match_the_win32_documentation():
    status, counters = hostmem._win_structs()
    assert ctypes.sizeof(status) == 64      # MEMORYSTATUSEX
    assert ctypes.sizeof(counters) == 72    # PROCESS_MEMORY_COUNTERS (64-bit)


def test_windows_failures_return_none_not_a_guess(monkeypatch):
    monkeypatch.setattr(hostmem, "_is_windows", lambda: True)
    monkeypatch.setattr(hostmem, "_win_memory_status", lambda: None)
    monkeypatch.setattr(hostmem, "_win_process_counters", lambda: None)
    assert hostmem.total_ram_gb() is None and hostmem.available_ram_gb() is None
    assert hostmem.current_rss_gb() is None and hostmem.peak_rss_gb() is None


def test_windows_values_are_converted_to_gb(monkeypatch):
    class S:  # stand-ins for the ctypes structures
        ullTotalPhys, ullAvailPhys = 16_000_000_000, 8_000_000_000
        WorkingSetSize, PeakWorkingSetSize = 2_000_000_000, 3_000_000_000
    monkeypatch.setattr(hostmem, "_is_windows", lambda: True)
    monkeypatch.setattr(hostmem, "_win_memory_status", lambda: S())
    monkeypatch.setattr(hostmem, "_win_process_counters", lambda: S())
    assert (hostmem.total_ram_gb(), hostmem.available_ram_gb()) == (16.0, 8.0)
    assert (hostmem.current_rss_gb(), hostmem.peak_rss_gb()) == (2.0, 3.0)


def test_macos_total_ram_falls_back_to_sysctl(monkeypatch):
    monkeypatch.setattr(hostmem.sys, "platform", "darwin")
    monkeypatch.setattr(hostmem, "_is_windows", lambda: False)
    monkeypatch.setattr(hostmem.os, "sysconf", lambda name: (_ for _ in ()).throw(ValueError()))
    monkeypatch.setattr(hostmem, "_run", lambda *cmd: "17179869184")
    assert abs(hostmem.total_ram_gb() - 17.179869184) < 1e-9


def test_linux_values_are_plausible_here():
    assert hostmem.total_ram_gb() and hostmem.available_ram_gb() and hostmem.current_rss_gb()
    assert hostmem.available_ram_gb() <= hostmem.total_ram_gb()


def test_oversized_local_model_is_refused_before_loading(tmp_path):
    from voltix.backends.transformers_backend import weights_exceed_memory

    (tmp_path / "model.safetensors").write_bytes(b"")
    with open(tmp_path / "model.safetensors", "r+b") as f:
        f.truncate(5_000_000_000)  # sparse: no real disk use
    msg = weights_exceed_memory(str(tmp_path), available_gb=2.0)
    assert msg and "5.0 GB" in msg and "2.0 GB" in msg
    assert weights_exceed_memory(str(tmp_path), available_gb=16.0) is None
    assert weights_exceed_memory(str(tmp_path), available_gb=None) is None      # unknown RAM: no guess
    assert weights_exceed_memory("org/hub-model", available_gb=1.0) is None      # Hub ids are not checked
