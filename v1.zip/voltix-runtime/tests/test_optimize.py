import json
import re

import pytest

from tests.phase3_helpers import make_samples, measured_run
from voltix.exports import study_to_csv, study_to_json, study_to_markdown
from voltix.optimize import (
    ConfidenceLevel,
    analyze_pair,
    build_study,
    cost_per_million_tokens,
    price_keys,
    replicate_noise,
    suggest_baseline,
)
from voltix.runner import run_benchmark
from voltix.schemas import Precision


def levels(pa):
    return {m.key: m.verdict for m in pa.metrics.values()}


# ---- a pair of runs -------------------------------------------------------------------------------

def test_clear_improvement_is_reported_with_interval_and_direction():
    base, cand = measured_run("fp32", 100, seed=1), measured_run("bf16", 80, seed=2, precision=Precision.BF16)
    pa = analyze_pair(base, cand)
    thr = pa.metrics["throughput_tokens_per_s"]
    assert pa.classification == "win" and thr.verdict == "improved" and thr.has_ci
    assert 20 < thr.ci_low_pct < thr.change_pct < thr.ci_high_pct < 30   # nominal truth: 100ms -> 80ms is +25% throughput
    assert pa.metrics["latency_p95_ms"].verdict == "improved" and not pa.regressions
    assert pa.comparability.factors_changed == ["precision fp32 → bf16"]


def test_the_95_percent_interval_covers_the_true_effect_about_95_percent_of_the_time():
    """Calibration through the full engine: nominal truth is +25% throughput (100 ms -> 80 ms)."""
    trials, covered = 120, 0
    for t in range(trials):
        a = measured_run("a", 100, seed=10_000 + t)
        b = measured_run("b", 80, seed=20_000 + t, precision=Precision.BF16)
        m = analyze_pair(a, b, resamples=500).metrics["throughput_tokens_per_s"]
        covered += m.ci_low_pct <= 25.0 <= m.ci_high_pct
    assert covered / trials >= 0.88, f"interval covered the truth in only {covered}/{trials} trials"


def test_a_tradeoff_lists_both_sides():
    pa = analyze_pair(measured_run("b1", 100, seed=1), measured_run("b8", 250, seed=2, batch=8))
    assert pa.classification == "trade_off"
    assert "throughput_tokens_per_s" in pa.improvements and "latency_p95_ms" in pa.regressions
    assert pa.metrics["throughput_tokens_per_s"].change_pct == pytest.approx(220, abs=15)  # 8*16/0.25 vs 16/0.1


def test_a_regression_is_reported():
    pa = analyze_pair(measured_run("a", 100, seed=1), measured_run("b", 130, seed=2, precision=Precision.BF16))
    assert pa.classification == "regression" and "throughput_tokens_per_s" in pa.regressions


def test_no_real_change_is_not_called_an_effect():
    pa = analyze_pair(measured_run("a", 100, seed=1, precision=Precision.FP32),
                      measured_run("b", 100, seed=2, precision=Precision.BF16))
    assert pa.classification == "no_detectable_difference" and not pa.improvements and not pa.regressions


def test_replicate_pair_never_claims_an_effect_even_if_runs_differ():
    pa = analyze_pair(measured_run("a", 100, seed=1), measured_run("b", 125, seed=2))
    assert pa.classification == "replicate"
    assert all(v not in ("improved", "regressed") for v in levels(pa).values())
    assert "noise" in pa.headline.lower()


def test_noise_between_replicates_demotes_effects_that_are_not_bigger():
    a1, a2 = measured_run("a1", 100, seed=1), measured_run("a2", 112, seed=2)   # same setup differs by ~12%
    cand = measured_run("c", 94, seed=3, precision=Precision.BF16)               # ~ -6% latency vs a1
    noise = replicate_noise([a1, a2, cand], like=a1)
    assert noise.pairs == 1 and noise.by_metric["throughput_tokens_per_s"] > 5
    without = analyze_pair(a1, cand)
    with_noise = analyze_pair(a1, cand, noise=noise)
    assert without.metrics["throughput_tokens_per_s"].verdict == "improved"
    thr = with_noise.metrics["throughput_tokens_per_s"]
    assert thr.verdict == "no_detectable_change" and "replicate runs" in thr.note


def test_confidence_rises_only_with_replication_and_good_hygiene():
    a1, a2, cand = (measured_run("a1", 100, seed=1), measured_run("a2", 101, seed=2),
                    measured_run("c", 70, seed=3, precision=Precision.BF16))
    alone = analyze_pair(a1, cand)
    assert alone.confidence.level == ConfidenceLevel.MEDIUM
    assert any(c.name == "Replication" and c.status == "warn" for c in alone.confidence.checks)
    replicated = analyze_pair(a1, cand, noise=replicate_noise([a1, a2, cand], like=a1))
    assert replicated.confidence.level == ConfidenceLevel.HIGH
    assert all(c.status in ("pass", "info") for c in replicated.confidence.checks)


@pytest.mark.parametrize("cand_kwargs,check,level", [
    (dict(warmup=0), "Warm-up", ConfidenceLevel.LOW),
    (dict(torch_version="2.5.0"), "Environment", ConfidenceLevel.LOW),
    (dict(n=12), "Sample size", ConfidenceLevel.LOW),
    (dict(sigma=0.4), "Noise (candidate)", ConfidenceLevel.LOW),
])
def test_each_hygiene_problem_lowers_confidence_and_names_itself(cand_kwargs, check, level):
    base = measured_run("a", 100, seed=1)
    cand = measured_run("b", 70, seed=2, precision=Precision.BF16, **cand_kwargs)
    pa = analyze_pair(base, cand, noise=replicate_noise([base, measured_run("a2", 100, seed=9), cand], like=base))
    assert pa.confidence.level == level
    assert any(c.name == check and c.status == "fail" for c in pa.confidence.checks)


def test_drifting_run_is_flagged_as_not_independent():
    base = measured_run("a", 100, seed=1, drift=1.0, sigma=0.01)
    pa = analyze_pair(base, measured_run("b", 70, seed=2, precision=Precision.BF16))
    assert any(c.name.startswith("Independence") and c.status == "warn" for c in pa.confidence.checks)


def test_too_few_iterations_means_no_verdict_and_insufficient_confidence():
    pa = analyze_pair(measured_run("a", 100, n=4, seed=1), measured_run("b", 60, n=4, seed=2, precision=Precision.BF16))
    assert pa.classification == "insufficient_data" and pa.confidence.level == ConfidenceLevel.INSUFFICIENT
    assert all(m.verdict == "not_assessed" for m in pa.metrics.values() if m.key != "peak_memory_gb")


def test_tail_metrics_need_enough_samples():
    pa = analyze_pair(measured_run("a", 100, n=12, seed=1), measured_run("b", 60, n=12, seed=2, precision=Precision.BF16))
    assert pa.metrics["latency_p95_ms"].verdict == "not_assessed" and "at least 20" in pa.metrics["latency_p95_ms"].note
    assert pa.metrics["latency_p99_ms"].verdict == "not_assessed"
    assert pa.metrics["throughput_tokens_per_s"].verdict == "improved"


def test_unlike_runs_get_no_metrics_at_all():
    pa = analyze_pair(measured_run("a", 100), measured_run("b", 100, prompt=64))
    assert pa.classification == "not_comparable" and pa.metrics == {} and pa.confidence.level == ConfidenceLevel.INSUFFICIENT


def test_analysis_is_deterministic():
    a, b = measured_run("a", 100, seed=1), measured_run("b", 90, seed=2, batch=2)
    x, y = analyze_pair(a, b).to_dict(), analyze_pair(a, b).to_dict()
    assert x == y


# ---- memory ---------------------------------------------------------------------------------------

def test_cpu_process_memory_is_never_used_for_a_verdict():
    pa = analyze_pair(measured_run("a", 100, peak_gb=2.0, seed=1), measured_run("b", 90, peak_gb=1.0, seed=2, batch=2))
    mem = pa.metrics["peak_memory_gb"]
    assert mem.verdict == "not_assessed" and "whole Python process" in mem.note and "peak_memory_gb" not in pa.regressions + pa.improvements


def test_gpu_memory_is_a_single_measurement_with_no_interval():
    a = measured_run("a", 100, seed=1, device="GPU X", kind="cuda", peak_gb=10.0)
    b = measured_run("b", 90, seed=2, device="GPU X", kind="cuda", peak_gb=5.0, precision=Precision.FP16)
    mem = analyze_pair(a, b).metrics["peak_memory_gb"]
    assert mem.verdict == "improved" and mem.change_pct == pytest.approx(-50) and not mem.has_ci
    assert "single measurement" in mem.note


# ---- cost: only from the user's prices ------------------------------------------------------------

def test_cost_formula():
    assert cost_per_million_tokens(160, 1.0) == pytest.approx(1.0 / (160 * 3600) * 1e6)
    with pytest.raises(ValueError):
        cost_per_million_tokens(0, 1.0)


def test_cost_appears_only_when_prices_are_given_for_both_devices():
    a = measured_run("cpu", 100, seed=1)
    b = measured_run("gpu", 25, seed=2, device="GPU X", kind="cuda")
    assert "cost_per_million_tokens" not in analyze_pair(a, b).metrics
    assert "cost_per_million_tokens" not in analyze_pair(a, b, prices={"Test CPU": 1.0}).metrics
    cost = analyze_pair(a, b, prices={"Test CPU": 1.0, "GPU X": 2.0}).metrics["cost_per_million_tokens"]
    # throughput x4 at double the price -> half the cost
    assert cost.change_pct == pytest.approx(-50, abs=6) and cost.verdict == "improved" and cost.has_ci
    assert cost.baseline == pytest.approx(cost_per_million_tokens(a.metrics.throughput_tokens_per_s, 1.0))
    assert "your hourly prices" in cost.note


def test_cost_can_get_worse_when_the_faster_device_is_priced_higher():
    a, b = measured_run("cpu", 100, seed=1), measured_run("gpu", 80, seed=2, device="GPU X", kind="cuda")
    cost = analyze_pair(a, b, prices={"Test CPU": 1.0, "GPU X": 5.0}).metrics["cost_per_million_tokens"]
    assert cost.verdict == "regressed" and cost.change_pct > 100


def test_simulated_runs_are_never_priced(cfg):
    a, b = run_benchmark(cfg(batch_size=1), "a"), run_benchmark(cfg(batch_size=4), "b")
    prices = {k: 1.0 for k in ("simulated NVIDIA A10G 24GB", "NVIDIA A10G 24GB")}
    assert "cost_per_million_tokens" not in analyze_pair(a, b, prices=prices).metrics
    assert build_study(a, [a, b], prices=prices).cost_enabled is False


# ---- simulated data is not evidence ----------------------------------------------------------------

def test_simulated_comparisons_are_labelled_not_evidence(cfg):
    a, b = run_benchmark(cfg(batch_size=1), "a"), run_benchmark(cfg(batch_size=16), "b")
    pa = analyze_pair(a, b)
    assert pa.confidence.level == ConfidenceLevel.SIMULATED and "not evidence" in pa.confidence.summary
    study = build_study(a, [a, b])
    assert study.notes[0].startswith("SIMULATED DATA") and all(f.confidence == ConfidenceLevel.SIMULATED for f in study.findings)
    assert all(f.basis == "simulated" for f in study.findings)


# ---- a whole study -------------------------------------------------------------------------------------

@pytest.fixture
def runs():
    return [
        measured_run("b1-fp32 #1", 100, seed=1), measured_run("b1-fp32 #2", 102, seed=2),
        measured_run("b1-bf16", 70, seed=3, precision=Precision.BF16),
        measured_run("b8-fp32", 260, seed=4, batch=8),
        measured_run("b8-bf16 (two changes)", 150, seed=5, batch=8, precision=Precision.BF16),
        measured_run("other prompt", 90, seed=6, prompt=128),
    ]


def test_study_groups_runs_and_explains_exclusions(runs):
    study = build_study(runs[0], runs)
    assert study.data_source == "measured" and len(study.analyses) == 4
    assert [n for n, _ in study.excluded] == ["other prompt"] and "prompt or output lengths" in study.excluded[0][1]
    by = {a.candidate_name: a for a in study.analyses}
    assert by["b1-fp32 #2"].classification == "replicate"
    assert by["b1-bf16"].classification == "win" and by["b8-fp32"].classification == "trade_off"
    assert by["b8-bf16 (two changes)"].comparability.level.value == "multi_factor"
    assert study.noise is not None and study.noise.pairs == 1


def test_study_frontier_and_dominance_are_consistent(runs):
    study = build_study(runs[0], runs)
    ids = {r.name: r.run_id for r in runs}
    assert ids["b1-fp32 #1"] in {d.dominated_id for d in study.dominated}     # bf16 beats it on everything assessed
    assert ids["b1-bf16"] in study.frontier and ids["b1-fp32 #1"] not in study.frontier
    assert set(study.frontier) <= set(study.run_ids)
    assert not any(d.dominated_id == d.by_id for d in study.dominated)


def test_multi_factor_pairs_are_reported_but_never_credited_to_one_setting(runs):
    study = build_study(runs[0], runs)
    mf = next(a for a in study.analyses if a.comparability.level.value == "multi_factor")
    assert mf.confidence.level == ConfidenceLevel.LOW
    assert any(c.name == "Attribution" and c.status == "fail" for c in mf.confidence.checks)


def test_untested_settings_get_experiments_with_no_numbers_attached(runs):
    study = build_study(runs[0], runs)
    kinds = {e.factor for e in study.next_experiments}
    assert {"batch size", "hardware"} <= kinds
    assert "bf16" not in " ".join(e.suggestion for e in study.next_experiments if e.factor == "precision")  # already tried
    for e in study.next_experiments:
        assert not re.search(r"\d+(\.\d+)?\s*%|x faster|saves?\b", e.suggestion + " " + e.reason)
    assert study.coverage.batch_sizes == [1, 8] and study.coverage.precisions == ["bf16", "fp32"]


FORBIDDEN = re.compile(r"\b(predict(s|ed|ion)?|projected|forecast|would save|will (save|improve|reduce|speed)|"
                       r"expected (to|gain|saving|speedup)|estimated sav)", re.I)


def test_no_text_in_findings_or_experiments_makes_a_prediction(runs, cfg):
    sim = run_benchmark(cfg(batch_size=1), "s1"), run_benchmark(cfg(batch_size=8), "s2")
    for study in (build_study(runs[0], runs), build_study(sim[0], list(sim))):
        for f in study.findings:
            for text in [f.title, f.statement, *f.evidence, *f.tradeoffs]:
                assert not FORBIDDEN.search(text), text
        for e in study.next_experiments:
            assert not FORBIDDEN.search(e.suggestion + " " + e.reason)


def test_every_percentage_in_a_finding_traces_to_a_measured_comparison(runs):
    study = build_study(runs[0], runs, prices={"Test CPU": 2.0})
    allowed = set()
    for pa in study.analyses:
        for m in pa.metrics.values():
            for v in (m.change_pct, m.ci_low_pct, m.ci_high_pct):
                if v is not None:
                    allowed.add(f"{v:+.1f}%")
    seen = 0
    for f in study.findings:
        for line in f.evidence + f.tradeoffs:
            for pct in re.findall(r"[+-]\d+\.\d%", line):
                seen += 1
                assert pct in allowed, f"{pct} in '{line}' matches no measured comparison"
    assert seen > 10


def test_study_requires_a_completed_baseline(cfg):
    failed = run_benchmark(cfg(batch_size=200, prompt_tokens=2048), "oom")
    with pytest.raises(ValueError):
        build_study(failed, [failed])


def test_a_lone_run_has_nothing_to_compare(runs):
    study = build_study(runs[0], [runs[0]])
    assert study.analyses == [] and study.findings == [] and study.frontier == [runs[0].run_id]


def test_helpers(runs, cfg):
    sim = run_benchmark(cfg(), "sim")
    assert suggest_baseline([sim, *runs]).data_source.value == "measured"      # measured beats simulated
    assert suggest_baseline([]) is None
    other = measured_run("gpu", 20, device="GPU X", kind="cuda")
    assert price_keys([*runs, other, sim]) == ["GPU X", "Test CPU"]            # simulated devices are not priceable


# ---- exports ------------------------------------------------------------------------------------------

def test_study_exports_are_complete_and_honest(runs, cfg):
    study = build_study(runs[0], runs)
    data = json.loads(study_to_json(study))
    assert data["data_source"] == "measured" and "Nothing here is a prediction" in data["data_source_notice"]
    assert data["study"]["analyses"] and data["study"]["run_to_run_noise"]["replicate_pairs"] == 1
    md = study_to_markdown(study, {r.run_id: r.name for r in runs})
    assert "## Findings" in md and "95% CI" in md and "## Not yet measured" in md and "Confidence:" in md
    rows = study_to_csv(study).splitlines()
    assert rows[0].startswith("baseline_id,") and len(rows) > 20 and "improved" in study_to_csv(study)

    a, b = run_benchmark(cfg(batch_size=1), "a"), run_benchmark(cfg(batch_size=8), "b")
    sim_study = build_study(a, [a, b])
    assert json.loads(study_to_json(sim_study))["data_source"] == "simulated"
    assert "SIMULATED DATA" in study_to_markdown(sim_study, {a.run_id: a.name})
