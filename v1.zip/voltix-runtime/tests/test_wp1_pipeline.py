"""Work package 1, end to end on REAL measurements: tiny model on CPU -> runner CLI -> JSON file -> import ->
history -> compare -> optimize -> every export, each checked against numbers recomputed from the raw samples
with an independent calculation. Also: recommendations must be traceable to the run's own measurements.

Timings on a shared CPU are noisy and a toy model proves nothing about real models, so these tests assert that
the numbers are carried through and calculated correctly, never that anything is fast or slow."""

import csv
import io
import json
import re

import numpy as np
import pytest
from streamlit.testing.v1 import AppTest

from tests.phase3_helpers import measured_run
from voltix.db import RunRepository
from voltix.exports import (
    run_to_json,
    run_to_markdown,
    runs_to_csv,
    samples_to_csv,
    study_to_csv,
    study_to_json,
    study_to_markdown,
)
from voltix.importer import import_run_with_warnings
from voltix.optimize import build_study
from voltix.recommendations import recommend
from voltix.schemas import DataSource, Precision

# ---------------------------------------------------------------- recommendations <-> measurements

def numbers(text):
    return [float(x.replace(",", "")) for x in re.findall(r"\d[\d,]*\.?\d*", text)]


def evidence_numbers(rec):
    return [n for e in rec.evidence for n in numbers(e)]


def test_tail_latency_evidence_quotes_the_runs_own_percentiles():
    n = 120
    run = measured_run("tail", 100.0, n=n, seed=1, sigma=0.02)
    for i in (5, 50, 90, 110):          # a handful of slow iterations -> heavy tail
        run.samples[i].latency_ms *= 4
        run.samples[i].ttft_ms = min(run.samples[i].ttft_ms, run.samples[i].latency_ms)
    from voltix.metrics import compute_metrics
    run.metrics = compute_metrics(run.samples, peak_memory_gb=1.0)
    rec = next(r for r in recommend(run) if r.rule_id == "tail-latency")
    m = run.metrics
    quoted = evidence_numbers(rec)
    assert round(m.latency_p99_ms) in [round(q) for q in quoted] and round(m.latency_p50_ms) in [round(q) for q in quoted]
    assert any(abs(q - m.latency_p99_ms / m.latency_p50_ms) < 0.006 for q in quoted)       # the ratio, 2 decimals
    assert m.iterations in quoted and rec.kind == "observation"


def test_tail_rule_needs_enough_iterations_and_a_real_ratio():
    few = measured_run("few", 100.0, n=30, seed=2)
    few.samples[3].latency_ms *= 10
    assert "tail-latency" not in {r.rule_id for r in recommend(few)}              # 30 iterations: p99 not trusted
    calm = measured_run("calm", 100.0, n=120, seed=2, sigma=0.01)
    assert "tail-latency" not in {r.rule_id for r in recommend(calm)}             # no tail, nothing to say


def test_prefill_rule_quotes_ttft_share_exactly():
    run = measured_run("p", 100.0, n=40, seed=3)
    for s in run.samples:
        s.ttft_ms = s.latency_ms * 0.8
    from voltix.metrics import compute_metrics
    run.metrics = compute_metrics(run.samples, peak_memory_gb=1.0)
    rec = next(r for r in recommend(run) if r.rule_id == "prefill-dominated")
    share = 100 * run.metrics.ttft_mean_ms / run.metrics.latency_mean_ms
    assert f"{share:.0f}%" in rec.evidence[0] and f"{run.metrics.ttft_mean_ms:,.0f} ms" in rec.evidence[0]


def test_prefill_rule_does_not_fire_below_its_threshold():
    run = measured_run("p", 100.0, n=40, seed=3)         # helper sets TTFT at 20% of latency
    assert "prefill-dominated" not in {r.rule_id for r in recommend(run)}


def test_cpu_memory_pressure_speaks_about_process_ram_not_device_memory_or_catalog_estimates():
    run = measured_run("cpu-mem", 100.0, n=40, seed=4, peak_gb=7.6)       # test CPU has 8 GB total
    run.metrics.memory_utilization = 7.6 / 8.0
    rec = next(r for r in recommend(run) if r.rule_id == "memory-pressure")
    text = " ".join([rec.summary, *rec.evidence])
    assert "Process peak RAM 7.6 GB" in text and "95%" in text and "device memory" not in text.replace("this computer's RAM", "")
    assert "Estimated composition" not in text and rec.basis == "measured"


def test_gpu_memory_pressure_quotes_measured_peak_and_utilization():
    run = measured_run("gpu-mem", 50.0, n=40, seed=5, device="Tesla T4", kind="cuda", peak_gb=14.9)
    run.metrics.memory_utilization = 14.9 / 15.1
    rec = next(r for r in recommend(run) if r.rule_id == "memory-pressure")
    assert "Peak memory 14.9 GB" in rec.evidence[0] and "99%" in rec.evidence[0] and rec.severity.value == "critical"


def test_no_recommendation_for_a_metric_the_run_does_not_have():
    run = measured_run("nomem", 100.0, n=40, seed=6, peak_gb=None)
    ids = {r.rule_id for r in recommend(run)}
    assert "memory-pressure" not in ids and "unused-headroom" not in ids


def test_cold_start_quotes_the_first_iteration():
    run = measured_run("cold", 100.0, n=40, seed=7, warmup=0, sigma=0.01)
    run.samples[0].latency_ms = 900.0
    rec = next(r for r in recommend(run) if r.rule_id == "cold-start")
    assert "900 ms" in rec.evidence[0]
    assert "cold-start" not in {r.rule_id for r in recommend(measured_run("w", 100.0, n=40, seed=7, warmup=3))}


def test_simulated_and_measured_advice_is_labelled_by_its_own_basis():
    from voltix.demo import seed_demo_runs
    import tempfile, pathlib
    repo = RunRepository(pathlib.Path(tempfile.mkdtemp()) / "s.db")
    seed_demo_runs(repo)
    assert all(r.basis == "simulated" for run in repo.list(include_samples=True) for r in recommend(run))
    assert all(r.basis == "measured" for r in recommend(measured_run("m", 100.0, n=40)))

# ---------------------------------------------------------------- real pipeline

@pytest.fixture(scope="module")
def pipeline(tmp_path_factory):
    pytest.importorskip("torch")
    pytest.importorskip("transformers")
    import run_real_benchmark as cli
    from voltix.testmodel import create_tiny_model

    root = tmp_path_factory.mktemp("wp1")
    model = str(create_tiny_model(root / "tiny"))
    out = root / "res"
    common = ["--model", model, "--device", "cpu", "--iterations", "12", "--warmup", "2", "--prompt-tokens", "16",
              "--output-tokens", "6", "--allow-cpu", "--out", str(out)]
    assert cli.main(common + ["--precision", "fp32", "--batch-size", "2", "--repeats", "2"]) == 0
    assert cli.main(common + ["--precision", "fp32", "--batch-size", "4"]) == 0
    assert cli.main(common + ["--precision", "bf16", "--batch-size", "2"]) == 0
    db = tmp_path_factory.mktemp("wp1db") / "dest.db"
    repo = RunRepository(db)
    results = [import_run_with_warnings(repo, f.read_text(encoding="utf-8")) for f in sorted(out.glob("*.json"))]
    return repo, results, db


def test_files_import_as_measured_and_nothing_is_simulated(pipeline):
    repo, results, _ = pipeline
    assert len(results) == 4 and repo.count() == 4
    for res in results:
        r = res.run
        assert r.data_source == DataSource.MEASURED and r.backend == "transformers" and not r.environment.get("simulated")
        assert r.environment["device_kind"] == "cpu" and r.metrics.peak_memory_gb is not None
        assert "imported" in r.tags
    assert not any(r.is_simulated for r in repo.list(include_samples=True))


def test_stored_metrics_equal_independent_recomputation_from_stored_samples(pipeline):
    repo, _, _ = pipeline
    for r in repo.list(include_samples=True):
        lat = np.array([s.latency_ms for s in r.samples]); ttft = np.array([s.ttft_ms for s in r.samples])
        b, o, n = r.config.batch_size, r.config.output_tokens, len(lat)
        assert n == r.config.iterations and (ttft <= lat).all()
        assert r.metrics.throughput_tokens_per_s == pytest.approx(n * b * o / (lat.sum() / 1000), rel=1e-9)
        assert r.metrics.latency_mean_ms == pytest.approx(lat.mean(), rel=1e-9)
        assert r.metrics.latency_p95_ms == pytest.approx(np.percentile(lat, 95), rel=1e-9)
        assert r.metrics.ttft_mean_ms == pytest.approx(ttft.mean(), rel=1e-9)
        assert r.metrics.tpot_mean_ms == pytest.approx(((lat - ttft) / (o - 1)).mean(), rel=1e-9)
        assert r.metrics.total_output_tokens == n * b * o


def test_exports_carry_the_same_numbers_as_the_stored_run(pipeline):
    repo, _, _ = pipeline
    runs = repo.list(include_samples=True)
    recs = {r.run_id: recommend(r) for r in runs}
    rows = list(csv.DictReader(io.StringIO(runs_to_csv(runs))))
    assert len(rows) == 4
    for run in runs:
        row = next(x for x in rows if x["run_id"] == run.run_id)
        assert float(row["throughput_tokens_per_s"]) == pytest.approx(run.metrics.throughput_tokens_per_s, rel=1e-9)
        assert row["data_source"] == "measured" and row["precision"] == run.config.precision.value
        j = json.loads(run_to_json(run, recs[run.run_id]))
        assert j["data_source"] == "measured" and j["run"]["metrics"]["latency_p50_ms"] == run.metrics.latency_p50_ms
        samples = list(csv.DictReader(io.StringIO(samples_to_csv(run))))
        assert [float(s["latency_ms"]) for s in samples] == [s.latency_ms for s in run.samples]
        md = run_to_markdown(run, recs[run.run_id])
        assert f"{run.metrics.throughput_tokens_per_s:,.1f} tok/s" in md and "measured" in md.lower()
        assert "SIMULATED" not in md.split("## Run")[0]


def test_optimize_study_matches_hand_calculation_and_exports_agree(pipeline):
    repo, _, _ = pipeline
    runs = repo.list(include_samples=True)
    base = next(r for r in sorted(runs, key=lambda r: r.created_at) if r.config.batch_size == 2 and r.config.precision == Precision.FP32)
    study = build_study(base, runs)
    assert study.data_source == "measured" and len(study.analyses) >= 2
    rows = list(csv.DictReader(io.StringIO(study_to_csv(study))))
    payload = json.loads(study_to_json(study))
    assert payload["data_source"] == "measured" and payload["study"]
    cand_by_id = {r.run_id: r for r in runs}
    checked = 0
    for pa in study.analyses:
        cand = cand_by_id[pa.candidate_id]
        thr = pa.metrics["throughput_tokens_per_s"]
        assert thr.baseline == pytest.approx(base.metrics.throughput_tokens_per_s)
        assert thr.candidate == pytest.approx(cand.metrics.throughput_tokens_per_s)
        assert thr.change_pct == pytest.approx((cand.metrics.throughput_tokens_per_s / base.metrics.throughput_tokens_per_s - 1) * 100)
        if thr.has_ci:
            assert thr.ci_low_pct <= thr.change_pct <= thr.ci_high_pct
        row = next(x for x in rows if x["candidate_id"] == pa.candidate_id and x["metric"] == thr.label)
        assert float(row["change_pct"]) == pytest.approx(thr.change_pct) and row["data_source"] == "measured"
        mem = pa.metrics.get("peak_memory_gb")
        assert mem is None or mem.verdict == "not_assessed"          # CPU process memory never decides anything
        checked += 1
    assert checked >= 2
    md = study_to_markdown(study, {r.run_id: r.name for r in runs})
    assert "SIMULATED" not in md.splitlines()[2] and "measured" in md.lower()


def test_the_replicate_pair_measures_noise_and_is_never_called_an_effect(pipeline):
    repo, _, _ = pipeline
    runs = repo.list(include_samples=True)
    base = next(r for r in sorted(runs, key=lambda r: r.created_at) if r.config.batch_size == 2 and r.config.precision == Precision.FP32)
    study = build_study(base, runs)
    rep = [a for a in study.analyses if a.comparability.level.value == "replicate"]
    assert len(rep) == 1 and rep[0].classification not in ("win", "regression")


@pytest.mark.parametrize("module", ["history", "compare_runs", "optimize", "results", "overview"])
def test_ui_pages_render_the_imported_measured_runs(pipeline, monkeypatch, module):
    _, _, db = pipeline
    monkeypatch.setenv("VOLTIX_DB_PATH", str(db))
    at = AppTest.from_string(f"from ui.pages import {module}\n{module}.render()", default_timeout=120).run()
    assert not at.exception, [e.value for e in at.exception]
    text = " ".join(m.value for m in at.markdown)
    assert "These runs are SIMULATED" not in " ".join(w.value for w in at.warning)
    if module == "optimize":
        assert "CONFIDENCE" in text and "Not yet measured" in text
    if module == "compare_runs":
        assert "Is this a fair comparison?" in text


def test_history_lists_newest_first_and_keeps_save_order_for_equal_timestamps(tmp_path):
    repo = RunRepository(tmp_path / "o.db")
    old = measured_run("old", 100.0, created="2026-10-01T10:00:00+00:00")
    new = measured_run("new", 100.0, created="2026-10-03T10:00:00+00:00")
    mid_a = measured_run("mid-a", 100.0, created="2026-10-02T10:00:00+00:00")
    mid_b = measured_run("mid-b", 100.0, created="2026-10-02T10:00:00+00:00")
    for r in (old, mid_a, new, mid_b):
        repo.save(r)
    assert [r.name for r in repo.list(include_samples=False)] == ["new", "mid-b", "mid-a", "old"]


def test_cpu_process_memory_is_not_quoted_as_evidence_in_findings():
    base = measured_run("b", 100.0, n=40, seed=1, peak_gb=1.0)
    fast = measured_run("f", 50.0, n=40, seed=2, batch=2, peak_gb=0.4)
    study = build_study(base, [base, fast])
    for f in study.findings:
        assert not any("peak memory" in e.lower() for e in f.evidence)
    pa = study.analyses[0]
    assert pa.metrics["peak_memory_gb"].verdict == "not_assessed" and pa.metrics["peak_memory_gb"].note   # still in the table, with its note


def test_gpu_memory_is_quoted_as_evidence_when_it_is_assessed():
    base = measured_run("b", 100.0, n=40, seed=1, device="Tesla T4", kind="cuda", peak_gb=2.0)
    fast = measured_run("f", 50.0, n=40, seed=2, device="Tesla T4", kind="cuda", precision=Precision.FP16, peak_gb=1.0)
    study = build_study(base, [base, fast])
    assert any("peak memory" in e.lower() for f in study.findings for e in f.evidence)
