"""Importing exported runs and the headless real-benchmark runner (tiny model on CPU; no GPU needed)."""

import json

import pytest
from streamlit.testing.v1 import AppTest

from tests.phase3_helpers import measured_run
from voltix.db import RunRepository
from voltix.demo import seed_demo_runs
from voltix.exports import run_to_json
from voltix.importer import IMPORT_TAG, ImportRejected, import_run, parse_run
from voltix.schemas import DataSource


@pytest.fixture
def repo(tmp_path):
    return RunRepository(tmp_path / "i.db")


def exported(run, **edit):
    d = json.loads(run_to_json(run, []))
    for path, value in edit.items():
        node = d
        *parents, last = path.split(".")
        for k in parents:
            node = node[k]
        node[last] = value
    return json.dumps(d)


def test_measured_run_round_trips_and_stays_measured(repo):
    r = measured_run("gpu-run", 80.0, seed=4)
    got = import_run(repo, run_to_json(r, []))
    assert got.data_source == DataSource.MEASURED and IMPORT_TAG in got.tags
    saved = repo.get(r.run_id)
    assert saved.metrics.throughput_tokens_per_s == r.metrics.throughput_tokens_per_s and len(saved.samples) == len(r.samples)


def test_simulated_run_stays_simulated(repo):
    seed_demo_runs(repo)
    sim = next(r for r in repo.list(include_samples=True) if r.metrics)
    other = RunRepository(repo.path.parent / "o.db")
    assert import_run(other, run_to_json(sim, [])).data_source == DataSource.SIMULATED


def test_existing_run_is_never_overwritten(repo):
    r = measured_run("x", 80.0)
    import_run(repo, run_to_json(r, []))
    with pytest.raises(ImportRejected, match="already in your history"):
        import_run(repo, run_to_json(r, []))


def test_edited_metrics_are_detected():
    r = measured_run("x", 80.0)
    with pytest.raises(ImportRejected, match="does not match"):
        parse_run(exported(r, **{"run.metrics.throughput_tokens_per_s": 99999.0}))


def test_relabelling_data_source_is_rejected():
    r = measured_run("x", 80.0)
    with pytest.raises(ImportRejected, match="Inconsistent"):
        parse_run(exported(r, **{"run.data_source": "simulated"}))


def test_truncated_or_foreign_files_are_rejected_clearly():
    r = measured_run("x", 80.0)
    for bad, why in [(run_to_json(r, [])[:200], "not a valid JSON"), ("[1,2]", "does not look like"), ('{"a":1}', "does not look like"),
                     (exported(r, **{"run.samples": r.samples[0:0] and []}), "samples")]:
        with pytest.raises(ImportRejected, match=why):
            parse_run(bad)


def test_measured_run_without_environment_is_rejected():
    with pytest.raises(ImportRejected, match="environment"):
        parse_run(exported(measured_run("x", 80.0), **{"run.environment": {}}))


def test_history_page_import_workflow(tmp_path, monkeypatch):
    monkeypatch.setenv("VOLTIX_DB_PATH", str(tmp_path / "ui.db"))
    at = AppTest.from_string("from ui.pages import history\nhistory.render()", default_timeout=60).run()
    assert not at.exception and any("Import runs" in e.label for e in at.expander)


@pytest.fixture(scope="module")
def tiny(tmp_path_factory):
    pytest.importorskip("torch")
    pytest.importorskip("transformers")
    from voltix.testmodel import create_tiny_model

    return str(create_tiny_model(tmp_path_factory.mktemp("climodel") / "tiny"))


def test_cli_refuses_to_save_a_cpu_run_as_a_gpu_benchmark(tiny, tmp_path, capsys):
    import run_real_benchmark as cli

    code = cli.main(["--model", tiny, "--device", "cpu", "--precision", "fp32", "--iterations", "5", "--warmup", "1",
                     "--prompt-tokens", "16", "--output-tokens", "4", "--out", str(tmp_path / "o")])
    assert code == 3 and not list((tmp_path / "o").glob("*.json"))
    assert "not a GPU" in capsys.readouterr().out


def test_cli_cpu_run_writes_an_importable_measured_file(tiny, tmp_path, capsys):
    import run_real_benchmark as cli

    code = cli.main(["--model", tiny, "--device", "cpu", "--precision", "fp32", "--iterations", "5", "--warmup", "1",
                     "--prompt-tokens", "16", "--output-tokens", "4", "--allow-cpu", "--repeats", "2", "--out", str(tmp_path / "o")])
    out = capsys.readouterr().out
    files = sorted((tmp_path / "o").glob("*.json"))
    assert code == 0 and len(files) == 2
    assert "n/a (needs at least 100 measured iterations" in out and "n/a (needs at least 20 measured iterations" in out and "Process RAM (CPU, not GPU)" in out
    repo = RunRepository(tmp_path / "dest.db")
    for f in files:
        assert import_run(repo, f.read_text(encoding="utf-8")).data_source == DataSource.MEASURED
    assert repo.count() == 2
