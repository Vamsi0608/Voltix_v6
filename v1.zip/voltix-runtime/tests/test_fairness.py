import dataclasses

import pytest

from tests.phase3_helpers import measured_run
from voltix.fairness import Comparability, assess_comparability, device_identity, explain_level
from voltix.runner import run_benchmark
from voltix.schemas import Precision, RunStatus


def codes(report, severity=None):
    return {i.code for i in report.issues if severity is None or i.severity == severity}


def test_identical_setup_is_a_replicate_pair():
    r = assess_comparability(measured_run("a", 100, seed=1), measured_run("b", 100, seed=2))
    assert r.level == Comparability.REPLICATE and r.factors_changed == [] and r.reportable
    assert "noise" in explain_level(r)


def test_one_changed_setting_is_a_controlled_comparison():
    base = measured_run("base", 100)
    batch = assess_comparability(base, measured_run("b8", 200, batch=8))
    assert batch.level == Comparability.CONTROLLED and batch.factors_changed == ["batch size 1 → 8"]
    assert "batch-semantics" in codes(batch, "note")
    prec = assess_comparability(base, measured_run("bf16", 80, precision=Precision.BF16))
    assert prec.level == Comparability.CONTROLLED and "precision-quality" in codes(prec, "note")
    hw = assess_comparability(base, measured_run("gpu", 20, device="GPU X", kind="cuda"))
    assert hw.level == Comparability.CONTROLLED and hw.factors_changed[0].startswith("hardware Test CPU → GPU X")


def test_several_changed_settings_cannot_be_attributed():
    r = assess_comparability(measured_run("a", 100), measured_run("b", 60, batch=8, precision=Precision.BF16))
    assert r.level == Comparability.MULTI_FACTOR and len(r.factors_changed) == 2 and r.reportable
    assert "cannot be separated" in explain_level(r)


@pytest.mark.parametrize("override,code", [
    (dict(prompt=64), "workload"), (dict(out=32), "workload"), (dict(model="org/other"), "model"),
])
def test_different_work_is_not_like_for_like(override, code):
    r = assess_comparability(measured_run("a", 100), measured_run("b", 100, **override))
    assert r.level == Comparability.NOT_LIKE_FOR_LIKE and not r.reportable and code in codes(r, "blocker")
    assert explain_level(r).startswith("These runs cannot be compared")


def test_simulated_and_measured_never_compare(cfg):
    sim = run_benchmark(cfg(), "sim")
    r = assess_comparability(sim, measured_run("m", 100))
    assert r.level == Comparability.NOT_LIKE_FOR_LIKE and "data-source" in codes(r, "blocker")


def test_failed_run_has_no_metrics_to_compare(cfg):
    failed = run_benchmark(cfg(batch_size=200, prompt_tokens=2048), "oom")
    assert failed.status == RunStatus.FAILED
    assert "no-metrics" in codes(assess_comparability(failed, measured_run("m", 100)), "blocker")


def test_software_difference_is_a_warning_that_weakens_but_does_not_block():
    r = assess_comparability(measured_run("a", 100), measured_run("b", 80, batch=2, torch_version="2.5.0"))
    assert r.level == Comparability.CONTROLLED and "env-differs" in codes(r, "warning")
    assert "software environment also differs" in explain_level(r)


def test_device_identity_names_the_hardware_used():
    assert device_identity(measured_run("a", 100, device="Xeon")) == "Xeon"
    assert device_identity(run_benchmark(__import__("tests.conftest", fromlist=["make_config"]).make_config(), "s")).startswith("simulated ")


def test_report_serialises():
    d = assess_comparability(measured_run("a", 100), measured_run("b", 90, batch=2)).to_dict()
    assert d["level"] == "controlled" and d["reportable"] and d["issues"] and d["summary"]
