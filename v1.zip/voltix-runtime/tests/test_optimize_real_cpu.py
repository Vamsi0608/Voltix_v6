"""End-to-end on REAL measurements: tiny random-weight model on CPU -> runner -> database -> study.

Asserts structure and honesty, never speed: timings on a shared CPU are noisy and a toy model proves nothing
about real models.
"""

import json

import pytest

pytest.importorskip("torch")
pytest.importorskip("transformers")

from tests.conftest import tf_config  # noqa: E402
from voltix.db import RunRepository  # noqa: E402
from voltix.exports import study_to_json, study_to_markdown  # noqa: E402
from voltix.optimize import build_study  # noqa: E402
from voltix.runner import run_benchmark  # noqa: E402
from voltix.schemas import DataSource, Precision, RunStatus  # noqa: E402
from voltix.testmodel import create_tiny_model  # noqa: E402


@pytest.fixture(scope="module")
def sweep(tmp_path_factory):
    model = str(create_tiny_model(tmp_path_factory.mktemp("sweepmodel") / "tiny"))
    repo = RunRepository(tmp_path_factory.mktemp("sweepdb") / "s.db")
    runs = []
    for name, kw in [("b2-fp32 #1", {}), ("b2-fp32 #2", {"seed": 12}), ("b4-fp32", {"batch_size": 4}),
                     ("b2-bf16", {"precision": Precision.BF16})]:
        r = run_benchmark(tf_config(model, iterations=12, warmup_iterations=2, **kw), name)
        if r.status == RunStatus.COMPLETED:
            repo.save(r)
            runs.append(r)
    return repo, runs


def test_real_sweep_produces_a_structurally_sound_study(sweep):
    repo, runs = sweep
    assert len(runs) >= 3 and all(r.data_source == DataSource.MEASURED for r in runs)
    saved = [r for r in repo.list(include_samples=True) if r.metrics]
    study = build_study(min(saved, key=lambda r: r.created_at), saved)
    assert study.data_source == "measured" and study.analyses
    for pa in study.analyses:
        assert pa.confidence.level.value != "simulated"
        for m in pa.metrics.values():
            assert m.verdict in {"improved", "regressed", "negligible", "no_detectable_change", "not_assessed"}
            if m.key == "peak_memory_gb":
                assert m.verdict == "not_assessed"  # CPU process RSS never drives a verdict
    json.loads(study_to_json(study))
    assert "predicted" not in study_to_markdown(study, {r.run_id: r.name for r in saved}).lower()
