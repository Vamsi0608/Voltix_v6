import numpy as np
import pytest

from voltix.stats import (
    ChangeEstimate,
    bootstrap_ratio,
    classify_change,
    classify_scalar_change,
    coefficient_of_variation,
    lag1_autocorrelation,
    stable_seed,
    stat_mean,
    stat_percentile,
)


def normal(mean, n, sd, seed):
    return np.random.default_rng(seed).normal(mean, sd, n)


def test_recovers_a_known_latency_reduction():
    base, cand = normal(100, 40, 3, 1), normal(80, 40, 3, 2)
    est = bootstrap_ratio(base, cand, stat_mean, tag="t")
    assert est.has_interval and est.ci_low_pct < est.change_pct < est.ci_high_pct
    assert -23 < est.ci_low_pct and est.ci_high_pct < -17  # truth is -20%
    assert classify_change(est, higher_is_better=False) == "improved"
    assert classify_change(est, higher_is_better=True) == "regressed"  # same data, opposite metric direction


def test_same_tag_is_reproducible_and_different_tag_is_not():
    base, cand = normal(100, 30, 5, 1), normal(95, 30, 5, 2)
    a = bootstrap_ratio(base, cand, stat_mean, tag="x")
    b = bootstrap_ratio(base, cand, stat_mean, tag="x")
    c = bootstrap_ratio(base, cand, stat_mean, tag="y")
    assert (a.ci_low_pct, a.ci_high_pct) == (b.ci_low_pct, b.ci_high_pct)
    assert a.change_pct == c.change_pct and (a.ci_low_pct, a.ci_high_pct) != (c.ci_low_pct, c.ci_high_pct)
    assert stable_seed("a", 1) == stable_seed("a", 1) != stable_seed("a", 2)


def test_point_estimate_comes_from_real_samples():
    base, cand = np.array([10.0] * 10), np.array([5.0] * 10)
    est = bootstrap_ratio(base, cand, stat_mean, tag="t")
    assert est.change_pct == pytest.approx(-50.0) and est.ci_low_pct == est.ci_high_pct == pytest.approx(-50.0)


def test_too_few_samples_gives_a_point_estimate_but_no_interval_and_no_verdict():
    est = bootstrap_ratio([10, 11, 12], [5, 6, 7], stat_mean, tag="t")
    assert est.change_pct is not None and not est.has_interval and est.ratio_samples is None
    assert classify_change(est, False) == "not_assessed"


def test_zero_baseline_and_empty_input():
    assert bootstrap_ratio([0.0] * 10, [1.0] * 10, stat_mean).change_pct is None
    with pytest.raises(ValueError):
        bootstrap_ratio([], [1.0], stat_mean)


def test_percentile_statistic_matches_numpy_and_metrics_definition():
    from voltix.metrics import percentile
    data = normal(50, 37, 4, 3)
    assert stat_percentile(95)(data[None, :])[0] == pytest.approx(percentile(list(data), 95))


def test_different_statistics_for_each_arm():
    # Throughput-style: tokens per iteration differ between arms, so each arm needs its own statistic.
    base, cand = np.full(10, 100.0), np.full(10, 100.0)
    est = bootstrap_ratio(base, cand, lambda a: 16 * 1000 / a.mean(axis=1), lambda a: 64 * 1000 / a.mean(axis=1), tag="t")
    assert est.change_pct == pytest.approx(300.0)


@pytest.mark.parametrize("point,low,high,hib,expected", [
    (10, 5, 15, True, "improved"), (10, 5, 15, False, "regressed"),
    (-10, -15, -5, True, "regressed"), (-10, -15, -5, False, "improved"),
    (1.0, -1.0, 1.5, True, "negligible"),            # whole interval inside +/-2%
    (6, -3, 15, True, "no_detectable_change"),       # interval straddles zero
    (1.5, 0.2, 3.0, True, "no_detectable_change"),   # excludes zero but effect below the 2% minimum
    (2.0, 0.1, 4.0, True, "improved"),
])
def test_verdict_boundaries(point, low, high, hib, expected):
    assert classify_change(ChangeEstimate(point, low, high, 0.95, 1000), hib) == expected


def test_scalar_verdicts():
    assert classify_scalar_change(None, False) == "not_assessed"
    assert classify_scalar_change(1.0, False) == "negligible"
    assert classify_scalar_change(-10, False) == "improved" and classify_scalar_change(10, False) == "regressed"
    assert classify_scalar_change(10, True) == "improved"


def test_false_positive_rate_on_identical_distributions_is_low():
    """Calibration: when nothing changed, 'improved'/'regressed' should be rare."""
    false_alarms = 0
    trials = 150
    for t in range(trials):
        rng = np.random.default_rng(1000 + t)
        base, cand = rng.normal(100, 5, 30), rng.normal(100, 5, 30)
        est = bootstrap_ratio(base, cand, stat_mean, tag=f"null{t}", resamples=1000)
        false_alarms += classify_change(est, False) in ("improved", "regressed")
    assert false_alarms / trials <= 0.08, f"{false_alarms}/{trials} false alarms"


def test_detection_power_for_a_five_percent_effect():
    hits = 0
    trials = 60
    for t in range(trials):
        rng = np.random.default_rng(5000 + t)
        base, cand = rng.normal(100, 4, 40), rng.normal(95, 4, 40)
        est = bootstrap_ratio(base, cand, stat_mean, tag=f"pow{t}", resamples=1000)
        hits += classify_change(est, False) == "improved"
    assert hits / trials >= 0.9, f"only {hits}/{trials} detected"


def test_quality_statistics():
    assert coefficient_of_variation([10, 10, 10]) == 0.0 and coefficient_of_variation([5]) is None
    assert coefficient_of_variation([0, 0]) is None
    assert coefficient_of_variation([9, 11]) == pytest.approx(0.1414, abs=1e-3)
    trend = list(range(1, 41))
    assert lag1_autocorrelation(trend) > 0.9           # a drifting run
    assert abs(lag1_autocorrelation(list(normal(0, 400, 1, 4)))) < 0.2
    assert lag1_autocorrelation([1, 2, 3]) is None and lag1_autocorrelation([5, 5, 5, 5]) is None
