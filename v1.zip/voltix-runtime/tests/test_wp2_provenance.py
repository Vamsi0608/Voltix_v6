"""WP2: provenance (procedure, timestamps, revision) and minimum-observation rules."""

from __future__ import annotations

import json
import re

import pytest

from voltix.exports import run_to_json, run_to_markdown, runs_to_csv
from voltix.metrics import MIN_OBSERVATIONS, describe_metric, metric_support, metric_value, unsupported_reason
from voltix.runner import PROCEDURE_VERSION, run_benchmark
from voltix.schemas import BenchmarkConfig, Precision
from voltix.validation import validate_config


def _sim(iterations, warmup=2):
    return BenchmarkConfig(model_id="llama-3.1-8b", precision=Precision.FP16, batch_size=1, prompt_tokens=64, output_tokens=16,
                           iterations=iterations, warmup_iterations=warmup, seed=3, backend="simulated", hardware_id="a100-80gb")


@pytest.mark.parametrize("n,p95,p99,std", [(4, False, False, False), (5, False, False, True), (19, False, False, True),
                                           (20, True, False, True), (99, True, False, True), (100, True, True, True)])
def test_support_thresholds_at_boundaries(n, p95, p99, std):
    m = run_benchmark(_sim(n)).metrics
    assert (metric_value(m, "latency_p95_ms") is not None) is p95
    assert (metric_value(m, "ttft_p95_ms") is not None) is p95
    assert (metric_value(m, "latency_p99_ms") is not None) is p99
    assert (unsupported_reason(m, "latency_std_ms") is None) is std
    assert metric_value(m, "latency_p50_ms") is not None  # median is always reported


def test_describe_metric_says_why():
    m = run_benchmark(_sim(10)).metrics
    assert describe_metric(m, "latency_p99_ms") == "n/a (needs at least 100 measured iterations; this run has 10)"
    assert describe_metric(m, "latency_p50_ms").endswith("ms")


def test_exports_never_show_unsupported_statistics():
    run = run_benchmark(_sim(10))
    md = run_to_markdown(run, [])
    assert "needs at least 100 measured iterations" in md and "needs at least 20 measured iterations" in md
    rows = list(__import__("csv").DictReader(runs_to_csv([run]).splitlines()))
    assert rows[0]["latency_p99_ms"] == "" and rows[0]["latency_p95_ms"] == "" and rows[0]["latency_p50_ms"] != ""
    payload = json.loads(run_to_json(run, []))
    sup = payload["metric_support"]
    assert sup["latency_p99_ms"] == {"supported": False, "needs_iterations": 100, "has_iterations": 10}
    assert payload["metric_support"] == metric_support(run.metrics)


def test_supported_run_exports_the_values():
    run = run_benchmark(_sim(100))
    rows = list(__import__("csv").DictReader(runs_to_csv([run]).splitlines()))
    assert rows[0]["latency_p99_ms"] != "" and "needs at least" not in run_to_markdown(run, [])


def test_procedure_block_and_timestamps():
    run = run_benchmark(_sim(6, warmup=2))
    p = run.environment["procedure"]
    assert p["procedure_version"] == PROCEDURE_VERSION and p["warmup_iterations"] == 2 and p["measured_iterations"] == 6
    assert p["iterations_completed"] == p["iterations_planned"] == 8 and p["seed"] == 3 and p["executed"] is False
    iso = re.compile(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d")
    assert iso.match(p["started_at"]) and iso.match(p["finished_at"]) and p["started_at"] <= p["finished_at"]
    assert p["wall_clock_s"] >= 0 and set(p["limits"]) == {"max_run_seconds", "max_iteration_seconds"}


def test_procedure_recorded_for_cancelled_run_with_partial_progress():
    from voltix.control import CancelToken
    tok = CancelToken()
    tok.cancel()
    run = run_benchmark(_sim(5), cancel=tok)
    p = run.environment["procedure"]
    assert run.status.value == "cancelled" and p["iterations_completed"] == 0 and p["iterations_planned"] == 7


def test_revision_validation():
    base = BenchmarkConfig(model_id="x", precision=Precision.FP32, batch_size=1, prompt_tokens=8, output_tokens=4, iterations=3,
                           warmup_iterations=1, seed=1, backend="transformers", hardware_id="cpu")
    import dataclasses
    for bad in ("../x", "a b", "-x", "x" * 101, ";rm", ""):
        errs = validate_config(dataclasses.replace(base, revision=bad))
        assert any("Revision" in e for e in errs), bad
    assert not any("Revision" in e or "revision" in e for e in validate_config(dataclasses.replace(base, revision="main")))
    assert not any("Revision" in e or "revision" in e for e in validate_config(dataclasses.replace(base, revision="a1b2c3d4")))
    sim = dataclasses.replace(_sim(5), revision="main")
    assert any("only applies to the Transformers backend" in e for e in validate_config(sim))


def test_revision_roundtrips_and_old_files_without_it_load():
    cfg = BenchmarkConfig.from_dict({**_sim(5).to_dict(), "revision": None})
    d = _sim(5).to_dict()
    d.pop("revision")
    assert BenchmarkConfig.from_dict(d).revision is None and cfg.revision is None


torch = pytest.importorskip("torch")
pytest.importorskip("transformers")


def test_real_run_records_environment_and_procedure(tmp_path):
    from voltix.testmodel import create_tiny_model
    path = str(create_tiny_model(tmp_path / "tiny"))
    cfg = BenchmarkConfig(model_id=path, precision=Precision.FP32, batch_size=1, prompt_tokens=16, output_tokens=4, iterations=6,
                          warmup_iterations=1, seed=9, backend="transformers", hardware_id="cpu", revision="main")
    run = run_benchmark(cfg)
    env = run.environment
    assert env["software"]["torch"] and env["software"]["transformers"] and env["software"]["python"]
    assert env["host"]["cpu_count"] and env["model"]["id"] == path and env["model"]["num_parameters"] > 0
    assert env["model"]["requested_revision"] is None  # local folder: a revision is meaningless and is not claimed
    assert env["procedure"]["executed"] is True and env["procedure"]["iterations_completed"] == 7
    assert run.config.revision == "main" and run.created_at
