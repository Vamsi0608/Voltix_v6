import sqlite3

import pytest

from voltix.db import RunRepository, StorageError
from voltix.runner import run_benchmark
from voltix.schemas import BenchmarkRun, DataSource, RunStatus


def test_roundtrip_preserves_everything(repo, cfg):
    run = run_benchmark(cfg(), "round trip", tags=["x"])
    run.notes = "hello"
    repo.save(run)
    loaded = repo.get(run.run_id)
    assert loaded.to_dict() == run.to_dict()
    assert isinstance(loaded, BenchmarkRun) and loaded.data_source == DataSource.SIMULATED


def test_failed_run_roundtrip(repo, cfg):
    run = run_benchmark(cfg(batch_size=200, prompt_tokens=2048))
    repo.save(run)
    loaded = repo.get(run.run_id)
    assert loaded.status == RunStatus.FAILED and loaded.metrics is None and loaded.error


def test_save_is_idempotent_and_count(repo, cfg):
    run = run_benchmark(cfg())
    repo.save(run); repo.save(run)
    assert repo.count() == 1 and repo.exists(run.run_id)


def test_list_filters_and_order(repo, cfg):
    a = run_benchmark(cfg(), "a")
    b = run_benchmark(cfg(batch_size=200, prompt_tokens=2048), "b")
    c = run_benchmark(cfg(model_id="tinyllama-1.1b"), "c")
    for r in (a, b, c):
        repo.save(r)
    assert {r.name for r in repo.list(status="failed")} == {"b"}
    assert {r.name for r in repo.list(model_id="tinyllama-1.1b")} == {"c"}
    assert len(repo.list(data_source="simulated")) == 3 and repo.list(data_source="measured") == []
    assert len(repo.list(limit=2)) == 2
    assert repo.list(include_samples=False)[0].samples == []


def test_notes_delete_and_missing(repo, cfg):
    run = run_benchmark(cfg()); repo.save(run)
    assert repo.update_notes(run.run_id, "note\x07") and repo.get(run.run_id).notes == "note"
    assert repo.update_notes("missing", "x") is False
    assert repo.delete(run.run_id) and repo.get(run.run_id) is None
    assert repo.delete(run.run_id) is False


def test_delete_by_tag(repo, cfg):
    for i, tags in enumerate((["demo"], ["demo"], [])):
        repo.save(run_benchmark(cfg(seed=i), tags=tags))
    assert repo.delete_by_tag("demo") == 2 and repo.count() == 1


def test_sql_injection_in_name_is_harmless(repo, cfg):
    run = run_benchmark(cfg(), "x'); DROP TABLE runs;--")
    repo.save(run)
    assert repo.count() == 1


def test_corrupted_row_raises_storage_error(tmp_path, cfg):
    repo = RunRepository(tmp_path / "c.db")
    run = run_benchmark(cfg()); repo.save(run)
    with sqlite3.connect(repo.path) as conn:
        conn.execute("UPDATE runs SET config_json = 'not json'")
    with pytest.raises(StorageError):
        repo.get(run.run_id)


def test_unwritable_location_raises_storage_error(tmp_path):
    blocker = tmp_path / "file"
    blocker.write_text("x")
    with pytest.raises(StorageError):
        RunRepository(blocker / "sub" / "db.sqlite")


def test_env_var_path(tmp_path, monkeypatch):
    monkeypatch.setenv("VOLTIX_DB_PATH", str(tmp_path / "env.db"))
    assert RunRepository().path == tmp_path / "env.db"
