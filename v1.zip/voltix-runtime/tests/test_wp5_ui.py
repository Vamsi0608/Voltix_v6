"""WP5: Requirements page."""

from __future__ import annotations

import pytest
from streamlit.testing.v1 import AppTest

from tests.phase3_helpers import measured_run
from voltix.db import RunRepository


@pytest.fixture
def seeded(tmp_path, monkeypatch):
    monkeypatch.setenv("VOLTIX_DB_PATH", str(tmp_path / "r.db"))
    repo = RunRepository()
    repo.save(measured_run("big", 50.0, kind="cuda", device="G", peak_gb=30.0, batch=8, seed=1, n=40, model="org/<b>m</b>"))
    repo.save(measured_run("ok", 80.0, kind="cuda", device="G", peak_gb=12.0, batch=4, seed=2, n=40, model="org/<b>m</b>"))
    return repo


def page() -> AppTest:
    return AppTest.from_string("from ui.pages import requirements\nrequirements.render()", default_timeout=60)


def test_empty_db_guides_the_user(tmp_path, monkeypatch):
    monkeypatch.setenv("VOLTIX_DB_PATH", str(tmp_path / "e.db"))
    at = page().run()
    assert not at.exception and any("No completed runs" in i.value for i in at.info)


def test_no_limit_set_asks_for_one(seeded):
    at = page().run()
    assert not at.exception and any("at least one limit" in i.value for i in at.info)


def test_memory_limit_picks_the_run_that_fits(seeded):
    at = page().run()
    at.number_input(key="req_mem").set_value(15.0)
    at = at.run()
    assert not at.exception
    assert any("Best saved run that meets every limit: **ok**" in s.value for s in at.success)
    text = " ".join(e.label for e in at.expander)
    assert "does not meet" in text and "meets all" in text


def test_model_name_is_escaped_in_heading(seeded):
    at = page().run()
    at.number_input(key="req_mem").set_value(15.0)
    at = at.run()
    heads = [m.value for m in at.markdown if m.value.startswith("####")]
    assert heads and not any("<b>" in h for h in heads)


def test_nothing_fits_message(seeded):
    at = page().run()
    at.number_input(key="req_mem").set_value(1.0)
    at = at.run()
    assert not at.exception and any("does not show that no configuration can" in i.value for i in at.info)
    assert not at.success
