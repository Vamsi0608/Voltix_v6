from voltix.recommendations import recommend
from voltix.runner import run_benchmark
from voltix.schemas import Precision, Severity


def ids(run):
    return {r.rule_id for r in recommend(run)}


def test_fp32_recommends_half_precision_with_evidence(cfg):
    run = run_benchmark(cfg(model_id="tinyllama-1.1b", hardware_id="a10g-24gb", precision=Precision.FP32))
    rec = next(r for r in recommend(run) if r.rule_id == "fp32-weights")
    assert "bf16" in rec.title and rec.evidence and rec.kind == "hypothesis" and rec.severity == Severity.INFO


def test_fp32_on_t4_suggests_fp16_because_no_bf16(cfg):
    run = run_benchmark(cfg(model_id="tinyllama-1.1b", hardware_id="t4-16gb", precision=Precision.FP32))
    rec = next(r for r in recommend(run) if r.rule_id == "fp32-weights")
    assert "fp16" in rec.title and any("no native bf16" in e for e in rec.evidence)


def test_small_batch_with_headroom_suggests_larger_batch(cfg):
    run = run_benchmark(cfg(batch_size=1))
    rec = next(r for r in recommend(run) if r.rule_id == "unused-headroom")
    assert "batch size 4" in rec.action and any("estimate (not a measurement) at batch 4" in e for e in rec.evidence)


def test_no_batch_suggestion_when_larger_batch_would_not_fit(cfg):
    # Llama 70B int4 on an 80GB card at batch 1: weights ~35GB, batch 4 still fits, so use a tight case instead.
    run = run_benchmark(cfg(model_id="mistral-7b", precision=Precision.FP16, hardware_id="a10g-24gb",
                            batch_size=7, prompt_tokens=4096, output_tokens=1024))
    assert "unused-headroom" not in ids(run)


def test_memory_pressure_fires_near_capacity(cfg):
    # GQA keeps Mistral's KV cache small (~131 KB/token), so it takes 36 x 1280 tokens to fill a 24 GB card.
    run = run_benchmark(cfg(batch_size=36, prompt_tokens=1024, output_tokens=256))
    found = {r.rule_id: r for r in recommend(run)}
    assert run.status.value == "completed" and run.metrics.memory_utilization > 0.9
    assert "memory-pressure" in found and any("KV cache" in e for e in found["memory-pressure"].evidence)


def test_cold_start_detected_only_without_warmup(cfg):
    assert "cold-start" in ids(run_benchmark(cfg(warmup_iterations=0, iterations=20)))
    assert "cold-start" not in ids(run_benchmark(cfg(warmup_iterations=3, iterations=20)))


def test_few_iterations_note(cfg):
    assert "few-iterations" in ids(run_benchmark(cfg(iterations=5)))
    assert "few-iterations" in ids(run_benchmark(cfg(iterations=50)))        # p99 needs 100
    assert "few-iterations" not in ids(run_benchmark(cfg(iterations=100)))


def test_quantization_quality_caveat(cfg):
    assert "quantization-quality" in ids(run_benchmark(cfg(precision=Precision.INT8)))
    assert "quantization-quality" not in ids(run_benchmark(cfg(precision=Precision.FP16)))


def test_prefill_dominated_with_long_prompt(cfg):
    run = run_benchmark(cfg(model_id="llama-3.1-8b", hardware_id="h100-80gb", batch_size=4, prompt_tokens=6000, output_tokens=32))
    assert "prefill-dominated" in ids(run)


def test_failed_run_gets_critical_recommendation_first(cfg):
    run = run_benchmark(cfg(batch_size=200, prompt_tokens=2048))
    recs = recommend(run)
    assert recs[0].rule_id == "run-failed" and recs[0].severity == Severity.CRITICAL


def test_ordering_by_severity_and_basis_labelled(cfg):
    run = run_benchmark(cfg(model_id="tinyllama-1.1b", precision=Precision.FP32, warmup_iterations=0, iterations=5, batch_size=1))
    recs = recommend(run)
    order = {Severity.CRITICAL: 0, Severity.WARNING: 1, Severity.INFO: 2}
    assert [order[r.severity] for r in recs] == sorted(order[r.severity] for r in recs)
    assert all(r.basis == "simulated" for r in recs)


# ---- Phase 3: recommendations must never predict a saving ------------------------------

import re  # noqa: E402

FORBIDDEN = re.compile(r"speed-?up|expected effect|roughly|will (rise|be|reduce|improve|increase|lower)|faster by|"
                       r"\bsaves\b|\bsavings?\b|\d+(\.\d+)?\s*%\s*(faster|lower|less|savings|gain)", re.I)


def _every_rule_run(cfg):
    return [
        run_benchmark(cfg(batch_size=200, prompt_tokens=2048)),                       # run-failed
        run_benchmark(cfg(batch_size=36, prompt_tokens=1024, output_tokens=256)),     # memory-pressure
        run_benchmark(cfg(model_id="tinyllama-1.1b", precision=Precision.FP32, warmup_iterations=0, iterations=5, batch_size=1)),
        run_benchmark(cfg(model_id="llama-3.1-8b", hardware_id="h100-80gb", batch_size=4, prompt_tokens=6000, output_tokens=32)),
        run_benchmark(cfg(precision=Precision.INT8)),
        run_benchmark(cfg(batch_size=1)),
    ]


def test_no_recommendation_predicts_a_saving(cfg):
    seen_rules = set()
    for run in _every_rule_run(cfg):
        for rec in recommend(run):
            seen_rules.add(rec.rule_id)
            for text in (rec.title, rec.summary, rec.action, rec.how_to_verify, rec.caveat or ""):
                assert not FORBIDDEN.search(text), f"{rec.rule_id}: predictive wording in {text!r}"
    # the guard is only meaningful if it saw the rules that used to make predictions
    assert {"fp32-weights", "unused-headroom", "memory-pressure", "prefill-dominated", "run-failed"} <= seen_rules


def test_every_recommendation_declares_its_kind_and_how_to_verify(cfg):
    for run in _every_rule_run(cfg):
        for rec in recommend(run):
            assert rec.kind in ("observation", "hypothesis", "caveat") and rec.how_to_verify.strip()


def test_untested_ideas_are_labelled_as_hypotheses(cfg):
    kinds = {r.rule_id: r.kind for run in _every_rule_run(cfg) for r in recommend(run)}
    assert kinds["fp32-weights"] == "hypothesis" and kinds["unused-headroom"] == "hypothesis"
    assert kinds["run-failed"] == "observation" and kinds["quantization-quality"] == "caveat"
