"""Work package 1: every reported number is checked against an independent recomputation, a hand-worked example,
or a known exact transformation. The reference code below deliberately does not import voltix.metrics."""

import math

import numpy as np
import pytest

from tests.phase3_helpers import measured_run
from voltix.metrics import METRIC_SPECS, compute_metrics, format_metric, pct_change, percentile
from voltix.optimize import SPECS, analyze_pair, cost_per_million_tokens, device_identity
from voltix.schemas import Precision, RequestSample, RunStatus


def samples(lat, ttft, batch=1, out=16):
    return [RequestSample(index=i, ttft_ms=t, latency_ms=l, batch_size=batch, output_tokens_per_seq=out)
            for i, (l, t) in enumerate(zip(lat, ttft))]


def reference(lat, ttft, batch, out):
    """Straight from the definitions, with numpy."""
    lat, ttft = np.asarray(lat, float), np.asarray(ttft, float)
    total_s = lat.sum() / 1000.0
    tokens = len(lat) * batch * out
    tpot = ((lat - ttft) / (out - 1)).mean() if out > 1 else 0.0
    return {
        "latency_mean_ms": lat.mean(), "latency_p50_ms": np.percentile(lat, 50), "latency_p95_ms": np.percentile(lat, 95),
        "latency_p99_ms": np.percentile(lat, 99), "latency_min_ms": lat.min(), "latency_max_ms": lat.max(),
        "latency_std_ms": lat.std(ddof=0), "ttft_mean_ms": ttft.mean(), "ttft_p50_ms": np.percentile(ttft, 50),
        "ttft_p95_ms": np.percentile(ttft, 95), "tpot_mean_ms": tpot, "throughput_tokens_per_s": tokens / total_s,
        "sequences_per_s": len(lat) * batch / total_s, "total_output_tokens": tokens, "total_time_s": total_s,
    }


# ---- hand-worked example --------------------------------------------------------------------

def test_hand_computed_example():
    # 4 iterations, batch 2, 11 output tokens each. Latencies 100, 200, 300, 400 ms; TTFT 10, 20, 30, 40 ms.
    m = compute_metrics(samples([100, 200, 300, 400], [10, 20, 30, 40], batch=2, out=11), peak_memory_gb=3.0, device_memory_gb=12.0)
    assert m.total_time_s == pytest.approx(1.0)                       # (100+200+300+400) ms
    assert m.total_output_tokens == 4 * 2 * 11 == 88
    assert m.throughput_tokens_per_s == pytest.approx(88.0)           # 88 tokens in 1.0 s
    assert m.sequences_per_s == pytest.approx(8.0)                    # 8 sequences in 1.0 s
    assert m.latency_mean_ms == pytest.approx(250.0)
    assert m.latency_p50_ms == pytest.approx(250.0)                   # linear interpolation between 200 and 300
    assert m.latency_p95_ms == pytest.approx(385.0)                   # rank 2.85: 300 + 0.85*100
    assert m.latency_p99_ms == pytest.approx(397.0)                   # rank 2.97
    assert m.latency_std_ms == pytest.approx(math.sqrt(12500.0))      # population std of 100..400
    assert m.ttft_mean_ms == pytest.approx(25.0)
    assert m.tpot_mean_ms == pytest.approx(((90 / 10) + (180 / 10) + (270 / 10) + (360 / 10)) / 4)  # (latency-ttft)/(out-1)
    assert m.memory_utilization == pytest.approx(0.25)


def test_single_iteration_and_constant_latency_edge_cases():
    m = compute_metrics(samples([50.0], [5.0], batch=1, out=10))
    assert m.latency_std_ms == 0.0 and m.latency_p99_ms == 50.0 and m.throughput_tokens_per_s == pytest.approx(200.0)
    m = compute_metrics(samples([80.0] * 7, [8.0] * 7, out=1))
    assert m.tpot_mean_ms == 0.0  # one output token: per-token time after the first is undefined, reported as 0, not NaN
    assert not any(isinstance(v, float) and math.isnan(v) for v in m.to_dict().values())


@pytest.mark.parametrize("seed", range(8))
@pytest.mark.parametrize("batch,out,n", [(1, 16, 30), (8, 128, 100), (4, 2, 7), (16, 1, 3)])
def test_matches_independent_reference(seed, batch, out, n):
    rng = np.random.default_rng(seed)
    lat = rng.lognormal(mean=4.5, sigma=0.4, size=n) + 5
    ttft = lat * rng.uniform(0.05, 0.6, size=n)
    got = compute_metrics(samples(lat, ttft, batch, out)).to_dict()
    for key, want in reference(lat, ttft, batch, out).items():
        assert got[key] == pytest.approx(want, rel=1e-9, abs=1e-9), key


@pytest.mark.parametrize("q", [0, 1, 25, 50, 75, 95, 99, 100])
def test_percentile_matches_numpy(q):
    v = np.random.default_rng(1).normal(100, 20, 57)
    assert percentile(list(v), q) == pytest.approx(np.percentile(v, q))


# ---- metamorphic properties (units and scaling) -----------------------------------------------

def test_scaling_all_times_by_k_scales_metrics_consistently():
    lat = np.random.default_rng(3).uniform(50, 300, 40)
    ttft = lat * 0.3
    a = compute_metrics(samples(lat, ttft, batch=4, out=32))
    b = compute_metrics(samples(lat * 2.5, ttft * 2.5, batch=4, out=32))
    for key in ("latency_mean_ms", "latency_p50_ms", "latency_p95_ms", "latency_p99_ms", "latency_std_ms", "ttft_mean_ms",
                "ttft_p95_ms", "tpot_mean_ms", "total_time_s"):
        assert getattr(b, key) == pytest.approx(getattr(a, key) * 2.5), key
    assert b.throughput_tokens_per_s == pytest.approx(a.throughput_tokens_per_s / 2.5)
    assert b.sequences_per_s == pytest.approx(a.sequences_per_s / 2.5)


def test_doubling_batch_at_equal_latency_doubles_throughput_not_latency():
    lat = [100.0] * 10
    a = compute_metrics(samples(lat, [10.0] * 10, batch=2, out=16))
    b = compute_metrics(samples(lat, [10.0] * 10, batch=4, out=16))
    assert b.throughput_tokens_per_s == pytest.approx(2 * a.throughput_tokens_per_s) and b.latency_mean_ms == a.latency_mean_ms


def test_units_the_numbers_are_milliseconds_and_tokens_per_second():
    # 128 tokens in 3.72 s is 34.4 tokens/s; this is the arithmetic behind a real T4 result reported by the user.
    m = compute_metrics(samples([3720.0] * 30, [34.0] * 30, batch=1, out=128))
    assert m.throughput_tokens_per_s == pytest.approx(34.4, abs=0.05) and m.latency_mean_ms == 3720.0 and m.total_time_s == pytest.approx(111.6)


def test_invalid_samples_are_refused_not_averaged_in():
    for lat, ttft in [(0.0, 0.0), (-1.0, 0.0), (float("nan"), 0.0), (float("inf"), 0.0), (10.0, 11.0), (10.0, -1.0), (10.0, float("nan"))]:
        with pytest.raises(ValueError):
            compute_metrics(samples([lat], [ttft]))
    with pytest.raises(ValueError):
        compute_metrics([])


# ---- percent change and direction -------------------------------------------------------------

def test_pct_change_definition_and_missing_values():
    assert pct_change(100.0, 150.0) == pytest.approx(50.0) and pct_change(100.0, 50.0) == pytest.approx(-50.0)
    assert pct_change(0.0, 5.0) is None and pct_change(None, 5.0) is None and pct_change(5.0, None) is None


def test_every_metric_has_one_direction_in_both_modules():
    assert {k: v[3] for k, v in SPECS.items() if k in {s.key for s in METRIC_SPECS}} == \
           {s.key: s.higher_is_better for s in METRIC_SPECS if s.key in SPECS}


def test_format_metric_units_and_missing():
    assert format_metric("throughput_tokens_per_s", 34.44) == "34.4 tok/s" and format_metric("peak_memory_gb", None) == "n/a"
    assert format_metric("memory_utilization", 0.256) == "25.6%" and format_metric("latency_p95_ms", 3813.0) == "3,813.0 ms"


# ---- comparison engine against exact transformations ------------------------------------------

def scaled(base, k_lat, *, name, peak=None, device=None, precision=Precision.BF16):
    """Same iterations, every latency/TTFT multiplied by k_lat: an exactly known difference.

    The candidate's precision differs from the baseline's, so the pair is a controlled one-setting comparison
    (identical setups are replicates and are deliberately never called improvements)."""
    import copy
    import uuid

    s = [RequestSample(x.index, x.ttft_ms * k_lat, x.latency_ms * k_lat, x.batch_size, x.output_tokens_per_seq) for x in base.samples]
    r = copy.deepcopy(base)
    r.run_id, r.name, r.samples = f"run_{uuid.uuid4().hex[:10]}", name, s
    r.config.precision = precision
    r.metrics = compute_metrics(s, peak_memory_gb=peak if peak is not None else base.metrics.peak_memory_gb)
    if device:
        r.environment["device"]["name"] = device
    return r


@pytest.fixture
def base():
    return measured_run("base", 100.0, n=60, seed=5, sigma=0.05)


def verdicts(pa):
    return {k: m.verdict for k, m in pa.metrics.items()}


def test_faster_candidate_is_better_on_every_direction_and_numbers_are_exact(base):
    cand = scaled(base, 0.5, name="2x faster")
    pa = analyze_pair(base, cand)
    thr, p95, ttft = pa.metrics["throughput_tokens_per_s"], pa.metrics["latency_p95_ms"], pa.metrics["ttft_mean_ms"]
    assert thr.change_pct == pytest.approx(100.0) and p95.change_pct == pytest.approx(-50.0) and ttft.change_pct == pytest.approx(-50.0)
    assert thr.verdict == "improved" and p95.verdict == "improved" and ttft.verdict == "improved"   # lower latency IS better
    # The bootstrap treats the two runs as independent samples, so even an exact 2x has a (small) interval around +100%.
    assert thr.ci_low_pct < 100.0 < thr.ci_high_pct and thr.ci_high_pct - thr.ci_low_pct < 25.0
    assert pa.metrics["tpot_mean_ms"].change_pct == pytest.approx(-50.0)
    assert thr.baseline == pytest.approx(base.metrics.throughput_tokens_per_s) and thr.candidate == pytest.approx(cand.metrics.throughput_tokens_per_s)


def test_slower_candidate_is_worse_on_every_direction(base):
    pa = analyze_pair(base, scaled(base, 2.0, name="2x slower"))
    assert pa.metrics["throughput_tokens_per_s"].change_pct == pytest.approx(-50.0)
    assert pa.metrics["latency_p50_ms"].change_pct == pytest.approx(100.0)
    assert {pa.metrics[k].verdict for k in ("throughput_tokens_per_s", "latency_p50_ms", "latency_p95_ms", "ttft_mean_ms")} == {"regressed"}


def test_change_below_the_minimum_effect_is_not_called_an_improvement():
    tight = measured_run("tight", 100.0, n=300, seed=6, sigma=0.01)       # very low noise, so a 1.5% change is resolvable
    pa = analyze_pair(tight, scaled(tight, 1 / 1.015, name="1.5% faster"), min_effect_pct=2.0)
    assert pa.metrics["throughput_tokens_per_s"].change_pct == pytest.approx(1.5, abs=1e-6)
    assert pa.metrics["throughput_tokens_per_s"].verdict == "negligible"
    assert analyze_pair(tight, scaled(tight, 1 / 1.015, name="x"), min_effect_pct=1.0).metrics["throughput_tokens_per_s"].verdict == "improved"


def test_a_small_change_buried_in_noise_is_never_called_an_improvement(base):
    pa = analyze_pair(base, scaled(base, 0.99, name="1% faster"))      # 60 noisy iterations cannot resolve 1%
    assert pa.metrics["throughput_tokens_per_s"].verdict in ("no_detectable_change", "negligible")


def test_reported_baseline_values_are_the_stored_run_metrics(base):
    cand = scaled(base, 0.8, name="c")
    pa = analyze_pair(base, cand)
    for key in ("latency_p50_ms", "latency_p95_ms", "ttft_mean_ms", "tpot_mean_ms"):
        assert pa.metrics[key].baseline == pytest.approx(getattr(base.metrics, key)) and pa.metrics[key].candidate == pytest.approx(getattr(cand.metrics, key))


def test_p99_is_not_assessed_below_100_iterations(base):
    assert analyze_pair(base, scaled(base, 0.5, name="c")).metrics["latency_p99_ms"].verdict == "not_assessed"
    big = measured_run("b", 100.0, n=120, seed=1)
    assert analyze_pair(big, scaled(big, 0.5, name="c")).metrics["latency_p99_ms"].verdict == "improved"


# ---- memory ----------------------------------------------------------------------------------

def test_gpu_memory_change_is_exact_and_lower_is_better():
    gpu = measured_run("g", 100.0, n=40, seed=2, kind="cuda", device="Tesla T4", peak_gb=1.0)
    cand = scaled(gpu, 1.0, name="c", peak=1.5)
    cand.environment["measurement"]["memory_kind"] = "cuda_max_memory_allocated"
    m = analyze_pair(gpu, cand).metrics["peak_memory_gb"]
    assert m.change_pct == pytest.approx(50.0) and m.verdict == "regressed" and not m.has_ci
    better = scaled(gpu, 1.0, name="c2", peak=0.5)
    assert analyze_pair(gpu, better).metrics["peak_memory_gb"].verdict == "improved"


def test_cpu_process_memory_never_drives_a_verdict():
    cpu = measured_run("c", 100.0, n=40, seed=2, kind="cpu", peak_gb=1.0)
    assert analyze_pair(cpu, scaled(cpu, 1.0, name="c2", peak=3.0)).metrics["peak_memory_gb"].verdict == "not_assessed"


def test_missing_memory_is_left_out_not_zero():
    a = measured_run("a", 100.0, n=40, seed=2, peak_gb=None)
    pa = analyze_pair(a, scaled(a, 0.5, name="c"))
    assert "peak_memory_gb" not in pa.metrics


# ---- cost ------------------------------------------------------------------------------------

def test_cost_formula_hand_computed():
    # $1.20/hour at 100 tokens/s: 360,000 tokens per hour -> $1.20 / 0.36 M tokens = $3.3333 per million tokens.
    assert cost_per_million_tokens(100.0, 1.2) == pytest.approx(3.3333333, rel=1e-6)
    assert cost_per_million_tokens(250.0, 0.0) == 0.0
    for bad in [(0.0, 1.0), (-5.0, 1.0), (10.0, -1.0)]:
        with pytest.raises(ValueError):
            cost_per_million_tokens(*bad)


def test_cost_change_combines_price_and_throughput_exactly():
    a = measured_run("a", 100.0, n=60, seed=5, device="GPU A", kind="cuda")
    b = scaled(a, 0.4, name="b", device="GPU B")                      # 2.5x the throughput
    prices = {device_identity(a): 1.0, device_identity(b): 2.0}      # but twice the hourly price
    cost = analyze_pair(a, b, prices=prices).metrics["cost_per_million_tokens"]
    assert cost.change_pct == pytest.approx((2.0 / 2.5 - 1) * 100)    # -20%
    assert cost.baseline == pytest.approx(cost_per_million_tokens(a.metrics.throughput_tokens_per_s, 1.0))
    assert cost.candidate == pytest.approx(cost_per_million_tokens(b.metrics.throughput_tokens_per_s, 2.0))
    assert cost.verdict == "improved"


def test_cost_is_not_produced_without_prices_or_for_simulated_data():
    a = measured_run("a", 100.0, n=60, seed=5, device="GPU A", kind="cuda")
    b = scaled(a, 0.5, name="b", device="GPU B")
    assert "cost_per_million_tokens" not in analyze_pair(a, b).metrics                                        # no prices
    assert "cost_per_million_tokens" not in analyze_pair(a, b, prices={device_identity(a): 1.0}).metrics      # one price missing
    assert "cost_per_million_tokens" in analyze_pair(a, b, prices={device_identity(a): 1.0, device_identity(b): 1.0}).metrics
    import voltix.catalog as cat
    from voltix.runner import run_benchmark
    from voltix.schemas import BenchmarkConfig

    def sim(prec):
        return run_benchmark(BenchmarkConfig(model_id=next(iter(cat.MODELS)), precision=prec, batch_size=2, prompt_tokens=64, output_tokens=32,
                                             iterations=30, warmup_iterations=1, seed=3, backend="simulated", hardware_id=next(iter(cat.HARDWARE))), "s")
    s1, s2 = sim(Precision.FP16), sim(Precision.FP32)
    assert "cost_per_million_tokens" not in analyze_pair(s1, s2, prices={device_identity(s1): 1.0}).metrics  # simulated: never priced


# ---- failed runs ------------------------------------------------------------------------------

def test_failed_runs_are_never_compared(base):
    from voltix.optimize import build_study

    failed = scaled(base, 0.5, name="failed")
    failed.status, failed.error, failed.metrics, failed.samples = RunStatus.FAILED, "boom", None, []
    pa = analyze_pair(base, failed)
    assert pa.classification == "not_comparable" and not pa.metrics
    study = build_study(base, [base, failed, scaled(base, 0.5, name="ok")])
    assert failed.run_id not in {a.candidate_id for a in study.analyses}


def test_recommendation_and_comparison_use_the_same_sample_thresholds():
    from voltix.optimize import MIN_SAMPLES
    from voltix.recommendations import T

    assert T.min_samples_for_tail == MIN_SAMPLES["p99"] and T.min_samples_p95 == MIN_SAMPLES["p95"]
