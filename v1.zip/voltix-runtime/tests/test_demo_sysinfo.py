from voltix.demo import DEMO_TAG, demo_experiments, has_demo_runs, remove_demo_runs, seed_demo_runs
from voltix.schemas import RunStatus
from voltix.sysinfo import collect_system_info
from voltix.validation import validate_config


def test_all_demo_configs_are_valid():
    for name, config in demo_experiments():
        assert validate_config(config) == [], name


def test_seed_is_idempotent_and_removable(repo):
    n = seed_demo_runs(repo)
    assert n == len(demo_experiments()) == repo.count()
    assert seed_demo_runs(repo) == 0 and has_demo_runs(repo)
    runs = repo.list()
    assert all(DEMO_TAG in r.tags and r.is_simulated for r in runs)
    assert sum(r.status == RunStatus.FAILED for r in runs) == 1  # the deliberate OOM example
    assert remove_demo_runs(repo) == n and repo.count() == 0 and not has_demo_runs(repo)


def test_demo_runs_are_reproducible(repo, tmp_path):
    from voltix.db import RunRepository
    other = RunRepository(tmp_path / "other.db")
    seed_demo_runs(repo); seed_demo_runs(other)
    a = {r.name: r.metrics.throughput_tokens_per_s for r in repo.list() if r.metrics}
    b = {r.name: r.metrics.throughput_tokens_per_s for r in other.list() if r.metrics}
    assert a == b


def test_sysinfo_never_raises_and_has_expected_shape():
    info = collect_system_info()
    assert {"os", "python", "cpu_count", "gpu", "packages"} <= set(info)
    assert isinstance(info["gpu"]["available"], bool) and isinstance(info["gpu"]["gpus"], list)
    assert "streamlit" in info["packages"]
