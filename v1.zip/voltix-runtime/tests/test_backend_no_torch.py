"""Transformers backend behaviour that must hold on a machine WITHOUT torch, transformers or a GPU.

Nothing here imports torch. The CUDA classes are exercised against a FAKE torch.cuda object, which
checks our call sequence and unit arithmetic, not real GPU behaviour (untested on real hardware).
"""

import sys
from types import SimpleNamespace

import pytest

from tests.conftest import tf_config
from voltix.backends import BackendNotImplemented, BackendUnavailable, TransformersBackend, create_backend
from voltix.backends import transformers_backend as tb
from voltix.backends.devices import AcceleratorProbe, ResolvedDevice
from voltix.runner import run_benchmark
from voltix.schemas import Precision

NO_GPU = AcceleratorProbe(True, "2.9.0", "12.4", False, ())


def fake_cuda_torch(log):
    cuda = SimpleNamespace(
        synchronize=lambda i: log.append(("sync", i)),
        reset_peak_memory_stats=lambda i: log.append(("reset", i)),
        max_memory_allocated=lambda i: 12_500_000_000,
        get_device_properties=lambda i: SimpleNamespace(total_memory=24_000_000_000))
    return SimpleNamespace(cuda=cuda)


def test_make_accelerator_picks_by_device_kind():
    assert isinstance(tb.make_accelerator(SimpleNamespace(), ResolvedDevice("cpu")), tb.CpuAccelerator)
    cuda = tb.make_accelerator(fake_cuda_torch([]), ResolvedDevice("cuda", 2, "X", 24.0, (8, 0)))
    assert isinstance(cuda, tb.CudaAccelerator) and cuda.index == 2


def test_missing_dependencies_are_reported_with_install_hint(monkeypatch):
    monkeypatch.setattr(tb, "missing_dependencies", lambda: ["torch", "transformers"])
    st = TransformersBackend.status()
    assert st.implemented and not st.available and "requirements-hf.txt" in st.detail
    with pytest.raises(BackendUnavailable, match="cannot run here"):
        create_backend("transformers")


def test_missing_dependencies_create_no_run_and_never_fake_results(monkeypatch):
    monkeypatch.setattr(tb, "missing_dependencies", lambda: ["torch"])
    with pytest.raises(BackendUnavailable):
        run_benchmark(tf_config("org/model"))


def test_installed_but_broken_torch_is_unavailable_not_a_crash(monkeypatch):
    monkeypatch.setattr(tb, "missing_dependencies", lambda: [])
    monkeypatch.setitem(sys.modules, "torch", None)  # makes `import torch` raise ImportError
    with pytest.raises(BackendUnavailable, match="failed to import"):
        TransformersBackend().load(tf_config("org/model"))


def test_vllm_is_still_an_honest_placeholder():
    with pytest.raises(BackendNotImplemented):
        create_backend("vllm")


def test_preflight_reports_problems_without_loading_anything():
    gpu = AcceleratorProbe(True, "2.9.0", "12.4", True, ())
    assert TransformersBackend.preflight(tf_config("m/x", hardware_id="cuda:0"), NO_GPU)[0].startswith("CUDA device requested")
    assert TransformersBackend.preflight(tf_config("m/x", precision=Precision.FP16, hardware_id="cpu"), gpu)
    assert TransformersBackend.preflight(tf_config("m/x", hardware_id="cpu"), NO_GPU) == []


def test_oom_detection():
    class CudaOOM(RuntimeError):
        pass

    fake = SimpleNamespace(cuda=SimpleNamespace(OutOfMemoryError=CudaOOM))
    assert tb.is_oom(CudaOOM("x"), fake) and tb.is_oom(MemoryError(), fake)
    assert tb.is_oom(RuntimeError("CUDA out of memory. Tried to allocate"), fake)
    assert not tb.is_oom(ValueError("shape mismatch"), fake)


def test_cuda_accelerator_calls_and_units():
    log = []
    acc = tb.CudaAccelerator(fake_cuda_torch(log), 1)
    acc.reset_peak()
    acc.sync()
    assert log == [("reset", 1), ("sync", 1)]
    assert acc.peak_memory_gb() == pytest.approx(12.5) and acc.total_memory_gb() == pytest.approx(24.0)
    assert acc.memory_kind == "cuda_max_memory_allocated" and "excludes CUDA context" in acc.memory_scope()


def test_cpu_accelerator_describes_its_memory_scope_honestly():
    acc = tb.CpuAccelerator()
    acc.peak_is_scoped = False
    assert "whole process over its entire lifetime" in acc.memory_scope()
    acc.peak_is_scoped = True
    assert "WHOLE process" in acc.memory_scope() and "already resident" in acc.memory_scope()
    assert acc.sync() is None


def test_version_parsing_for_dtype_keyword():
    assert tb._version_tuple("5.20.1") == (5, 20) and tb._version_tuple("4.56.0.dev0") == (4, 56)
    assert tb._version_tuple("4.9.2") < tb.DTYPE_KWARG_MIN_VERSION <= tb._version_tuple("4.56.0")
    assert tb._version_tuple(None) == (0, 0) and tb._version_tuple("garbage") == (0, 0)
