"""Device logic and host-memory helpers. Pure: no GPU, no torch import needed."""

from types import SimpleNamespace

import pytest

from voltix import hostmem
from voltix.backends.devices import (
    AcceleratorProbe,
    CudaDevice,
    DeviceUnavailable,
    ResolvedDevice,
    UnsupportedConfiguration,
    check_precision,
    is_valid_device_request,
    probe_from_torch,
    resolve_device,
)
from voltix.schemas import Precision


def fake_torch(gpus=(), cuda_build="12.4", available=None, broken=False):
    props = [SimpleNamespace(name=n, total_memory=int(gb * 1e9), major=a, minor=b) for n, gb, a, b in gpus]

    def boom(*_a):
        raise RuntimeError("driver exploded")

    cuda = SimpleNamespace(
        is_available=boom if broken else (lambda: bool(props) if available is None else available),
        device_count=lambda: len(props), get_device_properties=lambda i: props[i])
    return SimpleNamespace(__version__="2.9.0", version=SimpleNamespace(cuda=cuda_build), cuda=cuda)


A100 = ("NVIDIA A100", 80, 8, 0)
T4 = ("Tesla T4", 15, 7, 5)


def test_probe_reads_devices_and_capabilities():
    probe = probe_from_torch(fake_torch([A100, T4]))
    assert probe.cuda_available and [d.name for d in probe.devices] == ["NVIDIA A100", "Tesla T4"]
    assert probe.devices[0].bf16_supported and not probe.devices[1].bf16_supported
    assert probe.devices[0].total_gb == pytest.approx(80.0)
    assert probe.to_dict()["devices"][1]["compute_capability"] == "7.5"


def test_probe_on_cpu_only_build_and_broken_driver():
    cpu = probe_from_torch(fake_torch([], cuda_build=None))
    assert cpu.torch_installed and not cpu.cuda_available and cpu.devices == () and cpu.error is None
    broken = probe_from_torch(fake_torch(broken=True))
    assert not broken.cuda_available and "driver exploded" in broken.error


def test_device_request_validation():
    for ok in (None, "auto", "cpu", "cuda", "cuda:0", "cuda:3"):
        assert is_valid_device_request(ok)
    for bad in ("gpu", "cuda:", "cuda:x", "CPU ", ""):
        assert not is_valid_device_request(bad)


def test_auto_picks_gpu_when_present_else_cpu():
    gpu = resolve_device("auto", probe_from_torch(fake_torch([A100])))
    assert (gpu.kind, gpu.index, gpu.hardware_id) == ("cuda", 0, "cuda:0") and gpu.name == "NVIDIA A100"
    assert resolve_device(None, probe_from_torch(fake_torch([]))).hardware_id == "cpu"
    assert resolve_device("cpu", probe_from_torch(fake_torch([A100]))).hardware_id == "cpu"


def test_explicit_cuda_without_gpu_is_refused_honestly():
    with pytest.raises(DeviceUnavailable) as e:
        resolve_device("cuda", probe_from_torch(fake_torch([], cuda_build="12.4")))
    assert "none is available" in str(e.value) and "12.4" in str(e.value)
    with pytest.raises(DeviceUnavailable) as e:
        resolve_device("cuda:0", AcceleratorProbe(True, "2.9.0", None, False))
    assert "without CUDA support" in str(e.value)
    with pytest.raises(DeviceUnavailable) as e:
        resolve_device("cuda:0", probe_from_torch(fake_torch(broken=True)))
    assert "driver exploded" in str(e.value)


def test_missing_gpu_index_lists_what_exists():
    with pytest.raises(DeviceUnavailable) as e:
        resolve_device("cuda:3", probe_from_torch(fake_torch([A100, T4])))
    assert "cuda:3 does not exist" in str(e.value) and "cuda:1 (Tesla T4)" in str(e.value)
    assert resolve_device("cuda:1", probe_from_torch(fake_torch([A100, T4]))).name == "Tesla T4"
    with pytest.raises(DeviceUnavailable):
        resolve_device("tpu", probe_from_torch(fake_torch([])))


def test_precision_support_matrix():
    cpu = ResolvedDevice("cpu")
    ampere = ResolvedDevice("cuda", 0, "A100", 80.0, (8, 0))
    turing = ResolvedDevice("cuda", 0, "T4", 15.0, (7, 5))
    assert check_precision(Precision.FP32, cpu) == "float32" and check_precision(Precision.BF16, cpu) == "bfloat16"
    assert check_precision(Precision.FP16, ampere) == "float16" and check_precision(Precision.BF16, ampere) == "bfloat16"
    assert check_precision(Precision.FP16, turing) == "float16"
    with pytest.raises(UnsupportedConfiguration, match="fp16 is not supported on CPU"):
        check_precision(Precision.FP16, cpu)
    with pytest.raises(UnsupportedConfiguration, match=r"compute capability 8.0.*T4 is 7.5"):
        check_precision(Precision.BF16, turing)
    for q in (Precision.INT8, Precision.INT4):
        with pytest.raises(UnsupportedConfiguration, match="not supported"):
            check_precision(q, ampere)


def test_cuda_device_dataclass_helpers():
    d = CudaDevice(0, "X", 24_000_000_000, (9, 0))
    assert d.total_gb == 24.0 and d.bf16_supported


def test_hostmem_helpers_return_sane_values():
    assert (hostmem.total_ram_gb() or 1) > 0
    rss, peak = hostmem.current_rss_gb(), hostmem.peak_rss_gb()
    if rss is not None and peak is not None:
        assert 0 < rss <= peak * 1.5 + 0.05
    assert isinstance(hostmem.reset_peak_rss(), bool)
    assert hostmem.cpu_model_name()


def test_peak_rss_reset_scopes_the_peak():
    if not hostmem.reset_peak_rss():
        pytest.skip("peak RSS reset not supported on this OS")
    blob = bytearray(150 * 1024 * 1024)
    for i in range(0, len(blob), 4096):
        blob[i] = 1
    held = hostmem.peak_rss_gb()
    del blob
    hostmem.reset_peak_rss()
    assert hostmem.peak_rss_gb() < held - 0.1  # the 150 MB peak no longer counts
