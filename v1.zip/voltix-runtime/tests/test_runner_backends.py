import pytest

from voltix.backends import BackendNotImplemented, all_statuses, create_backend
from voltix.estimation import memory_breakdown
from voltix.catalog import MODELS
from voltix.runner import run_benchmark
from voltix.schemas import DataSource, Precision, RunStatus
from voltix.validation import ValidationError


def test_simulated_run_is_labelled_simulated(cfg):
    run = run_benchmark(cfg(), "demo")
    assert run.status == RunStatus.COMPLETED
    assert run.data_source == DataSource.SIMULATED and run.is_simulated
    assert run.environment["simulated"] is True
    assert len(run.samples) == 30 and run.metrics.iterations == 30
    assert run.metrics.throughput_tokens_per_s > 0


def test_same_seed_is_deterministic_and_different_seed_differs(cfg):
    a, b, c = run_benchmark(cfg(seed=1)), run_benchmark(cfg(seed=1)), run_benchmark(cfg(seed=2))
    assert [s.latency_ms for s in a.samples] == [s.latency_ms for s in b.samples]
    assert [s.latency_ms for s in a.samples] != [s.latency_ms for s in c.samples]


def test_progress_callback_reports_every_iteration(cfg):
    calls = []
    run_benchmark(cfg(iterations=5, warmup_iterations=2), progress=lambda d, t, l: calls.append((d, t, l)))
    assert calls[0] == (0, 7, "loading model")
    assert calls[-1][:2] == (7, 7) and len(calls) == 8
    assert [c[2] for c in calls[1:3]] == ["warmup", "warmup"]


def test_out_of_memory_produces_failed_run_not_exception(cfg):
    run = run_benchmark(cfg(batch_size=128, prompt_tokens=1024))
    assert run.status == RunStatus.FAILED and run.metrics is None and run.samples == []
    assert "out-of-memory" in run.error


def test_invalid_config_raises_validation_error(cfg):
    with pytest.raises(ValidationError):
        run_benchmark(cfg(batch_size=0))


def test_vllm_placeholder_refuses_to_run(cfg):
    with pytest.raises(BackendNotImplemented):
        run_benchmark(cfg(backend="vllm", hardware_id=None))
    with pytest.raises(BackendNotImplemented):
        create_backend("vllm")


def test_backend_statuses_are_honest():
    statuses = {s.key: s for s in all_statuses()}
    assert statuses["simulated"].implemented and statuses["simulated"].is_simulated
    assert statuses["transformers"].implemented and not statuses["transformers"].is_simulated
    assert not statuses["vllm"].implemented and not statuses["vllm"].available


def test_unknown_backend_key():
    with pytest.raises(KeyError):
        create_backend("does-not-exist")


def test_lower_precision_is_faster_and_smaller(cfg):
    fp16 = run_benchmark(cfg(batch_size=1, precision=Precision.FP16)).metrics
    int4 = run_benchmark(cfg(batch_size=1, precision=Precision.INT4)).metrics
    assert int4.throughput_tokens_per_s > fp16.throughput_tokens_per_s
    assert int4.peak_memory_gb < fp16.peak_memory_gb


def test_bigger_batch_raises_throughput_and_latency(cfg):
    small = run_benchmark(cfg(batch_size=1)).metrics
    big = run_benchmark(cfg(batch_size=16)).metrics
    assert big.throughput_tokens_per_s > small.throughput_tokens_per_s
    assert big.latency_p50_ms > small.latency_p50_ms


def test_faster_hardware_is_faster(cfg):
    a10 = run_benchmark(cfg(model_id="llama-3.1-8b", hardware_id="a10g-24gb")).metrics
    h100 = run_benchmark(cfg(model_id="llama-3.1-8b", hardware_id="h100-80gb")).metrics
    assert h100.throughput_tokens_per_s > a10.throughput_tokens_per_s


def test_memory_breakdown_arithmetic():
    b = memory_breakdown(MODELS["mistral-7b"], Precision.FP16, batch_size=1, prompt_tokens=100, output_tokens=0)
    assert b.weights_gb == pytest.approx(7.24 * 2)
    # KV per token = 2 * 32 layers * 8 kv heads * 128 head_dim * 2 bytes = 131072 bytes
    assert b.kv_cache_gb == pytest.approx(100 * 131072 / 1e9)
    assert b.total_gb == pytest.approx(b.weights_gb + b.kv_cache_gb + b.overhead_gb)
