"""Transformers backend logic that needs torch but no GPU and no model: timing with a scripted clock
and a stub model, and failure handling. Torch-free tests live in test_backend_no_torch.py."""

import sys
from types import SimpleNamespace

import pytest

pytest.importorskip("torch")
pytest.importorskip("transformers")
import torch  # noqa: E402

from tests.conftest import tf_config  # noqa: E402
from voltix.backends import BackendNotImplemented, BackendUnavailable, TransformersBackend, create_backend  # noqa: E402
from voltix.backends import transformers_backend as tb  # noqa: E402
from voltix.backends.base import BackendError  # noqa: E402
from voltix.backends.devices import AcceleratorProbe, ResolvedDevice  # noqa: E402
from voltix.runner import run_benchmark  # noqa: E402
from voltix.schemas import DataSource, Precision, RunStatus  # noqa: E402


# ---- failures become recorded, explained runs ------------------------------------

NO_GPU = AcceleratorProbe(True, "2.9.0", "12.4", False, ())


def test_cuda_requested_without_gpu_is_a_failed_run_with_reason(monkeypatch):
    monkeypatch.setattr(tb, "probe_from_torch", lambda _t: NO_GPU)
    run = run_benchmark(tf_config("org/model", hardware_id="cuda:0"))
    assert run.status == RunStatus.FAILED and run.metrics is None and run.samples == []
    assert "none is available" in run.error and run.data_source == DataSource.MEASURED


def test_fp16_on_cpu_is_refused_with_reason(monkeypatch):
    monkeypatch.setattr(tb, "probe_from_torch", lambda _t: NO_GPU)
    run = run_benchmark(tf_config("org/model", precision=Precision.FP16, hardware_id="cpu"))
    assert run.status == RunStatus.FAILED and "fp16 is not supported on CPU" in run.error
    assert "kernels are missing" not in run.error  # the stated reason must not overclaim


def test_rejected_runs_still_record_what_hardware_was_found(monkeypatch):
    """A run refused for unsupported hardware is exactly when the hardware record matters."""
    monkeypatch.setattr(tb, "probe_from_torch", lambda _t: NO_GPU)
    run = run_benchmark(tf_config("org/model", hardware_id="cuda"))
    env = run.environment
    assert run.status == RunStatus.FAILED and env["requested_hardware_id"] == "cuda"
    assert env["software"]["torch"] and env["software"]["transformers"] and env["host"]["cpu_count"]
    assert env["accelerators"]["cuda_available"] is False and env["accelerators"]["devices"] == []
    assert env["simulated"] is False and "device" not in env  # no device was ever selected


def test_bf16_on_pre_ampere_gpu_is_refused_and_the_gpu_is_recorded(monkeypatch):
    from voltix.backends.devices import CudaDevice

    t4 = AcceleratorProbe(True, "2.9.0", "12.4", True, (CudaDevice(0, "Tesla T4", 15_700_000_000, (7, 5)),))
    monkeypatch.setattr(tb, "probe_from_torch", lambda _t: t4)
    run = run_benchmark(tf_config("org/model", precision=Precision.BF16, hardware_id="cuda"))
    assert run.status == RunStatus.FAILED and "compute capability 8.0" in run.error and "Tesla T4" in run.error
    gpu = run.environment["accelerators"]["devices"][0]
    assert gpu["name"] == "Tesla T4" and gpu["compute_capability"] == "7.5" and gpu["bf16_native"] is False


# ---- timing logic with a scripted clock and a stub model ---------------------------

class StubModel:
    """Calls the stopping criteria once per generated token, like transformers does."""

    def __init__(self, tokens_out=None, call_criteria=True):
        self.tokens_out, self.call_criteria = tokens_out, call_criteria

    def generate(self, input_ids, attention_mask, max_new_tokens, stopping_criteria, **kw):
        n = self.tokens_out if self.tokens_out is not None else max_new_tokens
        if self.call_criteria:
            for t in range(n):
                stopping_criteria[0](torch.zeros((input_ids.shape[0], input_ids.shape[1] + t + 1), dtype=torch.long), None)
        return torch.zeros((input_ids.shape[0], input_ids.shape[1] + n), dtype=torch.long)


class RecordingAccel(tb.CpuAccelerator):
    def __init__(self, events):
        super().__init__()
        self.events = events

    def sync(self):
        self.events.append("sync")


def stubbed_backend(model, events, clock_values, monkeypatch):
    be = TransformersBackend()
    be._import_stack()
    be._model, be._accel = model, RecordingAccel(events)
    be._input_ids = torch.zeros((2, 5), dtype=torch.long)
    be._attention_mask = torch.ones_like(be._input_ids)
    be._timer_cls = be._make_timer_class()
    it = iter(clock_values)

    def clock():
        events.append("clock")
        return next(it)

    monkeypatch.setattr(tb.time, "perf_counter", clock)
    return be


def test_ttft_and_latency_come_from_the_right_timestamps(monkeypatch):
    events = []
    be = stubbed_backend(StubModel(), events, [100.000, 100.012, 100.080], monkeypatch)
    s = be.run_iteration(tf_config("m", output_tokens=6, batch_size=2), 3)
    assert s.ttft_ms == pytest.approx(12.0) and s.latency_ms == pytest.approx(80.0)
    assert (s.index, s.batch_size, s.output_tokens_per_seq) == (3, 2, 6)


def test_cuda_style_synchronization_surrounds_every_timestamp(monkeypatch):
    events = []
    be = stubbed_backend(StubModel(), events, [0.0, 0.01, 0.05], monkeypatch)
    be.run_iteration(tf_config("m", output_tokens=4), 0)
    # sync before t0, sync before the first-token stamp (once, not per token), sync before t1
    assert events == ["sync", "clock", "sync", "clock", "sync", "clock"]


def test_wrong_token_count_invalidates_the_measurement(monkeypatch):
    be = stubbed_backend(StubModel(tokens_out=3), [], [0.0, 0.01, 0.05], monkeypatch)
    with pytest.raises(BackendError, match="generated 3 tokens"):
        be.run_iteration(tf_config("m", output_tokens=6), 0)


def test_unobservable_first_token_is_an_error_not_a_guess(monkeypatch):
    be = stubbed_backend(StubModel(call_criteria=False), [], [0.0, 0.05], monkeypatch)
    with pytest.raises(BackendError, match="first generated token"):
        be.run_iteration(tf_config("m", output_tokens=4), 0)


def test_ttft_never_exceeds_latency(monkeypatch):
    be = stubbed_backend(StubModel(), [], [0.0, 0.2, 0.1], monkeypatch)  # pathological clock
    s = be.run_iteration(tf_config("m", output_tokens=2), 0)
    assert s.ttft_ms <= s.latency_ms


def test_generation_exceptions_become_backend_errors(monkeypatch):
    class Exploding:
        def generate(self, **kw):
            raise RuntimeError("CUDA out of memory. Tried to allocate 2 GiB")

    be = stubbed_backend(Exploding(), [], [0.0, 1.0], monkeypatch)
    with pytest.raises(BackendError, match="Out of memory during generation"):
        be.run_iteration(tf_config("m"), 0)

    class Broken:
        def generate(self, **kw):
            raise ValueError("bad shapes")

    be = stubbed_backend(Broken(), [], [0.0, 1.0], monkeypatch)
    with pytest.raises(BackendError, match=r"Generation failed \(ValueError\)"):
        be.run_iteration(tf_config("m"), 0)


def test_run_iteration_requires_load():
    with pytest.raises(BackendError, match="not loaded"):
        TransformersBackend().run_iteration(tf_config("m"), 0)


def test_version_parsing_for_dtype_keyword():
    assert tb._version_tuple("5.20.1") == (5, 20) and tb._version_tuple("4.56.0.dev0") == (4, 56)
    assert tb._version_tuple("4.9.2") < tb.DTYPE_KWARG_MIN_VERSION <= tb._version_tuple("4.56.0")
    assert tb._version_tuple(None) == (0, 0) and tb._version_tuple("garbage") == (0, 0)
