"""Work package 1: the importer must reject every damaged, contradictory or out-of-range file with a
specific message, accept every file VOLTIX itself exports, and never relabel data."""

import copy
import json

import pytest

from tests.phase3_helpers import measured_run
from voltix.db import RunRepository
from voltix.demo import seed_demo_runs
from voltix.exports import run_to_json
from voltix.importer import ImportRejected, import_run_with_warnings, parse_run, parse_run_with_warnings

BASE = json.loads(run_to_json(measured_run("base", 100.0, n=10, seed=3), []))


def edit(fn, allow_nan=False):
    d = copy.deepcopy(BASE)
    fn(d["run"])
    return json.dumps(d, allow_nan=allow_nan)


def setc(**kw):
    return lambda r: r["config"].update(kw)


def setr(**kw):
    return lambda r: r.update(kw)


def sets(i, **kw):
    return lambda r: r["samples"][i].update(kw)


def setm(**kw):
    return lambda r: r["metrics"].update(kw)


def failed(**kw):
    def f(r):
        r.update(status="failed", samples=[], metrics=None, error="boom")
        r.update(kw)
    return f


REJECTED = [  # (description, mutation, text that must appear in the message)
    ("zero batch size", setc(batch_size=0), "Batch size must be between"),
    ("negative batch size", setc(batch_size=-4), "Batch size must be between"),
    ("absurd batch size", setc(batch_size=10**9), "Batch size must be between"),
    ("zero output tokens", setc(output_tokens=0), "Output tokens must be between"),
    ("absurd iterations", setc(iterations=10**7), "Iterations must be between"),
    ("absurd warmup", setc(warmup_iterations=10**6), "Warmup iterations must be between"),
    ("negative seed", setc(seed=-1), "Seed must be between"),
    ("float batch size", setc(batch_size=2.5), "whole number"),
    ("bool batch size", setc(batch_size=True), "whole number"),
    ("iterations disagree with samples", setc(iterations=11), "samples but the run says"),
    ("sample latency as text", sets(0, latency_ms="100"), "not a number"),
    ("sample latency null", sets(0, latency_ms=None), "not a number"),
    ("sample latency bool", sets(0, latency_ms=True), "not a number"),
    ("sample latency negative", sets(0, latency_ms=-5), "non-positive"),
    ("sample ttft above latency", sets(0, ttft_ms=1e9), "ttft must be within"),
    ("sample batch differs from config", sets(0, batch_size=2), "batch size differs"),
    ("sample tokens differ from config", sets(0, output_tokens_per_seq=1), "output-token count differs"),
    ("sample missing field", lambda r: r["samples"][0].pop("ttft_ms"), "'ttft_ms' is missing"),
    ("duplicate sample indexes", lambda r: [s.update(index=0) for s in r["samples"]], "Sample indexes"),
    ("metric edited", setm(throughput_tokens_per_s=99999.0), "does not match"),
    ("metrics in a different unit", lambda r: [r["samples"][i].update(latency_ms=r["samples"][i]["latency_ms"] / 1000,
                                                                       ttft_ms=r["samples"][i]["ttft_ms"] / 1000) for i in range(10)], "does not match"),
    ("negative peak memory", setm(peak_memory_gb=-3.0), "not a valid amount"),
    ("peak memory above device total", setm(peak_memory_gb=1e6), "exceeds the device"),
    ("metric is text", setm(peak_memory_gb="1.0"), "must be a number"),
    ("unknown precision", setc(precision="int3"), "not a valid Precision"),
    ("int8 on a measured run", setc(precision="int8"), "cannot have precision int8"),
    ("unknown status", setr(status="weird"), "not a valid RunStatus"),
    ("unparseable date", setr(created_at="yesterday"), "valid ISO-8601"),
    ("date in the future", setr(created_at="2999-01-01T00:00:00+00:00"), "in the future"),
    ("run id with path characters", setr(run_id="../../etc/passwd"), "'run_id' must be"),
    ("empty run id", setr(run_id=""), "'run_id' must be"),
    ("huge run id", setr(run_id="a" * 10000), "'run_id' must be"),
    ("name not text", setr(name=12345), "'name' must be text"),
    ("tags not a list", setr(tags="abc"), "'tags' must be a list"),
    ("thousands of tags", setr(tags=[str(i) for i in range(10000)]), "'tags' must be a list"),
    ("environment not an object", setr(environment=[1, 2]), "'environment' must be an object"),
    ("measured run claims simulated environment", lambda r: r["environment"].update(simulated=True), "says it is simulated"),
    ("measured run without device kind", lambda r: r["environment"].pop("device_kind"), "environment record"),
    ("device setting contradicts device kind", setc(hardware_id="cuda:0"), "contradicts"),
    ("model id with control characters", setc(model_id="a\x00b"), "control characters"),
    ("model id 100k characters", setc(model_id="a" * 100000), "too long"),
    ("unknown device string", setc(hardware_id="<script>"), "Unknown device"),
    ("unknown backend", setr(backend="mystery"), "Unknown backend"),
    ("data source relabelled", setr(data_source="simulated"), "Inconsistent"),
    ("completed run without samples", setr(samples=[]), "samples"),
    ("completed run without metrics", setr(metrics=None), "samples and metrics"),
    ("completed run carrying an error", setr(error="x"), "must not carry an error"),
    ("failed run with samples and metrics", setr(status="failed", error="boom"), "must not contain samples"),
    ("failed run with no reason", failed(error=""), "must say why"),
    ("failed run with null reason", failed(error=None), "must say why"),
]


@pytest.mark.parametrize("why,mutation,expected", REJECTED, ids=[r[0] for r in REJECTED])
def test_bad_file_is_rejected_with_a_specific_message(why, mutation, expected):
    with pytest.raises(ImportRejected) as e:
        parse_run(edit(mutation))
    assert expected in str(e.value), str(e.value)


@pytest.mark.parametrize("value", [float("nan"), float("inf"), -float("inf")])
def test_non_finite_numbers_are_rejected(value):
    with pytest.raises(ImportRejected):
        parse_run(edit(sets(0, latency_ms=value), allow_nan=True))
    with pytest.raises(ImportRejected):
        parse_run(edit(setm(peak_memory_gb=value), allow_nan=True))


def test_error_messages_never_leak_python_internals():
    for _, mutation, _ in REJECTED:
        try:
            parse_run(edit(mutation))
        except ImportRejected as e:
            assert "Traceback" not in str(e) and "File \"" not in str(e)


def test_valid_failed_run_is_accepted_and_stays_failed():
    got = parse_run(edit(failed()))
    assert got.status.value == "failed" and got.metrics is None and got.error == "boom"


def test_missing_optional_values_are_handled():
    got = parse_run(edit(lambda r: r["metrics"].update(peak_memory_gb=None, memory_utilization=None)))
    assert got.metrics.peak_memory_gb is None
    got = parse_run(edit(lambda r: (r.pop("notes", None), r.pop("tags", None), r.pop("voltix_version", None))))
    assert got.tags == ["imported"] and got.notes == ""


def test_self_consistent_but_wrongly_scaled_values_raise_a_warning_not_silence():
    def to_seconds(r):
        for s in r["samples"]:
            s["latency_ms"] /= 100000
            s["ttft_ms"] /= 100000
        r["metrics"].update(latency_mean_ms=r["metrics"]["latency_mean_ms"] / 100000)
    # A consistent rescale of every metric is the one error the checks cannot prove wrong; it must at least warn.
    d = copy.deepcopy(BASE)
    from voltix.metrics import compute_metrics
    from voltix.schemas import RequestSample

    samples = [RequestSample.from_dict({**s, "latency_ms": s["latency_ms"] / 1e5, "ttft_ms": s["ttft_ms"] / 1e5}) for s in d["run"]["samples"]]
    d["run"]["samples"] = [s.to_dict() for s in samples]
    d["run"]["metrics"] = compute_metrics(samples, peak_memory_gb=d["run"]["metrics"]["peak_memory_gb"]).to_dict()
    result = parse_run_with_warnings(json.dumps(d))
    assert any("milliseconds" in w for w in result.warnings)


def test_every_simulated_and_measured_export_roundtrips(tmp_path):
    repo = RunRepository(tmp_path / "d.db")
    seed_demo_runs(repo)
    runs = repo.list(include_samples=True) + [measured_run("m", 90.0, seed=2)]
    for r in runs:
        got = parse_run(run_to_json(r, []))
        assert got.data_source == r.data_source and got.status == r.status
        assert (got.metrics is None) == (r.metrics is None)


def test_import_never_overwrites_or_relabels(tmp_path):
    repo = RunRepository(tmp_path / "x.db")
    r = measured_run("orig", 100.0)
    import_run_with_warnings(repo, run_to_json(r, []))
    changed = edit(setr(run_id=r.run_id, name="changed"))
    with pytest.raises(ImportRejected, match="already in your history"):
        import_run_with_warnings(repo, changed)
    assert repo.get(r.run_id).name == "orig" and repo.get(r.run_id).data_source.value == "measured"


def test_oversized_and_nested_files_are_rejected_not_crashed():
    with pytest.raises(ImportRejected, match="larger than"):
        parse_run(b"x" * (50 * 1024 * 1024 + 1))
    with pytest.raises(ImportRejected):
        parse_run("[" * 100000)
    with pytest.raises(ImportRejected):
        parse_run(b"\xff\xfe\x00bad")
