"""WP2: background job manager, Run Benchmark page flow, and CLI cancel/timeout behaviour."""

from __future__ import annotations

import time

import pytest

import run_real_benchmark as cli
from voltix.control import CancelToken, RunLimits
from voltix.jobs import JobBusy, JobManager
from voltix.schemas import BenchmarkConfig, Precision, RunStatus


def _sim(iterations=5, warmup=1) -> BenchmarkConfig:
    return BenchmarkConfig(model_id="llama-3.1-8b", precision=Precision.FP16, batch_size=1, prompt_tokens=64, output_tokens=16,
                           iterations=iterations, warmup_iterations=warmup, seed=1, backend="simulated", hardware_id="a100-80gb")


def _wait(job, timeout=30):
    end = time.time() + timeout
    while job.running and time.time() < end:
        time.sleep(0.02)
    assert not job.running, "job did not finish"


def test_job_completes_and_reports_progress():
    m = JobManager()
    job = m.start(_sim())
    _wait(job)
    s = job.snapshot()
    assert s.state == "finished" and s.run is not None and s.run.status == RunStatus.COMPLETED and s.error is None
    assert s.done == s.total == 6


def test_only_one_job_at_a_time(monkeypatch):
    import threading
    import voltix.jobs as jobs
    gate = threading.Event()
    real = jobs.run_benchmark

    def slow(config, name=None, **kw):
        gate.wait(10)
        return real(config, name, **kw)
    monkeypatch.setattr(jobs, "run_benchmark", slow)
    m = JobManager()
    job = m.start(_sim())
    try:
        assert job.running
        with pytest.raises(JobBusy):
            m.start(_sim())
    finally:
        gate.set()
        _wait(job)
    m.start(_sim())  # allowed again after the first one ended


def test_cancel_through_job():
    m = JobManager()
    job = m.start(_sim(iterations=1000, warmup=0), limits=RunLimits(None, None))
    job.cancel()
    _wait(job)
    s = job.snapshot()
    assert s.run is not None and s.run.status == RunStatus.CANCELLED and s.run.metrics is None and s.cancel_requested


def test_invalid_config_becomes_error_not_crash():
    m = JobManager()
    bad = _sim()
    bad.model_id = "no-such-model-profile"
    job = m.start(bad)
    _wait(job)
    s = job.snapshot()
    assert s.run is None and s.error


def test_unexpected_exception_is_reported(monkeypatch):
    import voltix.jobs as jobs

    def boom(*a, **k):
        raise RuntimeError("kaboom")
    monkeypatch.setattr(jobs, "run_benchmark", boom)
    m = JobManager()
    job = m.start(_sim())
    _wait(job)
    s = job.snapshot()
    assert s.run is None and "kaboom" in s.error and "RuntimeError" in s.error


def test_cli_limits_parsing():
    args = cli.build_parser().parse_args(["--model", "x", "--max-run-seconds", "0", "--max-iteration-seconds", "7"])
    lim = cli._limits(args)
    assert lim.max_run_seconds is None and lim.max_iteration_seconds == 7
    args = cli.build_parser().parse_args(["--model", "x"])
    assert cli._limits(args) == RunLimits.from_env()


def test_cli_rejects_negative_limit(capsys):
    assert cli.main(["--model", "x", "--max-run-seconds", "-5"]) == 2
    assert "Invalid limit" in capsys.readouterr().out


torch = pytest.importorskip("torch")
pytest.importorskip("transformers")


@pytest.fixture(scope="module")
def tiny(tmp_path_factory):
    from voltix.testmodel import create_tiny_model
    return str(create_tiny_model())


def _argv(model, tmp_path, *extra):
    return ["--model", model, "--device", "cpu", "--precision", "fp32", "--allow-cpu", "--batch-size", "1", "--prompt-tokens", "16",
            "--output-tokens", "8", "--iterations", "3", "--warmup", "1", "--out", str(tmp_path), *extra]


def test_cli_cancelled_returns_130_and_saves_nothing(tiny, tmp_path, capsys):
    tok = CancelToken()
    tok.cancel()
    assert cli.main(_argv(tiny, tmp_path), token=tok) == cli.EXIT_CANCELLED
    assert list(tmp_path.glob("*.json")) == []
    assert "Nothing was saved" in capsys.readouterr().out


def test_cli_timeout_returns_4_and_saves_nothing(tiny, tmp_path, capsys):
    assert cli.main(_argv(tiny, tmp_path, "--max-iteration-seconds", "0.0001")) == cli.EXIT_TIMED_OUT
    assert list(tmp_path.glob("*.json")) == []


def test_cli_normal_run_still_saves(tiny, tmp_path):
    assert cli.main(_argv(tiny, tmp_path)) == 0
    assert len(list(tmp_path.glob("*.json"))) == 1
