"""WP6: pilot material is consistent with the product and makes no unsupported promises."""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from voltix.importer import parse_run
from voltix.schemas import DataSource, RunStatus

ROOT = Path(__file__).resolve().parent.parent
PILOT = ROOT / "pilot"
DOCS = ["DEMO_SCRIPT.md", "FEEDBACK_QUESTIONNAIRE.md", "KNOWN_LIMITATIONS.md", "ONBOARDING_GUIDE.md", "PILOT_SCOPE_DRAFT.md"]


def test_all_pilot_documents_exist_and_are_not_empty():
    for name in DOCS:
        assert len((PILOT / name).read_text(encoding="utf-8").split()) > 100, name


@pytest.mark.parametrize("path", sorted((PILOT / "sample_report").glob("run_*.json")), ids=lambda p: p.name)
def test_sample_report_runs_import_as_real_measurements(path):
    run = parse_run(path.read_bytes())
    assert run.data_source == DataSource.MEASURED and run.status == RunStatus.COMPLETED
    assert run.environment["device_kind"] in ("cpu", "cuda") and "procedure" in run.environment


def test_sample_report_says_what_it_is_not():
    text = (PILOT / "sample_report" / "README.md").read_text(encoding="utf-8").lower()
    assert "random-weight" in text and "nothing" in text and "real model" in text


PROMISE = re.compile(r"\b(guarantee[sd]?|certified|soc ?2|iso 27001|hipaa|gdpr|testimonial|production[- ]ready|save[sd]? you|\d+ ?% (faster|cheaper|savings))\b", re.I)
NEGATION = re.compile(r"\b(no|not|never|without|nothing|none|nor|neither)\b", re.I)


def test_no_unsupported_promises_in_pilot_documents():
    offenders = []
    for name in DOCS:
        for n, line in enumerate((PILOT / name).read_text(encoding="utf-8").splitlines(), 1):
            if PROMISE.search(line) and not NEGATION.search(line):
                offenders.append(f"{name}:{n}: {line.strip()[:100]}")
    assert not offenders, offenders


def test_documents_reference_files_that_exist():
    text = " ".join((PILOT / n).read_text(encoding="utf-8") for n in DOCS)
    for ref in set(re.findall(r"`([A-Za-z_./]+\.(?:md|py|sh|bat|txt|ipynb))`", text)):
        candidates = [ROOT / ref, PILOT / ref]
        assert any(c.exists() for c in candidates), f"referenced but missing: {ref}"


def test_pilot_scope_makes_success_the_customers_and_promises_nothing():
    t = (PILOT / "PILOT_SCOPE_DRAFT.md").read_text(encoding="utf-8")
    assert "defined by the customer" in t and "no** commitment" in t.replace("**no**", "no**") or "makes **no** commitment" in t
    assert "not a contract" in t
