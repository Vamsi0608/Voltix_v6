import check_setup


def test_reports_missing_required_packages_with_the_fix(monkeypatch):
    monkeypatch.setattr(check_setup, "version", lambda pkg: None)
    rows = check_setup.check_required()
    assert all(status == check_setup.FAIL and "pip install -r requirements.txt" in msg for status, msg in rows)


def test_missing_torch_is_a_warning_not_a_failure(monkeypatch):
    monkeypatch.setattr(check_setup, "version", lambda pkg: None)
    (status, msg), = check_setup.check_optional()
    assert status == check_setup.WARN and "requirements-hf.txt" in msg


def test_unwritable_database_location_fails_with_the_env_var_hint(monkeypatch, tmp_path):
    blocker = tmp_path / "file"
    blocker.write_text("x")
    monkeypatch.setenv("VOLTIX_DB_PATH", str(blocker / "sub" / "x.db"))  # parent is a file: cannot be created
    status, msg = check_setup.check_database()
    assert status == check_setup.FAIL and "VOLTIX_DB_PATH" in msg


def test_main_exit_code_reflects_required_checks(monkeypatch, capsys):
    monkeypatch.setattr(check_setup, "check_port", lambda port=8501: (check_setup.OK, "port free"))
    assert check_setup.main() in (0, 1)
    monkeypatch.setattr(check_setup, "version", lambda pkg: None)
    assert check_setup.main() == 1
