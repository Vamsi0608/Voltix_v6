import math

import pytest

from voltix.metrics import compute_metrics, format_metric, pct_change, percentile
from voltix.schemas import RequestSample


def sample(i, latency, ttft=10.0, batch=2, out=11):
    return RequestSample(index=i, ttft_ms=ttft, latency_ms=latency, batch_size=batch, output_tokens_per_seq=out)


def test_percentile_matches_linear_interpolation():
    data = [10, 20, 30, 40, 50]
    assert percentile(data, 0) == 10
    assert percentile(data, 50) == 30
    assert percentile(data, 100) == 50
    assert percentile(data, 25) == 20
    assert percentile(data, 90) == pytest.approx(46.0)


def test_percentile_unsorted_and_single_value():
    assert percentile([5, 1, 3], 50) == 3
    assert percentile([42.0], 99) == 42.0


@pytest.mark.parametrize("bad_q", [-1, 101, float("nan")])
def test_percentile_rejects_bad_q(bad_q):
    with pytest.raises(ValueError):
        percentile([1, 2, 3], bad_q)


def test_percentile_rejects_empty():
    with pytest.raises(ValueError):
        percentile([], 50)


def test_compute_metrics_known_values():
    # 4 iterations of 1000 ms, batch 2, 11 tokens/seq -> 22 tokens each, 88 total over 4 s.
    m = compute_metrics([sample(i, 1000.0, ttft=100.0) for i in range(4)], peak_memory_gb=12.0, device_memory_gb=24.0)
    assert m.iterations == 4
    assert m.total_output_tokens == 88
    assert m.total_time_s == pytest.approx(4.0)
    assert m.throughput_tokens_per_s == pytest.approx(22.0)
    assert m.sequences_per_s == pytest.approx(2.0)
    assert m.latency_p50_ms == 1000.0 and m.latency_std_ms == 0.0
    assert m.tpot_mean_ms == pytest.approx((1000 - 100) / 10)
    assert m.memory_utilization == pytest.approx(0.5)


def test_compute_metrics_tail_percentiles_ordered():
    m = compute_metrics([sample(i, 100.0 + i) for i in range(100)])
    assert m.latency_min_ms <= m.latency_p50_ms <= m.latency_p95_ms <= m.latency_p99_ms <= m.latency_max_ms
    assert m.memory_utilization is None and m.peak_memory_gb is None


def test_compute_metrics_single_token_has_zero_tpot():
    m = compute_metrics([sample(0, 50.0, ttft=50.0, out=1)])
    assert m.tpot_mean_ms == 0.0


def test_compute_metrics_rejects_bad_samples():
    with pytest.raises(ValueError):
        compute_metrics([])
    with pytest.raises(ValueError):
        compute_metrics([sample(0, 0.0, ttft=0.0)])
    with pytest.raises(ValueError):
        compute_metrics([sample(0, math.inf)])
    with pytest.raises(ValueError):
        compute_metrics([sample(0, 10.0, ttft=20.0)])  # ttft > latency


def test_pct_change_and_format():
    assert pct_change(100, 150) == 50
    assert pct_change(200, 100) == -50
    assert pct_change(0, 5) is None and pct_change(None, 5) is None
    assert format_metric("memory_utilization", 0.456) == "45.6%"
    assert format_metric("throughput_tokens_per_s", 1234.5) == "1,234.5 tok/s"
    assert format_metric("throughput_tokens_per_s", None) == "n/a"
