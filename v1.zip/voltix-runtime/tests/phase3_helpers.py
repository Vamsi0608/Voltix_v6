"""Synthetic MEASURED runs with a known ground truth, for testing the analysis engine.

These are test fixtures only: they build BenchmarkRun objects from seeded random latencies so a test can
check that the engine recovers a known difference. They are never loaded into the app or shown to users.
"""

from __future__ import annotations

import random
import uuid

from voltix.metrics import compute_metrics
from voltix.schemas import (
    BenchmarkConfig,
    BenchmarkRun,
    DataSource,
    Precision,
    RequestSample,
    RunStatus,
)


def make_samples(mean_ms: float, n: int, *, batch: int = 1, out: int = 16, sigma: float = 0.04, seed: int = 0,
                 drift: float = 0.0) -> list[RequestSample]:
    rng = random.Random(seed)
    samples = []
    for i in range(n):
        lat = max(1.0, mean_ms * (1.0 + drift * i / max(n, 1)) * (1.0 + rng.gauss(0, sigma)))
        samples.append(RequestSample(index=i, ttft_ms=lat * 0.2, latency_ms=lat, batch_size=batch, output_tokens_per_seq=out))
    return samples


def measured_run(name: str, mean_ms: float, *, n: int = 40, batch: int = 1, precision: Precision = Precision.FP32,
                 seed: int = 0, sigma: float = 0.04, device: str = "Test CPU", kind: str = "cpu", warmup: int = 3,
                 model: str = "org/model", prompt: int = 32, out: int = 16, peak_gb: float | None = 1.0,
                 torch_version: str = "2.14.1", drift: float = 0.0, created: str | None = None) -> BenchmarkRun:
    cfg = BenchmarkConfig(model_id=model, precision=precision, batch_size=batch, prompt_tokens=prompt, output_tokens=out,
                          iterations=n, warmup_iterations=warmup, seed=seed, backend="transformers", hardware_id=kind)
    samples = make_samples(mean_ms, n, batch=batch, out=out, sigma=sigma, seed=seed, drift=drift)
    gpu = kind == "cuda"
    env = {
        "backend": "transformers", "simulated": False, "device_kind": kind,
        "device": {"kind": kind, "name": device, "total_memory_gb": 24.0 if gpu else 8.0},
        "software": {"torch": torch_version, "transformers": "5.20.1", "python": "3.13"},
        "host": {"cpu_model": device, "cpu_count": 2, "torch_threads": 2},
        "model": {"id": model, "num_parameters": 1000, "commit_hash": None},
        "measurement": {"memory_kind": "cuda_max_memory_allocated" if gpu else "process_peak_rss"},
    }
    metrics = compute_metrics(samples, peak_memory_gb=peak_gb, device_memory_gb=24.0 if gpu else 8.0)
    return BenchmarkRun(
        run_id=f"run_{uuid.uuid4().hex[:10]}", name=name, created_at=created or "2026-10-20T10:00:00+00:00",
        status=RunStatus.COMPLETED, data_source=DataSource.MEASURED, backend="transformers", config=cfg,
        metrics=metrics, samples=samples, environment=env, voltix_version="test")
