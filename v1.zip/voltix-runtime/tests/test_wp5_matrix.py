"""WP5: the validation matrix judges rows correctly and never reports an unrunnable row as passed."""

from __future__ import annotations

import pytest

from tests.phase3_helpers import measured_run
from voltix import matrix
from voltix.schemas import Precision, RunStatus

ROW = matrix.Row("r", "cpu-tiny", "tiny", Precision.FP32, 1, 32, 16)


def test_identical_repeats_pass():
    a, b = measured_run("a", 100.0, seed=1), measured_run("b", 100.0, seed=2)
    res = matrix.judge([a, b], ROW)
    assert res.outcome == "PASS" and res.comparability == "replicate" and res.repeat_spread_pct < 15


def test_large_repeat_spread_fails():
    res = matrix.judge([measured_run("a", 100.0, seed=1), measured_run("b", 140.0, seed=2)], ROW)
    assert res.outcome == "FAIL" and "differs by" in res.detail


def test_incomplete_repeat_fails():
    b = measured_run("b", 100.0)
    b.status, b.metrics, b.error = RunStatus.FAILED, None, "boom"
    assert matrix.judge([measured_run("a", 100.0), b], ROW).outcome == "FAIL"


def test_changed_setup_between_repeats_is_not_a_replicate():
    res = matrix.judge([measured_run("a", 100.0, batch=1), measured_run("b", 100.0, batch=2)], ROW)
    assert res.outcome == "FAIL" and "replicate" in res.detail


def test_availability_reasons():
    torch = pytest.importorskip("torch")
    gpu = matrix.Row("g", "cuda", "m", Precision.FP16, 1, 8, 8)
    hub = matrix.Row("h", "hub-model", "org/m", Precision.FP32, 1, 8, 8)
    if not torch.cuda.is_available():
        assert "no CUDA GPU" in matrix.availability(gpu, "/x", lambda m: True)
    assert "not in the local cache" in matrix.availability(hub, "/x", lambda m: False)
    assert matrix.availability(hub, "/x", lambda m: True) is None
    assert matrix.availability(ROW, None, lambda m: False) is not None
    assert matrix.availability(ROW, "/x", lambda m: False) is None


def test_unrunnable_rows_are_not_run_not_passed(tmp_path):
    pytest.importorskip("torch")
    rows = [matrix.Row("h", "hub-model", "org/not-cached", Precision.FP32, 1, 8, 8)]
    res = matrix.run_matrix(rows, "/x", lambda m: False)
    assert res[0].outcome == "NOT RUN" and res[0].throughput is None
    md = matrix.to_markdown(res, "test")
    assert "0 executed" in md and "NOT RUN" in md and "PASS" not in md.split("| Row")[1]


def test_default_matrix_has_gpu_rows_that_need_a_gpu():
    rows = matrix.default_rows()
    assert any(r.needs == "cuda" for r in rows) and len({r.row_id for r in rows}) == len(rows)
