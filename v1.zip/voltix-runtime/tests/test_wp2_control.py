"""Work package 2: cooperative cancellation and time limits."""

import threading
import time

import pytest

import voltix.catalog as catalog
from voltix.control import CancelToken, RunAborted, RunGuard, RunLimits
from voltix.exports import run_to_json, run_to_markdown, runs_to_csv
from voltix.importer import ImportRejected, parse_run
from voltix.recommendations import recommend
from voltix.runner import run_benchmark
from voltix.schemas import BenchmarkConfig, Precision, RunStatus


def sim(**kw):
    d = dict(model_id=next(iter(catalog.MODELS)), precision=Precision.FP16, batch_size=2, prompt_tokens=64, output_tokens=32,
             iterations=30, warmup_iterations=3, seed=3, backend="simulated", hardware_id=next(iter(catalog.HARDWARE)))
    d.update(kw)
    return BenchmarkConfig(**d)


class Clock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


# ---------------------------------------------------------------- guard and limits

def test_guard_passes_when_nothing_is_wrong():
    RunGuard(CancelToken(), RunLimits())()


def test_guard_raises_cancelled_with_location_and_elapsed_time():
    clock, tok = Clock(), CancelToken()
    g = RunGuard(tok, RunLimits(), clock)
    g.begin_iteration("measured iteration 4 of 30")
    clock.t = 12.34
    tok.cancel()
    with pytest.raises(RunAborted) as e:
        g()
    assert e.value.kind == "cancelled" and "measured iteration 4 of 30" in e.value.reason and "12.3 s" in e.value.reason


def test_guard_enforces_the_run_limit_and_names_the_setting():
    clock = Clock()
    g = RunGuard(None, RunLimits(max_run_seconds=10, max_iteration_seconds=None), clock)
    clock.t = 10.0
    g()                                   # at the limit is still allowed
    clock.t = 10.01
    with pytest.raises(RunAborted) as e:
        g()
    assert e.value.kind == "timed_out" and "VOLTIX_MAX_RUN_SECONDS" in e.value.reason


def test_guard_enforces_the_iteration_limit_only_while_an_iteration_runs():
    clock = Clock()
    g = RunGuard(None, RunLimits(max_run_seconds=None, max_iteration_seconds=5), clock)
    clock.t = 100.0
    g()                                   # no iteration in progress: loading time is not an iteration
    g.begin_iteration("measured iteration 1 of 3")
    clock.t = 104.9
    g()
    clock.t = 105.1
    with pytest.raises(RunAborted) as e:
        g()
    assert e.value.kind == "timed_out" and "VOLTIX_MAX_ITERATION_SECONDS" in e.value.reason
    g.end_iteration()
    clock.t = 500.0
    g()


@pytest.mark.parametrize("bad", [0, -1, float("nan"), float("inf")])
def test_invalid_limits_are_refused(bad):
    with pytest.raises(ValueError):
        RunLimits(max_run_seconds=bad)
    with pytest.raises(ValueError):
        RunLimits(max_iteration_seconds=bad)


def test_limits_from_environment():
    assert RunLimits.from_env({}).max_run_seconds == 1800 and RunLimits.from_env({}).max_iteration_seconds == 300
    got = RunLimits.from_env({"VOLTIX_MAX_RUN_SECONDS": "60", "VOLTIX_MAX_ITERATION_SECONDS": "none"})
    assert got.max_run_seconds == 60 and got.max_iteration_seconds is None
    assert RunLimits.from_env({"VOLTIX_MAX_RUN_SECONDS": "0"}).max_run_seconds is None
    for bad in ("abc", "-5", "nan", "inf"):
        with pytest.raises(ValueError, match="VOLTIX_MAX_RUN_SECONDS"):
            RunLimits.from_env({"VOLTIX_MAX_RUN_SECONDS": bad})

# ---------------------------------------------------------------- runner (simulated backend)

def test_cancel_before_start_returns_a_cancelled_run_with_nothing_measured():
    tok = CancelToken()
    tok.cancel()
    r = run_benchmark(sim(), "c", cancel=tok)
    assert r.status == RunStatus.CANCELLED and r.metrics is None and r.samples == []
    assert "0 of 33 iterations" in r.error and "never compared" in r.error


def test_cancel_in_the_middle_reports_how_far_it_got():
    tok = CancelToken()
    seen = []

    def progress(done, total, label):
        seen.append((done, label))
        if done == 10:
            tok.cancel()

    r = run_benchmark(sim(), "mid", cancel=tok, progress=progress)
    assert r.status == RunStatus.CANCELLED and r.metrics is None and not r.samples
    assert "10 of 33 iterations" in r.error and "measured iteration 8 of 30" in r.error
    assert seen[-1][0] == 10                                    # nothing ran after the cancel


def test_run_limit_produces_timed_out_status():
    r = run_benchmark(sim(), "t", limits=RunLimits(max_run_seconds=1e-9, max_iteration_seconds=None))
    assert r.status == RunStatus.TIMED_OUT and r.metrics is None and "time limit" in r.error


def test_uncancelled_run_is_unchanged_by_the_guard():
    a = run_benchmark(sim(seed=5), "a")
    b = run_benchmark(sim(seed=5), "b", cancel=CancelToken(), limits=RunLimits(max_run_seconds=3600, max_iteration_seconds=60))
    assert a.status == b.status == RunStatus.COMPLETED
    assert [s.latency_ms for s in a.samples] == [s.latency_ms for s in b.samples]


def test_aborted_runs_are_exported_imported_and_advised_correctly():
    tok = CancelToken()
    tok.cancel()
    c = run_benchmark(sim(), "cancelled-run", cancel=tok)
    t = run_benchmark(sim(), "timeout-run", limits=RunLimits(max_run_seconds=1e-9))
    for r, status, rule in ((c, "cancelled", "run-cancelled"), (t, "timed_out", "run-timed-out")):
        recs = recommend(r)
        assert [x.rule_id for x in recs] == [rule] and recs[0].kind == "observation"
        back = parse_run(run_to_json(r, recs))
        assert back.status.value == status and back.metrics is None and back.samples == []
        assert status in runs_to_csv([r]) and f"Status: {status}" in run_to_markdown(r, recs)


def test_importer_refuses_an_aborted_run_that_claims_metrics():
    import json

    tok = CancelToken()
    tok.cancel()
    good = run_benchmark(sim(), "g")
    d = json.loads(run_to_json(good, []))
    d["run"]["status"] = "cancelled"
    d["run"]["error"] = "stopped"
    with pytest.raises(ImportRejected, match="cancelled run must not contain samples"):
        parse_run(json.dumps(d))
    d["run"].update(samples=[], metrics=None, error="")
    with pytest.raises(ImportRejected, match="must say why"):
        parse_run(json.dumps(d))


def test_aborted_runs_are_excluded_from_comparison_and_optimize():
    from tests.phase3_helpers import measured_run
    from voltix.optimize import build_study
    base = measured_run("base", 100.0, n=40, seed=1)
    other = measured_run("other", 80.0, n=40, seed=2, batch=2)
    dead = measured_run("dead", 90.0, n=40, seed=3, batch=4)
    dead.status, dead.samples, dead.metrics, dead.error = RunStatus.TIMED_OUT, [], None, "Stopped: time limit."
    study = build_study(base, [base, other, dead])
    assert {a.candidate_id for a in study.analyses} == {other.run_id}

# ---------------------------------------------------------------- REAL backend (tiny model, CPU)

@pytest.fixture(scope="module")
def tiny(tmp_path_factory):
    pytest.importorskip("torch")
    pytest.importorskip("transformers")
    from voltix.testmodel import create_tiny_model
    return str(create_tiny_model(tmp_path_factory.mktemp("wp2model") / "tiny"))


def tf(model, **kw):
    d = dict(model_id=model, precision=Precision.FP32, batch_size=2, prompt_tokens=16, output_tokens=8, iterations=5,
             warmup_iterations=1, seed=11, backend="transformers", hardware_id="cpu")
    d.update(kw)
    return BenchmarkConfig(**d)


def test_real_run_is_cancelled_from_another_thread_within_seconds(tiny):
    tok = CancelToken()
    threading.Timer(0.5, tok.cancel).start()
    t0 = time.perf_counter()
    r = run_benchmark(tf(tiny, iterations=1000, output_tokens=64), "long", cancel=tok)
    took = time.perf_counter() - t0
    assert r.status == RunStatus.CANCELLED and r.metrics is None and not r.samples
    assert took < 15, took                                       # would take far longer to complete 1000 iterations
    assert r.environment.get("backend") == "transformers"        # what was known about the machine is still recorded


class CountingToken(CancelToken):
    """Becomes 'cancelled' on its Nth poll, so the test does not depend on timing."""

    def __init__(self, after):
        super().__init__()
        self.polls, self.after = 0, after

    @property
    def cancelled(self):
        self.polls += 1
        return self.polls > self.after


def test_real_cancel_takes_effect_at_the_next_token_inside_one_generation(tiny):
    tok = CountingToken(after=60)           # polls: 3 between-phase checks, then one per generated token
    r = run_benchmark(tf(tiny, batch_size=2, prompt_tokens=16, output_tokens=400, iterations=2, warmup_iterations=0), "mid-gen", cancel=tok)
    assert r.status == RunStatus.CANCELLED and "measured iteration 1 of 2" in r.error
    assert 61 <= tok.polls <= 62            # stopped immediately after the 61st poll: not at the end of the 400-token iteration


def test_real_iteration_time_limit_stops_generation(tiny):
    r = run_benchmark(tf(tiny, batch_size=8, prompt_tokens=64, output_tokens=400, iterations=3, warmup_iterations=0), "slow",
                      limits=RunLimits(max_run_seconds=None, max_iteration_seconds=0.001))
    assert r.status == RunStatus.TIMED_OUT and "one iteration exceeded" in r.error and r.metrics is None


def test_a_run_after_an_aborted_run_is_clean_and_unaffected(tiny):
    tok = CancelToken()
    tok.cancel()
    assert run_benchmark(tf(tiny), "x", cancel=tok).status == RunStatus.CANCELLED
    ok = run_benchmark(tf(tiny), "after")
    assert ok.status == RunStatus.COMPLETED and ok.metrics.iterations == 5 and ok.metrics.throughput_tokens_per_s > 0
    assert all(s.output_tokens_per_seq == 8 for s in ok.samples)
