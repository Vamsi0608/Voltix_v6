"""Optimize and Compare pages (headless AppTest) with synthetic measured runs and simulated demo runs."""

import pytest
from streamlit.testing.v1 import AppTest

from tests.phase3_helpers import measured_run
from voltix.db import RunRepository
from voltix.demo import seed_demo_runs
from voltix.schemas import Precision


@pytest.fixture
def db(tmp_path, monkeypatch):
    path = tmp_path / "opt.db"
    monkeypatch.setenv("VOLTIX_DB_PATH", str(path))
    return RunRepository(path)


def page(module: str) -> AppTest:
    return AppTest.from_string(f"from ui.pages import {module}\n{module}.render()", default_timeout=120)


def ok(at: AppTest) -> AppTest:
    assert not at.exception, [e.value for e in at.exception]
    return at


def text(at: AppTest) -> str:
    return " ".join([m.value for m in at.markdown] + [c.value for c in at.caption] + [w.value for w in at.warning]
                    + [i.value for i in at.info])


def test_empty_state_asks_for_runs(db):
    at = ok(page("optimize").run())
    assert any("at least two" in i.value for i in at.info)


def test_measured_findings_show_confidence_and_untested_settings(db):
    base = measured_run("b1-fp32", 100.0, seed=1)
    db.save(base)
    db.save(measured_run("b1-fp32 #2", 100.0, seed=2, created="2026-10-20T10:05:00+00:00"))
    db.save(measured_run("b1-bf16", 70.0, seed=3, precision=Precision.BF16, created="2026-10-20T10:10:00+00:00"))
    at = ok(page("optimize").run())
    t = text(at)
    assert not any("These runs are SIMULATED" in w.value for w in at.warning)
    assert "SIMULATED: NOT EVIDENCE" not in t
    assert "CONFIDENCE" in t and "Not yet measured" in t
    # price inputs exist only for measured baselines
    assert any(n.key and n.key.startswith("opt_price_") for n in at.number_input)
    assert not at.exception


def test_simulated_runs_are_labelled_not_evidence_and_have_no_price_inputs(db):
    seed_demo_runs(db)
    at = ok(page("optimize").run())
    t = text(at)
    assert "not evidence" in t.lower()
    assert not [n for n in at.number_input if n.key and n.key.startswith("opt_price_")]


def test_compare_page_shows_fairness_and_ci_wording(db):
    a = measured_run("a", 100.0, seed=1)
    b = measured_run("b", 70.0, seed=2, precision=Precision.BF16, created="2026-10-20T10:10:00+00:00")
    db.save(a)
    db.save(b)
    at = ok(page("compare_runs").run())
    t = text(at)
    assert "Is this a fair comparison?" in t and "95% CI" in t
