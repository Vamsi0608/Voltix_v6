"""Drive each page headlessly with Streamlit's AppTest against a temporary database."""

from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

APP = str(Path(__file__).resolve().parent.parent / "app.py")


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setenv("VOLTIX_DB_PATH", str(tmp_path / "ui.db"))


def page(module: str) -> AppTest:
    return AppTest.from_string(f"from ui.pages import {module}\n{module}.render()", default_timeout=60)


def clean(at: AppTest) -> AppTest:
    assert not at.exception, [e.value for e in at.exception]
    return at


def test_full_app_boots():
    at = AppTest.from_file(APP, default_timeout=60).run()
    clean(at)
    assert any("SIMULATED" in m.value for m in at.markdown) or at.button  # empty state or banner


def test_every_page_renders_empty():
    for module in ("overview", "run_benchmark", "compare_runs", "results", "history", "system_info"):
        clean(page(module).run())


def test_every_page_renders_with_demo_data():
    at = clean(page("overview").run())
    clean(at.button(key="ov_seed").click().run())
    for module in ("overview", "compare_runs", "results", "history", "system_info"):
        at = clean(page(module).run())
        assert any("SIMULATED" in m.value for m in at.markdown), f"{module} must label simulated data"


def test_compare_page_shows_charts_and_deltas():
    clean(page("overview").run().button(key="ov_seed").click().run())
    at = clean(page("compare_runs").run())
    assert len(at.get("plotly_chart")) == 4
    assert any("baseline" in m.value for m in at.markdown)


def test_run_save_workflow():
    at = clean(page("run_benchmark").run())
    at = at.button(key="rb_run").click().run()
    import time

    from voltix.jobs import manager
    end = time.time() + 60
    while manager().current().running and time.time() < end:
        time.sleep(0.05)
    at = clean(at.run())
    assert any("Result:" in m.value for m in at.markdown)
    assert any(b.key == "rb_save" for b in at.button)
    at = clean(at.button(key="rb_save").click().run())
    assert any("Saved to history" in s.value for s in at.success)
    history = clean(page("history").run())
    assert len(history.dataframe) >= 1  # the saved run is listed


def test_invalid_input_blocks_run():
    at = clean(page("run_benchmark").run())
    at.number_input(key="rb_prompt_simulated").set_value(8000).run()
    at.number_input(key="rb_out_simulated").set_value(1000).run()
    assert at.error and at.button(key="rb_run").disabled


def test_placeholder_backend_cannot_run():
    at = clean(page("run_benchmark").run())
    at.radio(key="rb_backend").set_value("vllm").run()
    clean(at)
    assert at.button(key="rb_run").disabled and any("placeholder" in w.value for w in at.warning)


def test_missing_dependencies_are_reported_in_the_ui(monkeypatch):
    from voltix.backends import transformers_backend as tb

    monkeypatch.setattr(tb, "missing_dependencies", lambda: ["torch", "transformers"])
    at = clean(page("run_benchmark").run())
    assert any("dependencies missing" in o for o in at.radio(key="rb_backend").options)
    clean(at.radio(key="rb_backend").set_value("transformers").run())
    assert any("requirements-hf.txt" in e.value for e in at.error)
    assert at.button(key="rb_run").disabled
