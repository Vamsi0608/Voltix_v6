"""WP3: access control, exposure policy, restricted mode, login brake, UI gate."""

from __future__ import annotations

import dataclasses
import os

import pytest
from streamlit.testing.v1 import AppTest

from voltix import security as sec
from voltix.schemas import BenchmarkConfig, Precision
from voltix.validation import validate_config

TOKEN = "correct-horse-battery-staple"


@pytest.mark.parametrize("addr,expected", [("127.0.0.1", True), ("::1", True), ("localhost", True), ("127.5.5.5", True),
                                           ("0.0.0.0", False), ("::", False), ("192.168.1.5", False), ("example.com", False),
                                           ("", False), (None, False), ("127.0.0.1.evil.com", False)])
def test_loopback_detection(addr, expected):
    assert sec.is_loopback_address(addr) is expected


def test_exposure_fails_closed():
    assert sec.exposure_problem("127.0.0.1", {}) is None
    assert "without an access token" in sec.exposure_problem("0.0.0.0", {})
    assert "without an access token" in sec.exposure_problem(None, {})
    assert sec.exposure_problem("0.0.0.0", {"VOLTIX_ACCESS_TOKEN": TOKEN}) is None
    assert "too short" in sec.exposure_problem("127.0.0.1", {"VOLTIX_ACCESS_TOKEN": "short"})
    assert "whitespace" in sec.exposure_problem("127.0.0.1", {"VOLTIX_ACCESS_TOKEN": " " + TOKEN})


def test_empty_token_is_not_a_token():
    assert sec.configured_token({"VOLTIX_ACCESS_TOKEN": ""}) is None
    assert sec.exposure_problem("0.0.0.0", {"VOLTIX_ACCESS_TOKEN": ""})  # still refused


def test_token_comparison():
    assert sec.tokens_match(TOKEN, TOKEN)
    assert not sec.tokens_match(TOKEN + "x", TOKEN) and not sec.tokens_match("", TOKEN) and not sec.tokens_match("é", TOKEN)


def test_limiter_blocks_after_five_failures_and_does_not_compare_while_blocked():
    now = [0.0]
    lim = sec.LoginLimiter(clock=lambda: now[0])
    for _ in range(4):
        assert lim.attempt("bad", TOKEN) == (False, 0.0)
    ok, wait = lim.attempt("bad", TOKEN)  # 5th failure starts the block
    assert not ok and wait > 0
    ok, wait = lim.attempt(TOKEN, TOKEN)  # even the right token is refused while blocked
    assert not ok and wait > 0
    now[0] += wait + 1
    assert lim.attempt(TOKEN, TOKEN)[0] is True
    assert lim.attempt("bad", TOKEN) == (False, 0.0)  # counter was reset by the success


def test_limiter_delay_grows_and_is_capped():
    now = [0.0]
    lim = sec.LoginLimiter(clock=lambda: now[0])
    waits = []
    for _ in range(30):
        now[0] += lim.wait_seconds() + 0.01
        waits.append(lim.attempt("bad", TOKEN)[1])
    assert max(waits) <= 900.001 and abs(waits[-1] - 900) < 0.001 and sorted(w for w in waits if w) == [w for w in sorted(waits) if w]


def _cfg(model, allow=False):
    return BenchmarkConfig(model_id=model, precision=Precision.FP32, batch_size=1, prompt_tokens=8, output_tokens=4, iterations=3,
                           warmup_iterations=1, seed=1, backend="transformers", hardware_id="cpu", allow_download=allow)


def test_restricted_mode_confines_models(tmp_path, monkeypatch):
    root = tmp_path / "models"
    (root / "ok").mkdir(parents=True)
    outside = tmp_path / "outside"
    outside.mkdir()
    (root / "link").symlink_to(outside)
    env = {"VOLTIX_ACCESS_TOKEN": TOKEN, "VOLTIX_MODEL_DIR": str(root)}
    assert sec.restricted_config_errors(str(root / "ok"), False, env) == []
    assert sec.restricted_config_errors(str(outside), False, env)
    assert sec.restricted_config_errors(str(root / "link"), False, env)  # symlink escape
    assert sec.restricted_config_errors(str(root / ".." / "outside"), False, env)  # dot-dot escape
    assert sec.restricted_config_errors("/etc", False, env)
    assert sec.restricted_config_errors("org/model", True, env)  # downloads off
    assert sec.restricted_config_errors("org/model", True, {**env, "VOLTIX_ALLOW_DOWNLOADS": "1"}) == []
    assert sec.restricted_config_errors("org/model", False, env) == []  # hub id, cache only
    assert sec.restricted_config_errors("/etc", True, {}) == []  # not restricted => unchanged behaviour


def test_validate_config_applies_restriction(tmp_path, monkeypatch):
    outside = tmp_path / "m"
    outside.mkdir()
    monkeypatch.setenv("VOLTIX_ACCESS_TOKEN", TOKEN)
    monkeypatch.setenv("VOLTIX_MODEL_DIR", str(tmp_path / "models"))
    assert any("inside the server's model folder" in e for e in validate_config(_cfg(str(outside))))
    monkeypatch.delenv("VOLTIX_ACCESS_TOKEN")
    assert not any("model folder" in e for e in validate_config(_cfg(str(outside))))


def _app() -> AppTest:
    return AppTest.from_file(str(__import__("pathlib").Path(__file__).resolve().parent.parent / "app.py"), default_timeout=60)


def test_gate_blocks_everything_until_token(monkeypatch, tmp_path):
    monkeypatch.setenv("VOLTIX_DB_PATH", str(tmp_path / "t.db"))
    monkeypatch.setenv("VOLTIX_ACCESS_TOKEN", TOKEN)
    at = _app().run()
    assert not at.exception
    text = " ".join(m.value for m in at.markdown) + " ".join(t.value for t in at.title)
    assert at.text_input(key="vx_token_input").proto.type == 1  # PASSWORD (masked)
    assert not [b for b in at.button if b.label in ("Run benchmark",)]
    # wrong token
    at.text_input(key="vx_token_input").set_value("wrong-token-wrong-token")
    at = at.run()
    at.get("form_submit_button")[0].click()
    at = at.run()
    assert any("not correct" in e.value for e in at.error) and TOKEN not in str(at)
    # right token
    at.text_input(key="vx_token_input").set_value(TOKEN)
    at.get("form_submit_button")[0].click()
    at = at.run()
    assert not at.exception and at.session_state["vx_authed"] is True


def test_gate_refuses_public_bind_without_token(monkeypatch, tmp_path):
    monkeypatch.setenv("VOLTIX_DB_PATH", str(tmp_path / "t.db"))
    monkeypatch.delenv("VOLTIX_ACCESS_TOKEN", raising=False)
    monkeypatch.setattr("streamlit.get_option", lambda k: "0.0.0.0" if k == "server.address" else None)
    at = _app().run()
    assert any("will not serve" in e.value for e in at.error)


def test_no_gate_on_default_local_setup(monkeypatch, tmp_path):
    monkeypatch.setenv("VOLTIX_DB_PATH", str(tmp_path / "t.db"))
    monkeypatch.delenv("VOLTIX_ACCESS_TOKEN", raising=False)
    at = _app().run()
    assert not at.exception and not at.error
