import pytest

from voltix.schemas import Precision
from voltix.validation import ValidationError, ensure_valid, sanitize_name, sanitize_notes, validate_config


def test_valid_config_has_no_errors(cfg):
    assert validate_config(cfg()) == []


@pytest.mark.parametrize("field,value", [
    ("batch_size", 0), ("batch_size", 257), ("prompt_tokens", 0), ("output_tokens", 5000),
    ("iterations", 0), ("iterations", 1001), ("warmup_iterations", -1), ("seed", -5),
])
def test_out_of_range_values_rejected(cfg, field, value):
    errors = validate_config(cfg(**{field: value}))
    assert errors, f"{field}={value} should be invalid"


def test_non_integer_rejected(cfg):
    assert validate_config(cfg(batch_size=2.5))
    assert validate_config(cfg(batch_size=True))


def test_context_window_checked(cfg):
    errors = validate_config(cfg(prompt_tokens=8000, output_tokens=1000))
    assert any("context window" in e for e in errors)


def test_unknown_model_and_hardware(cfg):
    assert any("Unknown model" in e for e in validate_config(cfg(model_id="nope")))
    assert any("Unknown hardware" in e for e in validate_config(cfg(hardware_id="nope")))
    assert any("needs a hardware" in e for e in validate_config(cfg(hardware_id=None)))


def test_multiple_errors_reported_together(cfg):
    errors = validate_config(cfg(batch_size=0, iterations=0))
    assert len(errors) >= 2
    with pytest.raises(ValidationError) as exc:
        ensure_valid(cfg(batch_size=0, iterations=0))
    assert len(exc.value.errors) >= 2


def test_sanitize_name_and_notes():
    assert sanitize_name("  hello \n world\x00 ") == "hello world"
    assert sanitize_name("   ", default="x") == "x"
    assert sanitize_name(None, default="x") == "x"
    assert len(sanitize_name("a" * 500)) == 80
    assert "\x07" not in sanitize_notes("bell\x07")
    assert len(sanitize_notes("a" * 10000)) == 5000


def test_precision_enum_values():
    assert {p.value for p in Precision} == {"fp32", "fp16", "bf16", "int8", "int4"}


# ---- Transformers backend validation -----------------------------------------

def tf_cfg(cfg, **kw):
    base = dict(backend="transformers", model_id="org/model", hardware_id="auto", precision=Precision.FP32, batch_size=1)
    base.update(kw)
    return cfg(**base)


def test_transformers_config_accepts_repo_ids_devices_and_local_dirs(cfg, tmp_path):
    for model in ("org/model", "gpt2", "Org-1/Model_2.v3", str(tmp_path)):
        assert validate_config(tf_cfg(cfg, model_id=model)) == [], model
    for device in (None, "auto", "cpu", "cuda", "cuda:0", "cuda:12"):
        assert validate_config(tf_cfg(cfg, hardware_id=device)) == [], device


@pytest.mark.parametrize("model", ["https://evil.example/x", "../escape", "/no/such/folder", "~/m", "a b", "a/b/c", "x\\y", "-bad", "bad\x07id"])
def test_transformers_rejects_bad_model_ids(cfg, model):
    assert validate_config(tf_cfg(cfg, model_id=model)), model


@pytest.mark.parametrize("device", ["gpu", "cuda:", "cuda:-1", "CUDA0", "tpu", ""])
def test_transformers_rejects_bad_devices(cfg, device):
    assert any("Device" in e for e in validate_config(tf_cfg(cfg, hardware_id=device)))


def test_transformers_rejects_quantized_precisions_and_allows_the_rest(cfg):
    for p in (Precision.INT8, Precision.INT4):
        assert any("not supported by the Transformers backend" in e for e in validate_config(tf_cfg(cfg, precision=p)))
    for p in (Precision.FP32, Precision.FP16, Precision.BF16):
        assert validate_config(tf_cfg(cfg, precision=p)) == []


def test_transformers_does_not_use_simulated_catalog_checks(cfg):
    # unknown-to-catalog models and large contexts are fine here; the real context limit is checked at load time
    assert validate_config(tf_cfg(cfg, model_id="someone/custom-model", prompt_tokens=30000, output_tokens=1000)) == []
    assert validate_config(tf_cfg(cfg, allow_download="yes"))
