import pytest

from voltix.db import RunRepository
from voltix.schemas import BenchmarkConfig, Precision


def make_config(**overrides) -> BenchmarkConfig:
    base = dict(
        model_id="mistral-7b", precision=Precision.FP16, batch_size=8, prompt_tokens=512, output_tokens=128,
        iterations=30, warmup_iterations=3, seed=7, backend="simulated", hardware_id="a10g-24gb",
    )
    base.update(overrides)
    return BenchmarkConfig(**base)


@pytest.fixture
def cfg():
    return make_config


@pytest.fixture
def repo(tmp_path):
    return RunRepository(tmp_path / "test.db")


def tf_config(model_id: str, **overrides) -> BenchmarkConfig:
    base = dict(model_id=model_id, precision=Precision.FP32, batch_size=2, prompt_tokens=32, output_tokens=8,
                iterations=5, warmup_iterations=1, seed=11, backend="transformers", hardware_id="cpu")
    base.update(overrides)
    return BenchmarkConfig(**base)


@pytest.fixture(autouse=True, scope="session")
def _test_log_file(tmp_path_factory):
    """Tests must not write into the project's real data/voltix.log."""
    import os

    os.environ["VOLTIX_LOG_FILE"] = str(tmp_path_factory.mktemp("logs") / "test.log")
    yield
