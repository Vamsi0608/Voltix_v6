"""REAL inference on CPU with a tiny, randomly initialised local model (no downloads, no GPU).

These prove the pipeline (load, generate, timing, memory, environment, storage, exports)
works for real. They say nothing about speed or quality of real models.
"""

import csv
import io
import json

import pytest

pytest.importorskip("torch")
pytest.importorskip("transformers")

from tests.conftest import tf_config  # noqa: E402
from voltix.backends import TransformersBackend  # noqa: E402
from voltix.compare import build_comparison, comparison_warnings  # noqa: E402
from voltix.exports import SIMULATED_BANNER, run_to_json, run_to_markdown, runs_to_csv  # noqa: E402
from voltix.recommendations import basis_disclaimer, recommend  # noqa: E402
from voltix.runner import run_benchmark  # noqa: E402
from voltix.schemas import DataSource, Precision, RunStatus  # noqa: E402
from voltix.testmodel import create_tiny_model  # noqa: E402


@pytest.fixture(scope="module")
def tiny(tmp_path_factory):
    return str(create_tiny_model(tmp_path_factory.mktemp("models") / "tiny"))


@pytest.fixture(scope="module")
def good_run(tiny):
    return run_benchmark(tf_config(tiny, iterations=8, warmup_iterations=2), "tiny real run")


def test_real_run_completes_and_is_labelled_measured(good_run, tiny):
    r = good_run
    assert r.status == RunStatus.COMPLETED, r.error
    assert r.data_source == DataSource.MEASURED and not r.is_simulated
    assert r.config.hardware_id == "cpu" and len(r.samples) == 8 and r.metrics.iterations == 8
    assert all(s.output_tokens_per_seq == 8 and s.batch_size == 2 for s in r.samples)
    assert all(0 < s.ttft_ms <= s.latency_ms for s in r.samples)


def test_metrics_are_consistent_with_the_samples(good_run):
    m, s = good_run.metrics, good_run.samples
    assert m.total_output_tokens == 8 * 2 * 8
    assert m.total_time_s == pytest.approx(sum(x.latency_ms for x in s) / 1000)
    assert m.throughput_tokens_per_s == pytest.approx(m.total_output_tokens / m.total_time_s)
    assert m.latency_p50_ms <= m.latency_p95_ms <= m.latency_p99_ms
    assert m.tpot_mean_ms > 0 and m.ttft_mean_ms < m.latency_mean_ms


def test_environment_records_hardware_software_model_and_method(good_run, tiny):
    e = good_run.environment
    assert e["simulated"] is False and e["backend"] == "transformers" and e["device_kind"] == "cpu"
    assert e["requested_hardware_id"] == "cpu" and e["device"]["name"] and e["host"]["cpu_count"] >= 1
    assert e["software"]["torch"] and e["software"]["transformers"] and e["software"]["python"]
    assert e["model"]["id"] == tiny and e["model"]["class"] == "LlamaForCausalLM"
    assert e["model"]["parameter_dtype"] == "float32" and e["model"]["num_parameters"] > 100_000
    assert e["model"]["trust_remote_code"] is False and e["model"]["downloads_allowed"] is False
    me = e["measurement"]
    assert "synthetic" in me["prompt"] and me["memory_kind"] == "process_peak_rss" and me["memory_unit"] == "GB = 10^9 bytes"
    assert me["memory_above_baseline_gb"] >= 0


def test_peak_memory_is_a_real_measurement(good_run):
    m = good_run.metrics
    assert m.peak_memory_gb and m.peak_memory_gb > 0.05 and 0 < m.memory_utilization < 1


def test_longer_generation_takes_longer_but_not_longer_to_first_token(tiny):
    short = run_benchmark(tf_config(tiny, output_tokens=4, iterations=6)).metrics
    long = run_benchmark(tf_config(tiny, output_tokens=64, iterations=6)).metrics
    assert long.latency_p50_ms > 3 * short.latency_p50_ms
    assert long.ttft_p50_ms < 3 * short.ttft_p50_ms + 5  # TTFT does not scale with output length


def test_prompts_are_seeded_and_avoid_special_tokens(tiny):
    def prompt(seed):
        be = TransformersBackend()
        be.load(tf_config(tiny, seed=seed))
        ids = be._input_ids.clone()
        be.unload()
        return ids

    a, b, c = prompt(5), prompt(5), prompt(6)
    assert a.equal(b) and not a.equal(c) and tuple(a.shape) == (2, 32)
    assert not ((a == 1) | (a == 2)).any()  # bos/eos of the tiny llama config


def test_bf16_on_cpu_really_loads_in_bf16(tiny):
    r = run_benchmark(tf_config(tiny, precision=Precision.BF16, iterations=3, warmup_iterations=1))
    assert r.status == RunStatus.COMPLETED, r.error
    assert r.environment["model"]["parameter_dtype"] == "bfloat16"


def test_context_overflow_is_a_failed_run_with_the_model_limit(tiny):
    r = run_benchmark(tf_config(tiny, prompt_tokens=500, output_tokens=100))
    assert r.status == RunStatus.FAILED and "512" in r.error and "context window" in r.error


def test_missing_model_explains_the_download_switch():
    r = run_benchmark(tf_config("definitely-not-a-real-org/missing-model-xyz"))
    assert r.status == RunStatus.FAILED and "not in the local Hugging Face cache" in r.error and "Allow downloading" in r.error


def test_unusable_folder_fails_cleanly(tmp_path):
    r = run_benchmark(tf_config(str(tmp_path)))  # exists but holds no model
    assert r.status == RunStatus.FAILED and "Could not load model" in r.error


def test_backend_can_be_reused_after_unload(tiny):
    be = TransformersBackend()
    be.load(tf_config(tiny))
    be.unload()
    be.load(tf_config(tiny))
    assert be.run_iteration(tf_config(tiny), 0).latency_ms > 0
    be.unload()


def test_storage_roundtrip_preserves_measured_provenance(repo, good_run):
    repo.save(good_run)
    loaded = repo.get(good_run.run_id)
    assert loaded.data_source == DataSource.MEASURED and loaded.environment == good_run.environment
    assert loaded.config.allow_download is False and loaded.to_dict() == good_run.to_dict()
    assert repo.list(data_source="measured")[0].run_id == good_run.run_id and repo.list(data_source="simulated") == []


def test_exports_describe_a_measured_run_correctly(good_run):
    recs = recommend(good_run)
    md = run_to_markdown(good_run, recs)
    assert "## Environment" in md and "device.name" in md and "software.torch" in md
    assert SIMULATED_BANNER not in md and "Simulated metrics" not in md and "measured" in md.lower()
    payload = json.loads(run_to_json(good_run, recs))
    assert payload["data_source"] == "measured" and payload["data_source_notice"] == "Measured on real hardware."
    row = list(csv.DictReader(io.StringIO(runs_to_csv([good_run]))))[0]
    assert row["data_source"] == "measured" and row["hardware_id"] == "cpu"


def test_recommendations_do_not_give_gpu_advice_for_cpu_runs(tiny):
    r = run_benchmark(tf_config(tiny, batch_size=1, iterations=25))
    ids = {x.rule_id for x in recommend(r)}
    assert "fp32-weights" not in ids and "unused-headroom" not in ids
    assert all(x.basis == "measured" for x in recommend(r))
    assert basis_disclaimer("measured") == "Based on measured data."


def test_mixing_measured_and_simulated_is_flagged(good_run, cfg):
    sim = run_benchmark(cfg(), "sim")
    warnings = comparison_warnings([good_run, sim])
    assert any("mix simulated and measured" in w for w in warnings)
    assert build_comparison([good_run, sim])  # still computable, just flagged
