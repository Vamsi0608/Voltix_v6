"""WP5: customer-defined requirements. Expected values are hand-computed, not read back from the code under test."""

from __future__ import annotations

import numpy as np
import pytest

from tests.phase3_helpers import measured_run
from voltix.constraints import Constraints, Eligibility, Verdict, constraint_recommendations, evaluate, select
from voltix.recommendations import recommend
from voltix.runner import run_benchmark
from voltix.schemas import BenchmarkConfig, Precision, RunStatus


def gpu_run(name, mean_ms, **kw):
    kw.setdefault("peak_gb", 10.0)
    return measured_run(name, mean_ms, kind="cuda", device="Test GPU", **kw)


def p95(run):
    return float(np.percentile([s.latency_ms for s in run.samples], 95))


def test_invalid_constraints_rejected():
    for bad in (0, -1, float("nan"), float("inf"), True, "5"):
        with pytest.raises(ValueError):
            Constraints(max_latency_p95_ms=bad)
    assert Constraints().empty


def test_pass_and_fail_match_hand_calculation():
    r = gpu_run("a", 100.0, n=40)
    p = p95(r)
    ok = evaluate(r, Constraints(max_latency_p95_ms=p * 1.5))
    assert ok.eligibility == Eligibility.ELIGIBLE and ok.results[0].verdict == Verdict.PASS
    bad = evaluate(r, Constraints(max_latency_p95_ms=p * 0.5))
    assert bad.eligibility == Eligibility.VIOLATES and abs(bad.results[0].measured - p) < 1e-6


def test_boundary_equal_to_limit_passes_and_is_marginal():
    r = gpu_run("a", 100.0, n=40)
    res = evaluate(r, Constraints(max_latency_p95_ms=p95(r))).results[0]
    assert res.verdict == Verdict.PASS and res.marginal
    assert evaluate(r, Constraints(max_latency_p95_ms=p95(r) * 0.999999)).results[0].verdict == Verdict.FAIL


def test_throughput_direction_is_minimum():
    r = gpu_run("a", 100.0, n=40, batch=2, out=16)  # 2*16 tokens per ~0.1 s = ~320 tok/s
    thr = r.metrics.throughput_tokens_per_s
    assert evaluate(r, Constraints(min_throughput_tokens_per_s=thr * 0.8)).eligibility == Eligibility.ELIGIBLE
    assert evaluate(r, Constraints(min_throughput_tokens_per_s=thr * 1.2)).eligibility == Eligibility.VIOLATES


def test_p95_not_assessed_with_too_few_iterations_never_eligible():
    r = gpu_run("short", 100.0, n=10)
    ev = evaluate(r, Constraints(max_latency_p95_ms=10_000))
    assert ev.results[0].verdict == Verdict.NOT_ASSESSED and "needs at least 20" in ev.results[0].reason
    assert ev.eligibility == Eligibility.UNKNOWN


def test_cpu_process_memory_is_never_compared_with_a_memory_limit():
    cpu = measured_run("cpu", 100.0, kind="cpu", peak_gb=3.0)
    res = evaluate(cpu, Constraints(max_memory_gb=100.0)).results[0]
    assert res.verdict == Verdict.NOT_ASSESSED and "whole Python process" in res.reason
    assert evaluate(gpu_run("g", 100.0, peak_gb=3.0), Constraints(max_memory_gb=4.0)).eligibility == Eligibility.ELIGIBLE
    assert evaluate(gpu_run("g", 100.0, peak_gb=5.0), Constraints(max_memory_gb=4.0)).eligibility == Eligibility.VIOLATES


def test_one_failing_limit_outweighs_passes_and_unknown_does_not_hide_a_failure():
    r = gpu_run("a", 100.0, n=10, peak_gb=9.0)  # p95 not assessable
    ev = evaluate(r, Constraints(max_latency_p95_ms=1000, max_memory_gb=5.0))
    assert ev.eligibility == Eligibility.VIOLATES


def test_failed_run_is_not_assessed():
    r = gpu_run("a", 100.0)
    r.status, r.metrics, r.samples = RunStatus.FAILED, None, []
    assert evaluate(r, Constraints(max_memory_gb=5)).eligibility == Eligibility.UNKNOWN


def test_select_picks_fastest_eligible_not_fastest_overall():
    fast_big = gpu_run("fast", 50.0, batch=8, peak_gb=30.0, seed=1)
    mid = gpu_run("mid", 80.0, batch=4, peak_gb=12.0, seed=2)
    slow_small = gpu_run("slow", 200.0, batch=1, peak_gb=6.0, seed=3)
    sel = select([fast_big, mid, slow_small], Constraints(max_memory_gb=15.0))
    assert len(sel) == 1
    assert sel[0].best.run.name == "mid"
    names = [e.run.name for e in sel[0].evaluations]
    assert names[:2] == ["mid", "slow"] or names[:2] == ["slow", "mid"]
    assert names[-1] == "fast" and sel[0].evaluations[-1].eligibility == Eligibility.VIOLATES
    assert sel[0].evaluations[0].run.name == "mid"  # higher throughput than slow among eligible


def test_select_none_eligible_says_so_without_overclaiming():
    sel = select([gpu_run("a", 100.0, peak_gb=30.0)], Constraints(max_memory_gb=10.0))[0]
    assert sel.best is None and "does not show that no configuration can" in sel.note


def test_select_never_mixes_sources_models_or_workloads():
    sim = run_benchmark(BenchmarkConfig(model_id="llama-3.1-8b", precision=Precision.FP16, batch_size=1, prompt_tokens=32,
                                        output_tokens=16, iterations=30, warmup_iterations=1, seed=1, backend="simulated",
                                        hardware_id="a100-80gb"))
    a = gpu_run("a", 100.0, model="org/m1")
    b = gpu_run("b", 90.0, model="org/m2")
    c = gpu_run("c", 90.0, model="org/m1", prompt=64)
    groups = select([sim, a, b, c], Constraints(min_throughput_tokens_per_s=1.0))
    assert len(groups) == 4
    simg = [g for g in groups if g.data_source == "simulated"][0]
    assert "SIMULATED" in simg.note and "illustrative" in simg.note
    for g in groups:
        assert len({(e.run.data_source, e.run.config.model_id, e.run.config.prompt_tokens) for e in g.evaluations}) == 1


def test_select_requires_a_requirement_and_valid_objective():
    with pytest.raises(ValueError):
        select([gpu_run("a", 100.0)], Constraints())
    with pytest.raises(ValueError):
        select([gpu_run("a", 100.0)], Constraints(max_memory_gb=1), objective="vibes")


def test_marginal_pass_is_disclosed_in_selection_note():
    r = gpu_run("a", 100.0, peak_gb=9.8)
    sel = select([r], Constraints(max_memory_gb=10.0))[0]
    assert sel.best is not None and "thin margin" in sel.note


def test_recommendations_report_violations_gaps_and_marginal():
    r = gpu_run("a", 100.0, n=10, peak_gb=9.8)
    ids = {x.rule_id for x in recommend(r, Constraints(max_latency_p95_ms=500, min_throughput_tokens_per_s=1e9, max_memory_gb=10.0))}
    assert {"requirement-violated", "requirement-not-assessed", "requirement-marginal"} <= ids
    assert not any(x.rule_id.startswith("requirement") for x in recommend(r))
    assert constraint_recommendations(r, Constraints()) == []
    for x in constraint_recommendations(r, Constraints(min_throughput_tokens_per_s=1e9)):
        assert "predicted" not in x.summary.lower() or "no change is predicted" in x.action


def test_select_ignores_runs_that_did_not_complete():
    good = gpu_run("good", 100.0)
    failed = gpu_run("failed", 50.0)
    failed.status, failed.metrics, failed.samples, failed.error = RunStatus.FAILED, None, [], "oom"
    cancelled = gpu_run("cancelled", 50.0)
    cancelled.status, cancelled.metrics, cancelled.samples = RunStatus.CANCELLED, None, []
    sel = select([failed, cancelled, good], Constraints(max_memory_gb=100.0))
    assert [e.run.name for e in sel[0].evaluations] == ["good"] and select([failed, cancelled], Constraints(max_memory_gb=1)) == []
