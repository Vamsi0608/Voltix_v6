"""Regression tests for problems found in the Phase 4 audit."""

import json
import re
import sqlite3

import pytest
from streamlit.testing.v1 import AppTest

import voltix.catalog as catalog
from tests.phase3_helpers import measured_run
from voltix.db import SCHEMA_VERSION, RunRepository, StorageError
from voltix.exports import run_to_markdown, runs_to_csv, study_to_markdown
from voltix.optimize import build_study
from voltix.runner import run_benchmark
from voltix.schemas import BenchmarkConfig, Precision


def sim_cfg(**kw):
    d = dict(model_id=next(iter(catalog.MODELS)), precision=Precision.FP16, batch_size=2, prompt_tokens=64, output_tokens=32,
             iterations=10, warmup_iterations=1, seed=3, backend="simulated", hardware_id=next(iter(catalog.HARDWARE)))
    d.update(kw)
    return BenchmarkConfig(**d)


def page(module):
    return AppTest.from_string(f"from ui.pages import {module}\n{module}.render()", default_timeout=120)


def corrupt(path, name):
    con = sqlite3.connect(path)
    con.execute("UPDATE runs SET config_json='{broken' WHERE name=?", (name,))
    con.commit()
    con.close()


@pytest.fixture
def db(tmp_path, monkeypatch):
    path = tmp_path / "a.db"
    monkeypatch.setenv("VOLTIX_DB_PATH", str(path))
    return RunRepository(path)


def test_one_damaged_row_does_not_hide_the_rest(db):
    for n in ("good-1", "bad", "good-2"):
        db.save(run_benchmark(sim_cfg(), n))
    corrupt(db.path, "bad")
    runs, problems = db.list_with_problems()
    assert sorted(r.name for r in runs) == ["good-1", "good-2"] and len(problems) == 1
    with pytest.raises(StorageError):
        db.list()  # strict callers still hear about it


@pytest.mark.parametrize("module", ["overview", "history", "results", "optimize", "compare_runs"])
def test_every_page_survives_a_damaged_row_and_says_so(db, module):
    for n in ("good-1", "bad", "good-2"):
        db.save(run_benchmark(sim_cfg(), n))
    corrupt(db.path, "bad")
    at = page(module).run()
    assert not at.exception, [e.value for e in at.exception]
    assert any("could not be read" in e.label for e in at.expander)


def test_damaged_rows_can_be_removed_from_the_ui(db):
    for n in ("good-1", "bad"):
        db.save(run_benchmark(sim_cfg(), n))
    corrupt(db.path, "bad")
    at = page("history").run()
    btn = next(b for b in at.button if b.label == "Remove unreadable runs")
    at = btn.click().run()
    assert not at.exception and db.count() == 1 and not db.list_with_problems()[1]


def test_database_from_a_newer_version_is_refused_and_untouched(tmp_path):
    path = tmp_path / "new.db"
    RunRepository(path)
    con = sqlite3.connect(path)
    con.execute(f"PRAGMA user_version={SCHEMA_VERSION + 6}")
    con.commit()
    con.close()
    with pytest.raises(StorageError, match="newer version"):
        RunRepository(path)
    con = sqlite3.connect(path)
    assert con.execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION + 6


def test_a_file_that_is_not_a_database_gives_actionable_guidance(tmp_path):
    path = tmp_path / "junk.db"
    path.write_text("this is not sqlite " * 100)
    with pytest.raises(StorageError) as e:
        RunRepository(path)
    assert "not a SQLite database" in str(e.value) and "VOLTIX_DB_PATH" in str(e.value)


HOSTILE = '|a|\n# Heading <script>alert(1)</script> [click](javascript:alert(1)) `x` *y*'


def test_markdown_exports_neutralise_hostile_run_names():
    r = run_benchmark(sim_cfg(), HOSTILE)
    md = run_to_markdown(r, [])
    assert "<script>" not in md and not re.search(r"(?<!\\)\]\(javascript", md)
    assert md.splitlines()[0].startswith("# VOLTIX Runtime report:") and "\n# Heading" not in md


def test_markdown_notes_cannot_inject_formatting():
    r = run_benchmark(sim_cfg(), "n")
    r.notes = "# Fake heading\n<img src=x onerror=alert(1)>"
    md = run_to_markdown(r, [])
    assert "~~~text" in md and md.index("~~~text") < md.index("<img")


def test_study_markdown_neutralises_names():
    a = measured_run(HOSTILE, 100.0, seed=1)
    b = measured_run("fine", 70.0, seed=2, precision=Precision.BF16)
    md = study_to_markdown(build_study(a, [a, b]), {a.run_id: a.name, b.run_id: b.name})
    assert "<script>" not in md and not re.search(r"(?<!\\)\]\(javascript", md)


@pytest.mark.parametrize("name", ["=HYPERLINK(\"http://x\")", "+1", "-1", "@SUM(1)", "\t=1"])
def test_csv_formula_injection_is_neutralised(name):
    r = run_benchmark(sim_cfg(), name)
    first_cell = runs_to_csv([r]).splitlines()[1]
    assert not first_cell.split(",")[1].lstrip('"').startswith(("=", "+", "-", "@"))


def test_json_export_round_trips_without_loss():
    from voltix.exports import run_to_json
    from voltix.schemas import BenchmarkRun

    r = run_benchmark(sim_cfg(), "rt")
    d = json.loads(run_to_json(r, []))
    back = BenchmarkRun.from_dict(d.get("run", d))
    assert back.metrics == r.metrics and back.config == r.config and len(back.samples) == len(r.samples)


def test_missing_dependency_message_says_where_and_how_to_install():
    from voltix.backends.transformers_backend import INSTALL_HINT

    assert "requirements-hf.txt" in INSTALL_HINT and "restart" in INSTALL_HINT
