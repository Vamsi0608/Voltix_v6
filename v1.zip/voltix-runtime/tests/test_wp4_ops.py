"""WP4: health check, backup/restore, logging."""

from __future__ import annotations

import json
import logging
import sqlite3

import pytest

from voltix import admin
from voltix.db import RunRepository, StorageError
from voltix.logging_setup import configure_logging
from voltix.runner import run_benchmark
from voltix.schemas import BenchmarkConfig, Precision


def _run():
    return run_benchmark(BenchmarkConfig(model_id="llama-3.1-8b", precision=Precision.FP16, batch_size=1, prompt_tokens=64,
                                         output_tokens=16, iterations=5, warmup_iterations=1, seed=1, backend="simulated",
                                         hardware_id="a100-80gb"))


@pytest.fixture
def db(tmp_path, monkeypatch):
    p = tmp_path / "v.db"
    monkeypatch.setenv("VOLTIX_DB_PATH", str(p))
    return p


def test_health_ok_counts_runs(db, capsys):
    repo = RunRepository()
    repo.save(_run())
    assert admin.main(["health"]) == 0
    rep = json.loads(capsys.readouterr().out)
    assert rep["healthy"] and "1 readable run" in rep["checks"]["database"]["detail"]


def test_health_fails_for_corrupt_database(db, capsys):
    db.write_bytes(b"this is not a database" * 50)
    assert admin.main(["health"]) == 1
    rep = json.loads(capsys.readouterr().out)
    assert not rep["healthy"] and not rep["checks"]["database"]["ok"]


def test_health_fails_for_weak_token(db, monkeypatch, capsys):
    monkeypatch.setenv("VOLTIX_ACCESS_TOKEN", "short")
    assert admin.main(["health"]) == 1
    assert "too short" in json.loads(capsys.readouterr().out)["checks"]["access_token"]["detail"]


def test_health_url_down_is_unhealthy(db, capsys):
    assert admin.main(["health", "--url", "http://127.0.0.1:1"]) == 1
    assert not json.loads(capsys.readouterr().out)["checks"]["web_server"]["ok"]


def test_backup_is_restorable_and_never_overwrites(db, tmp_path):
    repo = RunRepository()
    r = _run()
    repo.save(r)
    dest = tmp_path / "bk" / "copy.db"
    admin.backup_database(dest)
    restored = RunRepository(dest)
    got = restored.get(r.run_id)
    assert got is not None and got.to_dict() == r.to_dict()
    with pytest.raises(StorageError, match="already exists"):
        admin.backup_database(dest)
    with pytest.raises(StorageError, match="itself"):
        admin.backup_database(db)


def test_backup_without_database(db, tmp_path):
    with pytest.raises(StorageError, match="no database"):
        admin.backup_database(tmp_path / "x.db")


def test_backup_does_not_modify_source(db, tmp_path):
    RunRepository().save(_run())
    before = db.read_bytes()
    admin.backup_database(tmp_path / "b.db")
    assert db.read_bytes() == before


def test_logging_writes_file_and_redacts_token(tmp_path, monkeypatch):
    monkeypatch.setenv("VOLTIX_ACCESS_TOKEN", "super-secret-token-value")
    path = configure_logging("INFO", tmp_path / "logs" / "v.log")
    logging.getLogger("voltix.test").info("leaked super-secret-token-value here")
    logging.getLogger("voltix.test").debug("not shown at INFO")
    for h in logging.getLogger("voltix").handlers:
        h.flush()
    text = path.read_text()
    assert "leaked [redacted] here" in text and "super-secret" not in text and "not shown" not in text


def test_logging_is_idempotent_and_survives_unwritable_path(tmp_path):
    configure_logging("INFO", tmp_path / "a.log")
    configure_logging("INFO", tmp_path / "a.log")
    assert len([h for h in logging.getLogger("voltix").handlers if getattr(h, "_voltix_handler", False)]) == 2
    blocker = tmp_path / "file"
    blocker.write_text("x")
    assert configure_logging("INFO", blocker / "sub" / "v.log") is None  # parent is a file: falls back to stderr only
    configure_logging("INFO", tmp_path / "a.log")
