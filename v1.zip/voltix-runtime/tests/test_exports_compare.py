import csv
import io
import json

import pytest

from voltix.compare import ComparisonError, build_comparison, comparison_rows, comparison_warnings, config_diff_rows
from voltix.exports import SIMULATED_BANNER, run_to_json, run_to_markdown, runs_to_csv, samples_to_csv
from voltix.recommendations import recommend
from voltix.runner import run_benchmark
from voltix.schemas import BenchmarkRun, Precision


def test_summary_csv_has_data_source_and_values(cfg):
    runs = [run_benchmark(cfg(seed=1), "one"), run_benchmark(cfg(batch_size=200, prompt_tokens=2048), "failed")]
    rows = list(csv.DictReader(io.StringIO(runs_to_csv(runs))))
    assert len(rows) == 2 and all(r["data_source"] == "simulated" for r in rows)
    assert float(rows[0]["throughput_tokens_per_s"]) > 0
    assert rows[1]["status"] == "failed" and rows[1]["throughput_tokens_per_s"] == "" and "out-of-memory" in rows[1]["error"]


def test_csv_formula_injection_is_neutralized(cfg):
    run = run_benchmark(cfg(), "=HYPERLINK(\"http://evil\")")
    first = list(csv.DictReader(io.StringIO(runs_to_csv([run]))))[0]
    assert first["name"].startswith("'=")


def test_samples_csv(cfg):
    run = run_benchmark(cfg(iterations=6))
    rows = list(csv.DictReader(io.StringIO(samples_to_csv(run))))
    assert len(rows) == 6 and rows[0]["data_source"] == "simulated"


def test_json_export_roundtrips_and_declares_simulation(cfg):
    run = run_benchmark(cfg())
    payload = json.loads(run_to_json(run, recommend(run)))
    assert payload["data_source"] == "simulated" and "SIMULATED" in payload["data_source_notice"]
    assert BenchmarkRun.from_dict(payload["run"]).to_dict() == run.to_dict()


def test_markdown_report_flags_simulated_data_twice(cfg):
    run = run_benchmark(cfg())
    md = run_to_markdown(run, recommend(run))
    assert md.count(SIMULATED_BANNER) == 2 and "Simulated metrics" in md and "## Configuration" in md


def test_comparison_deltas_and_verdicts(cfg):
    a = run_benchmark(cfg(batch_size=1), "a")
    b = run_benchmark(cfg(batch_size=16), "b")
    cmp = {c.key: c for c in build_comparison([a, b], a.run_id)}
    thr = cmp["throughput_tokens_per_s"]
    assert thr.deltas_pct[a.run_id] is None and thr.deltas_pct[b.run_id] > 0 and thr.verdicts[b.run_id] == "better"
    assert cmp["latency_p50_ms"].verdicts[b.run_id] == "worse"  # bigger batch -> slower per batch
    assert cmp["peak_memory_gb"].verdicts[b.run_id] == "worse"


def test_comparison_rejects_bad_selections(cfg):
    a = run_benchmark(cfg(), "a"); failed = run_benchmark(cfg(batch_size=200, prompt_tokens=2048), "f")
    with pytest.raises(ComparisonError):
        build_comparison([a])
    with pytest.raises(ComparisonError):
        build_comparison([a, a])
    with pytest.raises(ComparisonError):
        build_comparison([a, failed])
    with pytest.raises(ComparisonError):
        build_comparison([a, run_benchmark(cfg(seed=2))], baseline_id="nope")


def test_comparison_warnings_and_config_diff(cfg):
    a = run_benchmark(cfg(), "a"); b = run_benchmark(cfg(precision=Precision.INT8, hardware_id="h100-80gb"), "b")
    warnings = comparison_warnings([a, b])
    assert any("simulated" in w.lower() for w in warnings) and any("hardware" in w for w in warnings)
    diff = {row["field"]: row for row in config_diff_rows([a, b])}
    assert diff["Precision"]["differs"] and diff["Hardware"]["differs"] and not diff["Model"]["differs"]
    rows = comparison_rows([a, b], build_comparison([a, b]))
    assert rows and {"metric", "run_id", "data_source", "value", "delta_vs_baseline_pct"} <= set(rows[0])
