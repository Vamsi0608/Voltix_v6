"""Run Benchmark page with the REAL Transformers backend (CPU, tiny local model)."""

from pathlib import Path

import pytest

pytest.importorskip("torch")
pytest.importorskip("transformers")
from streamlit.testing.v1 import AppTest  # noqa: E402

from voltix.backends import transformers_backend as tb  # noqa: E402
from voltix.testmodel import create_tiny_model  # noqa: E402


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setenv("VOLTIX_DB_PATH", str(tmp_path / "ui.db"))


@pytest.fixture(scope="module")
def tiny(tmp_path_factory):
    return str(create_tiny_model(tmp_path_factory.mktemp("uimodels") / "tiny"))


def page(module="run_benchmark") -> AppTest:
    return AppTest.from_string(f"from ui.pages import {module}\n{module}.render()", default_timeout=120)


def ok(at: AppTest) -> AppTest:
    assert not at.exception, [e.value for e in at.exception]
    return at


def wait_job(at: AppTest, timeout: float = 120) -> AppTest:
    """Runs now execute in a background thread: wait for it, then rerun so the page collects the result."""
    import time

    from voltix.jobs import manager
    end = time.time() + timeout
    while manager().current() is not None and manager().current().running and time.time() < end:
        time.sleep(0.05)
    assert not manager().current().running, "benchmark job did not finish"
    return at.run()


def select_transformers(model=None) -> AppTest:
    at = ok(page().run())
    ok(at.radio(key="rb_backend").set_value("transformers").run())
    if model:
        ok(at.text_input(key="rb_model_id").set_value(model).run())
    return at


def test_transformers_backend_without_a_model_asks_for_one():
    at = select_transformers()
    assert at.button(key="rb_run").disabled and any("Enter a Hugging Face repo id" in i.value for i in at.info)


def test_real_run_save_and_history_workflow(tiny):
    at = select_transformers(tiny)
    assert not at.button(key="rb_run").disabled and not at.error
    at = ok(wait_job(at.button(key="rb_run").click().run()))
    assert any("Result:" in m.value for m in at.markdown)
    assert any("MEASURED" in m.value for m in at.markdown) and not any("⚠ SIMULATED" in m.value and "vx-pill" in m.value for m in at.markdown)
    assert any(b.key == "rb_save" for b in at.button)
    kpis = " ".join(m.value for m in at.markdown)
    assert "Peak process RAM" in kpis  # CPU run: memory is labelled as process RAM, not "GPU" or "(est.)"
    at = ok(at.button(key="rb_save").click().run())
    assert any("Saved to history" in s.value for s in at.success)
    history = ok(page("history").run())
    assert len(history.dataframe) == 1 and "MEASURED" in history.dataframe[0].value.to_string()
    results = ok(page("results").run())
    assert any("MEASURED" in m.value for m in results.markdown)
    assert not any("SIMULATED by an analytic model" in w.value for w in results.warning)


def test_fp16_on_cpu_is_blocked_before_running(tiny):
    at = select_transformers(tiny)
    labels = list(at.selectbox(key="rb_device").options)
    if any(o.startswith("cuda") for o in labels):
        pytest.skip("this machine has a CUDA GPU, so fp16 is legitimately allowed here")
    assert len(labels) == 2  # only "auto" and "CPU" are offered: no GPU is invented
    ok(at.selectbox(key="rb_device").select_index(1).run())  # explicit CPU
    ok(at.selectbox(key="rb_prec_tf").select_index(1).run())  # fp16
    assert at.button(key="rb_run").disabled and any("fp16 is not supported on CPU" in e.value for e in at.error)


def test_cuda_cannot_be_selected_without_a_gpu(tiny):
    at = select_transformers(tiny)
    if any(o.startswith("cuda") for o in at.selectbox(key="rb_device").options):
        pytest.skip("this machine has a CUDA GPU")
    assert not any("cuda" in o for o in at.selectbox(key="rb_device").options)


def test_tiny_model_button_creates_a_local_model(tmp_path, monkeypatch):
    import ui.pages.run_benchmark as rb

    monkeypatch.setattr(rb, "create_tiny_model", lambda: create_tiny_model(tmp_path / "made"))
    at = select_transformers()
    ok(at.button(key="rb_tiny").click().run())
    assert at.text_input(key="rb_model_id").value == str(tmp_path / "made")
    assert any("RANDOM-WEIGHT" in s.value for s in at.success) and (Path(tmp_path) / "made" / "config.json").exists()
    assert not at.button(key="rb_run").disabled


def test_system_page_probe_button(monkeypatch):
    at = ok(page("system_info").run())
    ok(at.button(key="sys_probe").click().run())
    text = " ".join(m.value for m in at.markdown)
    assert "CUDA usable" in text
