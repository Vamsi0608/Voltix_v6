# Deploying VOLTIX for a supervised demo or controlled pilot

Read SECURITY.md first. VOLTIX is single-tenant: **one deployment and one database per customer.**

## 1. Install (verified from a clean folder on Linux, Python 3.13)
```bash
unzip voltix-runtime.zip && cd voltix-runtime
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt                          # demo mode (simulated)
pip install -r requirements-hf.txt                       # optional: real inference (torch is large; GPU builds: see GPU_BENCHMARK.md)
python check_setup.py                                    # must end with "Ready."
```
Launchers: `./run_voltix.sh` (Linux/Mac) or `run_voltix.bat` (Windows; written but **not tested on Windows**).

## 2. Configure
Environment variables only (no config file with secrets). See `.env.example` for all of them: access token, model folder, database path, log file/level, run time limits.

## 3. Run
- **Local demo:** `python -m streamlit run app.py` → http://localhost:8501 (this computer only).
- **Shared pilot:** set `VOLTIX_ACCESS_TOKEN`, keep VOLTIX on 127.0.0.1, put an HTTPS reverse proxy in front (SECURITY.md has a Caddy example). The app will not serve on a reachable address without a token.

## 4. Operate
| Task | Command |
|---|---|
| Health (database, token, backends) | `python -m voltix.admin health` (exit 0 healthy, 1 problem, JSON output) |
| Health incl. web server | `python -m voltix.admin health --url http://127.0.0.1:8501` (also usable by a monitor: Streamlit answers `/_stcore/health` with `ok`) |
| Backup (safe while running) | `python -m voltix.admin backup /safe/place/voltix-2026-10-25.db` (never overwrites) |
| Restore | stop the app, copy the backup over the file at `VOLTIX_DB_PATH`, start the app |
| Logs | `data/voltix.log` (rotating 1 MB × 3; sign-ins, job start/finish/failure; tokens are redacted) |
| Upgrade | stop; back up; replace the code; `pip install -r requirements.txt`; `python check_setup.py`; start. A database written by a newer version is refused, not modified. |
| Delete all customer data | stop the app; delete the database file and `data/voltix.log*` |

## 5. Not verified
Windows launcher; Docker (no container image is provided); behind a real reverse proxy/TLS; macOS; running as a system service; log shipping; multi-instance use of one database file.
