# How VOLTIX measures (procedure v1)

Every run records this procedure in `environment.procedure`, so two results can be judged comparable.

## Procedure
1. **Validate** the configuration (ranges, model, precision, device, revision).
2. **Load the model once per run.** Each repeat run reloads it (load time is recorded, not measured as latency).
3. **Warm-up iterations** (default 2–3) run first and are discarded.
4. **Measured iterations** run one at a time, sequentially, with the same seeded synthetic prompt (random token ids, no real text), greedy decoding, exactly the requested number of new tokens.
5. **Timing:** wall clock around `generate()` (CUDA synchronize before/after on GPU). TTFT = time until the first generated token exists.
6. **Memory:** GPU = peak tensor memory (`max_memory_allocated`); CPU = whole-process peak RSS, which is never used for verdicts.
7. **Stop rules:** cancel at the next generated token; total limit (default 30 min) and per-iteration limit (default 5 min). A stopped run keeps no samples or metrics and is never compared.

## What is recorded
Model id, requested revision and (when the library reports it) the resolved commit; parameter count and dtype; device name, compute capability, driver; Python / torch / CUDA build / transformers versions; OS; CPU model, cores, RAM; workload settings, seed; `started_at` / `finished_at` (UTC) and wall-clock; iterations planned vs completed; the limits in force.

Not recorded (cannot be observed by the runner): GPU clocks and temperature, other processes on the machine, power mode. Compare runs only when these are plausibly equal.

## Minimum observations
| Statistic | Reported only with at least |
|---|---|
| p50, mean, TTFT mean | 1 iteration (but 5+ recommended) |
| Latency std | 5 |
| p95 latency / TTFT | 20 |
| p99 latency | 100 |

Below the threshold, the value is stored but every display, comparison and export shows `n/a (needs at least N measured iterations; this run has M)`; JSON exports include a `metric_support` map.

## Repeatability evidence (CPU, tiny random-weight model, this sandbox only)
5 identical runs × 30 iterations: throughput 634.7, 643.0, 656.8, 660.7, 692.7 tok/s, run-to-run CV 3.4 %. This shows the procedure is repeatable on a quiet CPU for a tiny model; it says nothing about real models or GPUs. The one real T4 pair (34.4 / 34.1 tok/s) is the only GPU repeatability data so far.
