"""Run REAL Hugging Face inference benchmarks from the command line (for example on a cloud GPU notebook).

Each run is written as a JSON file you can import on the History page of the VOLTIX app. Only measured numbers
are recorded. Metrics that could not be measured are shown as "n/a" with the reason; nothing is estimated.

Example (GPU):
    python run_real_benchmark.py --model Qwen/Qwen2.5-0.5B --allow-download --device cuda --precision fp16 \\
        --batch-size 1 --prompt-tokens 128 --output-tokens 128 --iterations 30 --repeats 2

Needs: numpy, torch, transformers (not streamlit).
"""

from __future__ import annotations

import argparse
import re
import signal
import sys
import threading
from pathlib import Path

from voltix.backends.base import BackendError, BackendUnavailable
from voltix.control import CancelToken, RunLimits
from voltix.db import RunRepository
from voltix.exports import run_to_json
from voltix.metrics import describe_metric
from voltix.recommendations import recommend
from voltix.runner import run_benchmark
from voltix.schemas import BenchmarkConfig, DataSource, Precision, RunStatus
from voltix.validation import ValidationError


def _slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "-", text).strip("-")[:60] or "run"


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model", required=True, help="Hugging Face repo id (org/name) or a local model folder")
    p.add_argument("--device", default="cuda", help="auto, cpu, cuda or cuda:N (default: cuda)")
    p.add_argument("--precision", default="fp16", choices=["fp32", "fp16", "bf16"])
    p.add_argument("--batch-size", type=int, default=1)
    p.add_argument("--prompt-tokens", type=int, default=128)
    p.add_argument("--output-tokens", type=int, default=128)
    p.add_argument("--iterations", type=int, default=30)
    p.add_argument("--warmup", type=int, default=3)
    p.add_argument("--seed", type=int, default=1)
    p.add_argument("--repeats", type=int, default=1, help="identical repeat runs (>=2 lets the Optimize page measure run-to-run noise)")
    p.add_argument("--revision", default=None, help="Hugging Face branch, tag or commit to load (pins the exact weights; recorded with the run)")
    p.add_argument("--allow-download", action="store_true", help="allow downloading the model from the Hugging Face Hub")
    p.add_argument("--allow-cpu", action="store_true", help="do not stop when the run ends up on the CPU")
    p.add_argument("--max-run-seconds", type=float, default=None,
                   help="stop a run that takes longer than this in total (default 1800; 0 = no limit; env VOLTIX_MAX_RUN_SECONDS)")
    p.add_argument("--max-iteration-seconds", type=float, default=None,
                   help="stop when one iteration takes longer than this (default 300; 0 = no limit; env VOLTIX_MAX_ITERATION_SECONDS)")
    p.add_argument("--out", default="voltix_results", help="folder for the JSON files (default: voltix_results)")
    p.add_argument("--save-db", default=None, help="also save runs into this VOLTIX database file")
    return p


def _na(value, unit: str, why: str) -> str:
    return f"{value:,.2f} {unit}" if value is not None else f"n/a ({why})"


def summarize(run) -> str:
    m, env = run.metrics, run.environment or {}
    dev = env.get("device") or {}
    mem_kind = (env.get("measurement") or {}).get("memory_kind")
    mem_label = {"cuda_max_memory_allocated": "GPU memory (peak tensors)", "process_peak_rss": "Process RAM (CPU, not GPU)"}.get(mem_kind, "Peak memory")
    why = "not reported by this device/OS"
    return "\n".join([
        f"  device            : {dev.get('name', 'unknown')} ({dev.get('kind', '?')})",
        f"  throughput        : {_na(m.throughput_tokens_per_s, 'tokens/s', why)}",
        f"  time to 1st token : {_na(m.ttft_mean_ms, 'ms (mean)', why)}",
        f"  latency p50       : {m.latency_p50_ms:,.2f} ms",
        f"  latency p95       : {describe_metric(m, 'latency_p95_ms')}",
        f"  latency p99       : {describe_metric(m, 'latency_p99_ms')}",
        f"  {mem_label:<18}: {_na(m.peak_memory_gb, 'GB', why)}",
    ])


EXIT_CANCELLED, EXIT_TIMED_OUT = 130, 4


def _limits(args) -> RunLimits:
    base = RunLimits.from_env()
    pick = lambda cli, env: env if cli is None else (None if cli == 0 else cli)  # noqa: E731
    return RunLimits(max_run_seconds=pick(args.max_run_seconds, base.max_run_seconds),
                     max_iteration_seconds=pick(args.max_iteration_seconds, base.max_iteration_seconds))


def main(argv: list[str] | None = None, token: CancelToken | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        limits = _limits(args)
    except ValueError as exc:
        print(f"Invalid limit: {exc}")
        return 2
    token = token or CancelToken()
    previous = None
    if threading.current_thread() is threading.main_thread():
        def _on_sigint(signum, frame):  # first Ctrl+C asks politely; the second one is the normal hard interrupt
            token.cancel()
            signal.signal(signal.SIGINT, signal.default_int_handler)
            print("\nCancel requested: stopping at the next token (model loading cannot be interrupted; press Ctrl+C again to force quit).", flush=True)
        previous = signal.signal(signal.SIGINT, _on_sigint)
    try:
        return _main(args, limits, token)
    finally:
        if previous is not None:
            signal.signal(signal.SIGINT, previous)


def _main(args, limits: RunLimits, token: CancelToken) -> int:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    repo = RunRepository(args.save_db) if args.save_db else None
    failures = 0
    for k in range(1, args.repeats + 1):
        cfg = BenchmarkConfig(model_id=args.model, precision=Precision(args.precision), batch_size=args.batch_size,
                              prompt_tokens=args.prompt_tokens, output_tokens=args.output_tokens, iterations=args.iterations,
                              warmup_iterations=args.warmup, seed=args.seed, backend="transformers", hardware_id=args.device,
                              allow_download=args.allow_download, revision=args.revision)
        label = f"{args.model.split('/')[-1]} {args.precision} b{args.batch_size}" + (f" #{k}" if args.repeats > 1 else "")
        print(f"[{k}/{args.repeats}] {label}: loading model and measuring (this can take minutes the first time)...", flush=True)
        try:
            run = run_benchmark(cfg, label, progress=lambda d, t, s: print(f"\r    {s}: {d}/{t}", end="", flush=True),
                                cancel=token, limits=limits)
        except (ValidationError, BackendUnavailable) as exc:
            print(f"\nCannot run: {exc}")
            return 2
        except BackendError as exc:
            print(f"\nCannot run: {exc}")
            return 2
        print()
        if run.status in (RunStatus.CANCELLED, RunStatus.TIMED_OUT):
            print(f"  {run.status.value.upper().replace('_', ' ')}: {run.error}\n  Nothing was saved for this run.")
            return EXIT_CANCELLED if run.status == RunStatus.CANCELLED else EXIT_TIMED_OUT
        if run.status != RunStatus.COMPLETED or run.metrics is None:
            print(f"  FAILED: {run.error}")
            failures += 1
            continue
        kind = (run.environment or {}).get("device_kind")
        if kind != "cuda" and not args.allow_cpu:
            print(f"  STOPPED: this ran on '{kind}', not a GPU. Nothing was saved. In Colab choose Runtime > Change runtime type > "
                  "GPU and restart; or pass --allow-cpu to measure the CPU on purpose.")
            return 3
        assert run.data_source == DataSource.MEASURED  # the transformers backend can only produce measured runs
        print(summarize(run))
        path = out / f"{_slug(label)}_{run.run_id}.json"
        path.write_text(run_to_json(run, recommend(run)), encoding="utf-8")
        print(f"  saved: {path}")
        if repo is not None:
            repo.save(run)
            print(f"  saved to database: {repo.path}")
    print(f"\nDone: {args.repeats - failures} of {args.repeats} run(s) completed. Import the JSON files in the VOLTIX app: Benchmark History > Import.")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
