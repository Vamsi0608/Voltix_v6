# Pilot feedback questionnaire

Answer in your own words. "Did not use" is a fine answer. Nothing here is scored.

**About your use**
1. Which model(s) and hardware did you measure? How many runs did you save?
2. Could you install and start VOLTIX without help? Where did you get stuck (step, message)?
3. How long did the first real measurement take from download to a saved result?

**Trust in the numbers**
4. Did any result surprise you? Did you check it against another tool? What did the other tool say?
5. Was it clear which numbers were measured and which were simulated?
6. Were any `n/a`, "cannot be confirmed" or "no detectable difference" messages confusing? Which?

**Usefulness**
7. Did you reach a decision (or a concrete next experiment) because of the results? What was it? (Please do not estimate savings; describe what you decided.)
8. Which page did you use most? Which did you not use?
9. Which limit did you want to enter on the Requirements page that is missing?

**Problems**
10. Anything that crashed, hung, or gave a wrong or misleading result? Steps to reproduce.
11. Did anything about data handling or security concern you?

**Next**
12. What would you need before running this on production hardware or a shared server?
13. May we contact you with follow-up questions? (yes/no)
