# VOLTIX Runtime optimization study: baseline fp32 b1 (run 1)

> Every figure is a difference between saved runs (or arithmetic on them). Nothing here is a prediction. Intervals describe measurement noise on one machine only.

## Workload

- Model: tiny-random-test-model
- Prompt / output tokens: 64 / 16
- Backend: transformers
- Runs in this study: 4

## Findings

### same configuration: baseline fp32 b1 (run 2, repeat) vs baseline fp32 b1 (run 1)

_Kind: no_difference. Confidence: low._

Replicate runs differ by up to 10.1% on time to first token (mean). Treat changes of this size between configurations as noise. (single comparison on one machine)

- throughput -7.3% (95% CI -14.2% to -0.4%; 645 -\> 598 tok/s): no detectable change
- latency p95 +5.3% (95% CI -11.8% to +40.7%; 36.10 -\> 38.03 ms): no detectable change
- time to first token (mean) +10.1% (95% CI +1.3% to +20.1%; 2.96 -\> 3.26 ms): no detectable change

### precision fp32 → bf16: bf16 b1 vs baseline fp32 b1 (run 1)

_Kind: regression. Confidence: medium._

Worse on throughput, time to first token (mean); nothing assessed improved. (single comparison on one machine)

- throughput -22.6% (95% CI -26.6% to -18.5%; 645 -\> 499 tok/s): worse
- latency p95 +16.5% (95% CI -1.3% to +39.7%; 36.10 -\> 42.06 ms): no detectable change
- time to first token (mean) +22.6% (95% CI +15.7% to +30.3%; 2.96 -\> 3.63 ms): worse
- Trade-off: Cost of this change: throughput -22.6% (95% CI -26.6% to -18.5%; 645 -\> 499 tok/s).
- Trade-off: Cost of this change: time to first token (mean) +22.6% (95% CI +15.7% to +30.3%; 2.96 -\> 3.63 ms).

### batch size 1 → 4: fp32 b4 vs baseline fp32 b1 (run 1)

_Kind: trade_off. Confidence: medium._

Better on throughput, but worse on time to first token (mean). (single comparison on one machine)

- throughput +283.0% (95% CI +265.4% to +302.5%; 645 -\> 2,470 tok/s): better
- latency p95 -4.2% (95% CI -20.5% to +15.9%; 36.10 -\> 34.58 ms): no detectable change
- time to first token (mean) +19.8% (95% CI +13.4% to +26.5%; 2.96 -\> 3.54 ms): worse
- Trade-off: Cost of this change: time to first token (mean) +19.8% (95% CI +13.4% to +26.5%; 2.96 -\> 3.54 ms).
- Trade-off: Batch size changes how much work one iteration does: per-iteration latency is not per-request latency, so throughput and latency answer different questions here.

### bf16 b1 is outperformed by baseline fp32 b1 (run 1)

_Kind: dominated. Confidence: medium._

baseline fp32 b1 (run 1) is better on throughput, time to first token (mean) and not worse on anything assessed, in a like-for-like comparison.


### bf16 b1 is outperformed by baseline fp32 b1 (run 2, repeat)

_Kind: dominated. Confidence: low._

baseline fp32 b1 (run 2, repeat) is better on throughput, time to first token (mean) and not worse on anything assessed, in a like-for-like comparison.


### baseline fp32 b1 (run 2, repeat) is outperformed by fp32 b4

_Kind: dominated. Confidence: low._

fp32 b4 is better on throughput and not worse on anything assessed, in a like-for-like comparison.


### bf16 b1 is outperformed by fp32 b4

_Kind: dominated. Confidence: low._

fp32 b4 is better on throughput, latency p95 and not worse on anything assessed, in a like-for-like comparison.


## Comparisons against the baseline

| Candidate | Comparability | Result | Confidence |
|---|---|---|---|
| baseline fp32 b1 (run 2, repeat) | replicate | Replicate runs differ by up to 10.1% on time to first token (mean). Treat changes of this size between configurations as noise. | low |
| bf16 b1 | controlled | Worse on throughput, time to first token (mean); nothing assessed improved. | medium |
| fp32 b4 | controlled | Better on throughput, but worse on time to first token (mean). | medium |

### baseline fp32 b1 (run 2, repeat) vs baseline fp32 b1 (run 1)

| Metric | Baseline | Candidate | Change (95% CI) | Verdict |
|---|---|---|---|---|
| Throughput (tok/s) | 644.91 | 598.11 | -7.3% (-14.2% to -0.4%) | no_detectable_change |
| Latency p50 (ms) | 23.01 | 23.95 | +4.1% (-0.8% to +11.2%) | no_detectable_change |
| Latency p95 (ms) | 36.10 | 38.03 | +5.3% (-11.8% to +40.7%) | no_detectable_change |
| Latency p99 (ms) | 42.50 | 69.62 | +63.8% (-12.3% to +104.2%) | no_detectable_change |
| Time to first token (mean) (ms) | 2.96 | 3.26 | +10.1% (+1.3% to +20.1%) | no_detectable_change |
| Time per output token (mean) (ms) | 1.46 | 1.57 | +7.5% (+0.0% to +16.1%) | no_detectable_change |
| Peak memory (GB) | 0.01 | 0.00 | -90.0% (no interval) | not_assessed |

**Confidence: low.** Low: noise (candidate).

- [info] Attribution: Same configuration: this pair measures noise.
- [pass] Sample size: 100 measured iterations in the smaller run (>= 30).
- [warn] Noise (baseline): Latency varies by 21% (std/mean) across iterations.
- [warn] Independence (baseline): Consecutive iterations are correlated (r = 0.71); the run may be drifting (thermal throttling, caching), so intervals are likely too narrow.
- [fail] Noise (candidate): Latency varies by 32% (std/mean) across iterations.
- [warn] Independence (candidate): Consecutive iterations are correlated (r = 0.57); the run may be drifting (thermal throttling, caching), so intervals are likely too narrow.
- [pass] Warm-up: Both runs excluded warm-up iterations.
- [pass] Environment: Software versions and host match.
- [pass] Replication: 1 replicate pair(s) of one setup differ by (throughput up to 7.3%); changes no bigger than a metric's replicate difference are not reported as effects.
- [pass] Precision: Throughput change is known to within about ±6.9 percentage points (95% CI).

### bf16 b1 vs baseline fp32 b1 (run 1)

| Metric | Baseline | Candidate | Change (95% CI) | Verdict |
|---|---|---|---|---|
| Throughput (tok/s) | 644.91 | 499.00 | -22.6% (-26.6% to -18.5%) | regressed |
| Latency p50 (ms) | 23.01 | 31.54 | +37.1% (+28.6% to +44.4%) | regressed |
| Latency p95 (ms) | 36.10 | 42.06 | +16.5% (-1.3% to +39.7%) | no_detectable_change |
| Latency p99 (ms) | 42.50 | 45.95 | +8.1% (-9.0% to +38.8%) | no_detectable_change |
| Time to first token (mean) (ms) | 2.96 | 3.63 | +22.6% (+15.7% to +30.3%) | regressed |
| Time per output token (mean) (ms) | 1.46 | 1.90 | +30.1% (+23.0% to +37.3%) | regressed |
| Peak memory (GB) | 0.01 | 0.01 | -30.0% (no interval) | not_assessed |

**Confidence: medium.** Medium: noise (baseline); independence (baseline); noise (candidate) could be better.

- [pass] Attribution: Exactly one setting changed (precision fp32 → bf16).
- [pass] Sample size: 100 measured iterations in the smaller run (>= 30).
- [warn] Noise (baseline): Latency varies by 21% (std/mean) across iterations.
- [warn] Independence (baseline): Consecutive iterations are correlated (r = 0.71); the run may be drifting (thermal throttling, caching), so intervals are likely too narrow.
- [warn] Noise (candidate): Latency varies by 17% (std/mean) across iterations.
- [pass] Warm-up: Both runs excluded warm-up iterations.
- [pass] Environment: Software versions and host match.
- [pass] Replication: 1 replicate pair(s) of one setup differ by (throughput up to 7.3%); changes no bigger than a metric's replicate difference are not reported as effects.
- [pass] Precision: Throughput change is known to within about ±4.0 percentage points (95% CI).

### fp32 b4 vs baseline fp32 b1 (run 1)

| Metric | Baseline | Candidate | Change (95% CI) | Verdict |
|---|---|---|---|---|
| Throughput (tok/s) | 644.91 | 2,470.19 | +283.0% (+265.4% to +302.5%) | improved |
| Latency p50 (ms) | 23.01 | 24.72 | +7.5% (+2.5% to +12.2%) | regressed |
| Latency p95 (ms) | 36.10 | 34.58 | -4.2% (-20.5% to +15.9%) | no_detectable_change |
| Latency p99 (ms) | 42.50 | 38.25 | -10.0% (-23.2% to +4.2%) | no_detectable_change |
| Time to first token (mean) (ms) | 2.96 | 3.54 | +19.8% (+13.4% to +26.5%) | regressed |
| Time per output token (mean) (ms) | 1.46 | 1.49 | +2.4% (-3.0% to +7.5%) | no_detectable_change |
| Peak memory (GB) | 0.01 | 0.00 | -70.0% (no interval) | not_assessed |

**Confidence: medium.** Medium: noise (baseline); independence (baseline); independence (candidate); precision could be better.

- [pass] Attribution: Exactly one setting changed (batch size 1 → 4).
- [pass] Sample size: 100 measured iterations in the smaller run (>= 30).
- [warn] Noise (baseline): Latency varies by 21% (std/mean) across iterations.
- [warn] Independence (baseline): Consecutive iterations are correlated (r = 0.71); the run may be drifting (thermal throttling, caching), so intervals are likely too narrow.
- [pass] Noise (candidate): Latency varies by 14% (std/mean) across iterations.
- [warn] Independence (candidate): Consecutive iterations are correlated (r = 0.69); the run may be drifting (thermal throttling, caching), so intervals are likely too narrow.
- [pass] Warm-up: Both runs excluded warm-up iterations.
- [pass] Environment: Software versions and host match.
- [pass] Replication: 1 replicate pair(s) of one setup differ by (throughput up to 7.3%); changes no bigger than a metric's replicate difference are not reported as effects.
- [warn] Precision: Throughput change is known to within about ±18.6 percentage points (95% CI).

## Not yet measured

- Precisions tried: bf16, fp32; batch sizes tried: 1, 4; devices: Intel(R) Xeon(R) Processor @ 2.10GHz.
- Benchmark batch size 2: No saved run of this workload uses batch 2. Its effect on throughput and latency is unknown until measured.
- Benchmark the same workload on a different device: Every run so far used the same device, so nothing can be said about other hardware.

## How to read this

- Every figure is a difference between saved runs, or arithmetic on them. Nothing here is a prediction.
- Intervals are 95% bootstrap intervals that treat iterations as independent; they describe measurement noise on this machine only.
- Results do not transfer to other hardware, models, prompt lengths or real traffic patterns.
- Speed is measured, output quality is not: check quality yourself before adopting a lower precision.
