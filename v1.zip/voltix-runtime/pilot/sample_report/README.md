# Sample report (real measurements, tiny test model)

**What this is.** Four real benchmark runs executed by VOLTIX on Linux-6.18.44-fc-v153-x86_64-with-glibc2.39, Python 3.13.16, CPU only.
Each run: 3 warm-up + 100 measured iterations, prompt 64 tokens, output 16 tokens, seed 1.

**What the model is.** VOLTIX's built-in tiny *random-weight* test model. It was chosen because it needs no download. Its speed says
**nothing** about any real model, any GPU, or any saving you could expect.

**What it shows.** The shape of the output a pilot customer receives: per-run report, a replicate pair (identical setup run twice,
which measures run-to-run noise), a precision change, and a batch-size change, each with confidence statements and caveats.

**Files.** `run_*.json` can be imported on the Benchmark History page (they import as MEASURED). `run_reports.md` and `study_report.md`
are the app's own exports, unedited.

**Reproduce.** `python make_sample_report.py` (numbers will differ run to run; that variation is the point of the replicate pair).
