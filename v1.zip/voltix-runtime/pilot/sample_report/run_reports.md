# VOLTIX Runtime report: baseline fp32 b1 (run 1)

> Data source: **measured** on the machine and software listed under Environment.

## Run

- Run ID: `run_e58d15a3fc`
- Created (UTC): 2026-10-25T18:15:46+00:00
- Status: completed
- Data source: **measured**
- Backend: transformers
- VOLTIX Runtime version: 0.5.0

## Configuration

| Setting | Value |
|---|---|
| Model | tiny-random-test-model (tiny-random-test-model) |
| Device | cpu |
| Precision | fp32 |
| Batch size | 1 |
| Prompt tokens | 64 |
| Output tokens | 16 |
| Iterations / warmup | 100 / 3 |
| Seed | 1 |

## Environment

| Item | Value |
|---|---|
| device.kind | cpu |
| device.name | Intel(R) Xeon(R) Processor @ 2.10GHz |
| device.hardware_id | cpu |
| device.total_memory_gb | 8.417529856 |
| software.python | 3.13.16 |
| software.torch | 2.14.1+cu130 |
| software.torch_cuda_build | 13.0 |
| software.transformers | 5.20.2 |
| software.os | Linux 6.18.44-fc-v153 |
| host.cpu_model | Intel(R) Xeon(R) Processor @ 2.10GHz |
| host.cpu_count | 2 |
| host.ram_gb | 8.417529856 |
| host.torch_threads | 2 |
| model.id | tiny-random-test-model |
| model.class | LlamaForCausalLM |
| model.num_parameters | 336192 |
| model.parameter_dtype | float32 |
| model.max_position_embeddings | 512 |
| model.requested_revision | None |
| model.commit_hash | None |
| model.load_time_s | 0.021 |
| model.downloads_allowed | False |
| model.trust_remote_code | False |
| measurement.prompt | synthetic random token ids (seeded); no tokenizer, no real text |
| measurement.decoding | greedy; exactly the requested number of new tokens (EOS suppressed) |
| measurement.latency | wall clock around generate() |
| measurement.ttft | time until the first generated token exists (prefill + first decode step + generate setup) |
| measurement.memory_kind | process\_peak\_rss |
| measurement.memory_scope | peak resident memory of the WHOLE process, counted from just before model loading; it still includes memory already resident then (Python, torch), see memory\_above\_baseline\_gb |
| measurement.memory_unit | GB = 10^9 bytes |
| measurement.memory_above_baseline_gb | 0.01 |

## Metrics

| Metric | Value |
|---|---|
| Throughput | 644.9 tok/s |
| Sequences per second | 40.31 seq/s |
| Latency (mean) | 24.8 ms |
| Latency p50 | 23.0 ms |
| Latency p95 | 36.1 ms |
| Latency p99 | 42.5 ms |
| TTFT (mean) | 3.0 ms |
| TTFT p95 | 4.6 ms |
| Time per output token | 1.46 ms |
| Peak memory | 0.72 GB |
| Memory utilization | 8.6% |

## Recommendations

_Based on measured data._

### 1. Heavy tail latency (warning; observation)

A few iterations are much slower than the median, which hurts p99 service-level targets.

**Evidence**

- p99 43 ms is 1.85x the p50 23 ms (warning at 1.5x).
- Slowest iteration 47 ms over 100 iterations.

**Action:** Check for contention, thermal throttling or allocator stalls; use warmup iterations and more iterations.

**How to verify:** Re-run with at least 100 iterations and see whether the p99/p50 ratio persists. A tail that vanishes was noise.

**Caveat:** With few iterations, p99 is close to the maximum and is noisy.


---

# VOLTIX Runtime report: baseline fp32 b1 (run 2, repeat)

> Data source: **measured** on the machine and software listed under Environment.

## Run

- Run ID: `run_c035bcc9b2`
- Created (UTC): 2026-10-25T18:15:49+00:00
- Status: completed
- Data source: **measured**
- Backend: transformers
- VOLTIX Runtime version: 0.5.0

## Configuration

| Setting | Value |
|---|---|
| Model | tiny-random-test-model (tiny-random-test-model) |
| Device | cpu |
| Precision | fp32 |
| Batch size | 1 |
| Prompt tokens | 64 |
| Output tokens | 16 |
| Iterations / warmup | 100 / 3 |
| Seed | 1 |

## Environment

| Item | Value |
|---|---|
| device.kind | cpu |
| device.name | Intel(R) Xeon(R) Processor @ 2.10GHz |
| device.hardware_id | cpu |
| device.total_memory_gb | 8.417529856 |
| software.python | 3.13.16 |
| software.torch | 2.14.1+cu130 |
| software.torch_cuda_build | 13.0 |
| software.transformers | 5.20.2 |
| software.os | Linux 6.18.44-fc-v153 |
| host.cpu_model | Intel(R) Xeon(R) Processor @ 2.10GHz |
| host.cpu_count | 2 |
| host.ram_gb | 8.417529856 |
| host.torch_threads | 2 |
| model.id | tiny-random-test-model |
| model.class | LlamaForCausalLM |
| model.num_parameters | 336192 |
| model.parameter_dtype | float32 |
| model.max_position_embeddings | 512 |
| model.requested_revision | None |
| model.commit_hash | None |
| model.load_time_s | 0.016 |
| model.downloads_allowed | False |
| model.trust_remote_code | False |
| measurement.prompt | synthetic random token ids (seeded); no tokenizer, no real text |
| measurement.decoding | greedy; exactly the requested number of new tokens (EOS suppressed) |
| measurement.latency | wall clock around generate() |
| measurement.ttft | time until the first generated token exists (prefill + first decode step + generate setup) |
| measurement.memory_kind | process\_peak\_rss |
| measurement.memory_scope | peak resident memory of the WHOLE process, counted from just before model loading; it still includes memory already resident then (Python, torch), see memory\_above\_baseline\_gb |
| measurement.memory_unit | GB = 10^9 bytes |
| measurement.memory_above_baseline_gb | 0.001 |

## Metrics

| Metric | Value |
|---|---|
| Throughput | 598.1 tok/s |
| Sequences per second | 37.38 seq/s |
| Latency (mean) | 26.8 ms |
| Latency p50 | 24.0 ms |
| Latency p95 | 38.0 ms |
| Latency p99 | 69.6 ms |
| TTFT (mean) | 3.3 ms |
| TTFT p95 | 4.9 ms |
| Time per output token | 1.57 ms |
| Peak memory | 0.72 GB |
| Memory utilization | 8.6% |

## Recommendations

_Based on measured data._

### 1. Heavy tail latency (warning; observation)

A few iterations are much slower than the median, which hurts p99 service-level targets.

**Evidence**

- p99 70 ms is 2.91x the p50 24 ms (warning at 1.5x).
- Slowest iteration 78 ms over 100 iterations.

**Action:** Check for contention, thermal throttling or allocator stalls; use warmup iterations and more iterations.

**How to verify:** Re-run with at least 100 iterations and see whether the p99/p50 ratio persists. A tail that vanishes was noise.

**Caveat:** With few iterations, p99 is close to the maximum and is noisy.


---

# VOLTIX Runtime report: bf16 b1

> Data source: **measured** on the machine and software listed under Environment.

## Run

- Run ID: `run_07fd87d2b5`
- Created (UTC): 2026-10-25T18:15:52+00:00
- Status: completed
- Data source: **measured**
- Backend: transformers
- VOLTIX Runtime version: 0.5.0

## Configuration

| Setting | Value |
|---|---|
| Model | tiny-random-test-model (tiny-random-test-model) |
| Device | cpu |
| Precision | bf16 |
| Batch size | 1 |
| Prompt tokens | 64 |
| Output tokens | 16 |
| Iterations / warmup | 100 / 3 |
| Seed | 1 |

## Environment

| Item | Value |
|---|---|
| device.kind | cpu |
| device.name | Intel(R) Xeon(R) Processor @ 2.10GHz |
| device.hardware_id | cpu |
| device.total_memory_gb | 8.417529856 |
| software.python | 3.13.16 |
| software.torch | 2.14.1+cu130 |
| software.torch_cuda_build | 13.0 |
| software.transformers | 5.20.2 |
| software.os | Linux 6.18.44-fc-v153 |
| host.cpu_model | Intel(R) Xeon(R) Processor @ 2.10GHz |
| host.cpu_count | 2 |
| host.ram_gb | 8.417529856 |
| host.torch_threads | 2 |
| model.id | tiny-random-test-model |
| model.class | LlamaForCausalLM |
| model.num_parameters | 336192 |
| model.parameter_dtype | bfloat16 |
| model.max_position_embeddings | 512 |
| model.requested_revision | None |
| model.commit_hash | None |
| model.load_time_s | 0.028 |
| model.downloads_allowed | False |
| model.trust_remote_code | False |
| measurement.prompt | synthetic random token ids (seeded); no tokenizer, no real text |
| measurement.decoding | greedy; exactly the requested number of new tokens (EOS suppressed) |
| measurement.latency | wall clock around generate() |
| measurement.ttft | time until the first generated token exists (prefill + first decode step + generate setup) |
| measurement.memory_kind | process\_peak\_rss |
| measurement.memory_scope | peak resident memory of the WHOLE process, counted from just before model loading; it still includes memory already resident then (Python, torch), see memory\_above\_baseline\_gb |
| measurement.memory_unit | GB = 10^9 bytes |
| measurement.memory_above_baseline_gb | 0.007 |

## Metrics

| Metric | Value |
|---|---|
| Throughput | 499.0 tok/s |
| Sequences per second | 31.19 seq/s |
| Latency (mean) | 32.1 ms |
| Latency p50 | 31.5 ms |
| Latency p95 | 42.1 ms |
| Latency p99 | 46.0 ms |
| TTFT (mean) | 3.6 ms |
| TTFT p95 | 4.9 ms |
| Time per output token | 1.90 ms |
| Peak memory | 0.73 GB |
| Memory utilization | 8.6% |


---

# VOLTIX Runtime report: fp32 b4

> Data source: **measured** on the machine and software listed under Environment.

## Run

- Run ID: `run_5e1f80ca97`
- Created (UTC): 2026-10-25T18:15:55+00:00
- Status: completed
- Data source: **measured**
- Backend: transformers
- VOLTIX Runtime version: 0.5.0

## Configuration

| Setting | Value |
|---|---|
| Model | tiny-random-test-model (tiny-random-test-model) |
| Device | cpu |
| Precision | fp32 |
| Batch size | 4 |
| Prompt tokens | 64 |
| Output tokens | 16 |
| Iterations / warmup | 100 / 3 |
| Seed | 1 |

## Environment

| Item | Value |
|---|---|
| device.kind | cpu |
| device.name | Intel(R) Xeon(R) Processor @ 2.10GHz |
| device.hardware_id | cpu |
| device.total_memory_gb | 8.417529856 |
| software.python | 3.13.16 |
| software.torch | 2.14.1+cu130 |
| software.torch_cuda_build | 13.0 |
| software.transformers | 5.20.2 |
| software.os | Linux 6.18.44-fc-v153 |
| host.cpu_model | Intel(R) Xeon(R) Processor @ 2.10GHz |
| host.cpu_count | 2 |
| host.ram_gb | 8.417529856 |
| host.torch_threads | 2 |
| model.id | tiny-random-test-model |
| model.class | LlamaForCausalLM |
| model.num_parameters | 336192 |
| model.parameter_dtype | float32 |
| model.max_position_embeddings | 512 |
| model.requested_revision | None |
| model.commit_hash | None |
| model.load_time_s | 0.017 |
| model.downloads_allowed | False |
| model.trust_remote_code | False |
| measurement.prompt | synthetic random token ids (seeded); no tokenizer, no real text |
| measurement.decoding | greedy; exactly the requested number of new tokens (EOS suppressed) |
| measurement.latency | wall clock around generate() |
| measurement.ttft | time until the first generated token exists (prefill + first decode step + generate setup) |
| measurement.memory_kind | process\_peak\_rss |
| measurement.memory_scope | peak resident memory of the WHOLE process, counted from just before model loading; it still includes memory already resident then (Python, torch), see memory\_above\_baseline\_gb |
| measurement.memory_unit | GB = 10^9 bytes |
| measurement.memory_above_baseline_gb | 0.003 |

## Metrics

| Metric | Value |
|---|---|
| Throughput | 2,470.2 tok/s |
| Sequences per second | 154.39 seq/s |
| Latency (mean) | 25.9 ms |
| Latency p50 | 24.7 ms |
| Latency p95 | 34.6 ms |
| Latency p99 | 38.3 ms |
| TTFT (mean) | 3.5 ms |
| TTFT p95 | 4.8 ms |
| Time per output token | 1.49 ms |
| Peak memory | 0.73 GB |
| Memory utilization | 8.7% |

## Recommendations

_Based on measured data._

### 1. Heavy tail latency (warning; observation)

A few iterations are much slower than the median, which hurts p99 service-level targets.

**Evidence**

- p99 38 ms is 1.55x the p50 25 ms (warning at 1.5x).
- Slowest iteration 39 ms over 100 iterations.

**Action:** Check for contention, thermal throttling or allocator stalls; use warmup iterations and more iterations.

**How to verify:** Re-run with at least 100 iterations and see whether the p99/p50 ratio persists. A tail that vanishes was noise.

**Caveat:** With few iterations, p99 is close to the maximum and is noisy.
