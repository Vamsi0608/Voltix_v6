# Supervised demo script (about 25 minutes)

Audience: a prospective pilot customer. Presenter runs VOLTIX on their own computer (or a screen share). **Do not leave the app running unattended for the customer** at this stage.

## Before the demo (10 min, presenter)
1. `python check_setup.py` shows "Ready". Start with `./run_voltix.sh` (or `python -m streamlit run app.py`).
2. On Benchmark History, import the files in `pilot/sample_report/` (they import as MEASURED). If you have your own GPU runs from `GPU_BENCHMARK.md`, import those too.
3. Do **not** click "Load demo experiments" on the Overview page unless you intend to show simulated data; remove them afterwards.

## Flow
| Min | Page | Say | Show |
|---|---|---|---|
| 0–3 | Overview | "Everything is labelled SIMULATED or MEASURED. Simulated numbers come from a formula and are never evidence." | The banner; the measured/simulated counts |
| 3–8 | Run Benchmark | "A real run loads your model and times it on this machine." | Choose Transformers; **Create tiny test model**; run 100 iterations; point at progress and **Cancel**; note the result is labelled MEASURED and shows device, versions, procedure |
| 8–12 | Results and Reports | "Percentiles are shown only when there are enough iterations." | A run with 100 iterations (p99 shown) vs a short run (p99 "n/a") ; export JSON/Markdown |
| 12–18 | Optimize | "A replicate pair measures noise first. A difference smaller than that is not called an improvement." | The sample study: replicate, bf16 change, batch change; read one confidence block aloud |
| 18–22 | Requirements | "You give your own limits. Anything that cannot be checked says so." | Set a latency or throughput limit; show "cannot be confirmed" for a CPU memory limit |
| 22–25 | Questions | Hand over `pilot/ONBOARDING_GUIDE.md` and `pilot/KNOWN_LIMITATIONS.md` | |

## Say / do not say
- Say: the sample numbers come from a tiny random-weight model on a CPU and say nothing about your model or GPU.
- Say: a pilot's first deliverable is **your own model on your own hardware**, measured with the recorded procedure.
- Do **not** quote speed-ups, savings, cost reductions, uptime, security certifications or other customers. None exist in this project.
- Do not run an unprepared model live unless you know it fits in memory; loading cannot be cancelled.
