# Pilot scope — DRAFT for discussion (not a contract; have counsel review before use)

Items in [brackets] are to be agreed.

**1. Purpose.** Measure [model(s)] on [hardware] with VOLTIX, compare [precision / batch / device] options, and evaluate whether VOLTIX's results are clear and trustworthy enough to inform [customer's] deployment decisions.

**2. Duration.** [2–4] weeks from the day the customer's environment passes `check_setup.py`.

**3. In scope**
- Install on [customer-owned machine(s)]; supervised sessions with the VOLTIX team ([n] × [60] min).
- Up to [N] models and [M] hardware configurations, each measured with ≥100 iterations and at least one replicate.
- Requirements checks against limits **defined by the customer** in writing before measurement starts: [p95 latency], [throughput], [memory].
- Feedback via `FEEDBACK_QUESTIONNAIRE.md` and a closing review.

**4. Out of scope**
Production serving or traffic; shared/internet-exposed deployment; load, concurrency or quality testing; model training or fine-tuning; vLLM or quantised real inference; any performance improvement work; compliance assessments.

**5. Data handling**
- The application runs on customer-controlled machines and sends no run data anywhere (usage statistics are off). When served on a non-local address, the underlying Streamlit framework may contact an external service to display its network URL. Inputs are synthetic; model weights stay where they are.
- Results (JSON/Markdown exports) contain hardware/software descriptions and the model identifier; the customer reviews exports before sharing them.
- At the end the customer deletes the database and logs (`DEPLOY.md`); [VOLTIX team deletes any copies within [x] days].

**6. Customer responsibilities.** Provide access to the model and hardware; run on a quiet machine; keep the access token secret if the app is served to others; report problems with the steps in the onboarding guide.

**7. Pilot "success" is defined by the customer, not promised by VOLTIX.** Candidate measures, to be chosen by the customer: first measurement within [x] hours of kickoff; replicate runs agree within [x]%; results reproduced independently by [tool/person]; customer states a concrete decision or next experiment. VOLTIX makes **no** commitment to any speed-up, saving, uptime or accuracy.

**8. Known limitations** are as listed in `KNOWN_LIMITATIONS.md` and are accepted by both sides.

**9. Exit.** Either side may stop at any time; deletion per section 5.

**10. Not included.** No SLA, warranty, support hours beyond the supervised sessions, security certification, or indemnity; commercial terms [to be agreed separately].
