# Known limitations (read before agreeing to a pilot)

VOLTIX is an **internal-prototype-to-supervised-demo** build. Its classification and evidence are in `AUDIT.md`.

**Measurement**
- Real-GPU evidence is thin: one Colab T4 session (two repeats of one small model, run by the project owner). No A100/H100/consumer-GPU, multi-GPU, or large-model results exist yet.
- Only the Hugging Face Transformers backend measures real inference. vLLM and quantised (int8/int4) real runs are not implemented. Simulated mode is a formula and is never evidence.
- Inputs are synthetic random tokens with greedy decoding, a fixed number of output tokens, one request at a time. It does not model real traffic, concurrency, queueing, long contexts, or output quality.
- Short CPU runs are noisy: identical 20-iteration runs differed by ~10% (CV); 100 iterations ~5%. Treat differences below that as noise; the Optimize page measures this when you run a replicate pair.
- CPU memory is whole-process peak RAM and is not used for verdicts. GPU memory is tensor memory (excludes CUDA context/cache).
- Loading or downloading a model cannot be cancelled and has no time limit; GPU hangs cannot be interrupted.
- Clock speeds, temperature, power mode and other processes on the machine are not recorded.

**Security and operations**
- No independent security review. One shared access token, no per-user identity or audit trail, no idle timeout. TLS must be provided by a reverse proxy. Data (SQLite) is not encrypted. See `SECURITY.md`.
- Tested on Linux. The Windows launcher and Windows memory readers are untested here; macOS, Docker and running as a service are untested.
- One benchmark at a time per process. A restart during a run loses that run.

**Recommendations**
- They are rules over the measured numbers, not predictions. Nothing here estimates cost savings, and no uptime, throughput or latency is promised.
- The Requirements page only reflects runs you saved; "no saved run meets the limit" does not mean no configuration can.

**Not provided**
No certifications or compliance attestations (SOC 2, ISO 27001, HIPAA, GDPR, …), no SLA, no warranty, no customer references.
