# VOLTIX pilot: onboarding guide

VOLTIX measures how fast and how memory-hungry **your** model is on **your** hardware, then compares configurations (precision, batch size, device) without overstating what the data shows. It runs on your own machine; nothing is uploaded anywhere by the application.

## 1. What you need
- A computer with Python 3.10+ (only 3.13 has been tested by the project; older versions are untested), 4 GB free RAM for the demo mode.
- For real measurements: `torch` and `transformers` (`pip install -r requirements-hf.txt`), your model as a local folder or a cached Hugging Face model, and a GPU if you want GPU numbers.
- The pilot team will tell you which model(s) and hardware are in scope.

## 2. Install (15 min) — see SETUP.md / DEPLOY.md
`python -m venv .venv`, activate it, `pip install -r requirements.txt`, `python check_setup.py` → "Ready". Start: `python -m streamlit run app.py`. The app listens on this computer only.

## 3. First measurement
1. **Run Benchmark** → Hugging Face Transformers → enter the model folder or repo id → leave defaults (batch 1, 128 prompt / 32 output tokens) but set **Measured iterations to 100** → Run.
2. Wait for the progress bar; **Cancel** is available (loading a model cannot be cancelled).
3. Check the result says MEASURED and names your device. If it says CPU when you expected a GPU, stop and tell us.
4. **Save run**.

Repeat the same run once more (this measures run-to-run noise). Then change **one** thing (precision or batch size), run, save.

## 4. GPU machines without the app
Use `run_real_benchmark.py` or the notebook in `GPU_BENCHMARK.md`; it writes JSON files you import on **Benchmark History → Import**. Imports are validated and are never relabelled (a measured file stays measured).

## 5. Reading results
- **Results and Reports:** one run. `n/a` means "not enough iterations / not measurable on this device", never zero.
- **Compare Runs / Optimize:** differences with confidence intervals. "No detectable difference" is not "no difference". Runs that are not like-for-like are listed as left out, with the reason.
- **Requirements:** enter your latency, throughput, memory limits. The page says which saved runs meet them, which do not, and which **cannot be confirmed**.

## 6. What to send back
Exported JSON/Markdown for the runs you want to discuss (no model weights, no prompts: inputs are synthetic), plus the completed `FEEDBACK_QUESTIONNAIRE.md`. Review exports before sending: they include your CPU/GPU model, OS and software versions, and the model folder name.

## 7. If something goes wrong
`SETUP.md` has a troubleshooting table. `python -m voltix.admin health` checks the install. Logs: `data/voltix.log`. Report a problem with: what you clicked, the message on screen, and the last 20 lines of the log.
