# VOLTIX Runtime

AI inference benchmarking and optimization.

**Status (Phase 5 start, v0.5.0):** audited demo build. Two backends, fair comparisons and evidence-based findings. **Not validated as production software**: see [AUDIT.md](AUDIT.md) for what was verified and what is still open (never run on a real GPU or a Hub model; no authentication).
- **Simulated (demo mode):** an analytic model. Needs no GPU or model. Always labelled SIMULATED.
- **Hugging Face Transformers (real):** executes a model with PyTorch on this machine and records MEASURED timings. **Verified on CPU only** (see [Verification status](#verification-status)). The CUDA path has never run on a real GPU.

## Launch

Full step-by-step instructions for Windows, macOS and Linux, data location, security notes and troubleshooting are in **[SETUP.md](SETUP.md)**. In short, from the project folder:

```
python -m venv .venv
# activate:  Windows  .venv\Scripts\activate     Mac/Linux  source .venv/bin/activate
python -m pip install -r requirements.txt
python check_setup.py                    # read-only self-check
python -m streamlit run app.py           # open http://localhost:8501
```

Real inference additionally needs `python -m pip install -r requirements-hf.txt` and a restart. The audit status of this build is in **[AUDIT.md](AUDIT.md)**.

## Real GPU benchmark (Phase 5)

**[GPU_BENCHMARK.md](GPU_BENCHMARK.md)** explains how to run a first real GPU benchmark (a free Colab notebook is included: `VOLTIX_GPU_benchmark.ipynb`) and import the results with **Benchmark History > Import**. The headless runner is `run_real_benchmark.py`. The GPU path has not yet been run on a real GPU.

## Running a real benchmark

1. **Run Benchmark** page, choose **Hugging Face Transformers**.
2. Model: a **local folder** or a Hugging Face model id (`org/name`). No model handy? Use the page's tiny-model button: it creates a small *randomly initialised* model on local disk to exercise the pipeline offline. Its speed says nothing about real models and it generates meaningless text.
3. Device: `auto` (GPU if available, else CPU), `cpu`, `cuda` or `cuda:N`. Precision: fp32, fp16, bf16.
4. **Downloading is off by default.** Only local folders and your existing Hugging Face cache are used unless you tick *Allow downloading*. Large models can be many GB. `trust_remote_code` is never enabled.
5. Run, inspect, **Save**. Runs are tagged MEASURED and appear in History, Compare and exports like any other.

### How measurements are taken

- Each iteration calls `generate` on a batch of **seeded synthetic prompts** (random token ids, no tokenizer) with greedy decoding and **exactly** `output_tokens` new tokens (EOS suppressed). If a model returns a different count the run fails instead of reporting a wrong number.
- **Latency:** wall clock around `generate()`, with a CUDA synchronize before and after on GPU.
- **TTFT:** a stopping criterion fires after every generated token; the first call (after a CUDA synchronize) timestamps the first token. It covers `generate()` setup + prefill + first decode step.
- **Throughput:** total generated tokens / total measured latency. **TPOT:** (latency - TTFT) / (tokens - 1).
- **Memory:** on GPU, `torch.cuda.max_memory_allocated` (tensor memory only; excludes the CUDA context and allocator cache). On CPU, the **peak RSS of the whole Python process** counted from just before model loading, so it includes the interpreter, torch and Streamlit. It is labelled as such and is not "model memory".
- Not captured: GPU utilization, power, clocks, temperature, multi-GPU, output quality, concurrent-request load.

### What gets recorded with every run

Requested device and the device actually used; torch, transformers, Python and OS versions; CPU model, core count, RAM and torch threads; each GPU's name, memory, compute capability and driver (when present); model class, parameter count, dtype, context limit and commit hash; load time; and the measurement method text above. **Runs that are refused (no GPU, unsupported precision, missing model) are saved as failed runs with the reason and the hardware that was found.**

### Unsupported hardware and missing dependencies

| Situation | What happens |
|---|---|
| torch/transformers not installed (or installed but broken) | Backend shows as unavailable with an install hint. No run is created and nothing is faked. |
| `cuda` requested, no usable GPU | Failed run explaining why (e.g. CPU-only torch build or no driver) and listing what was found. |
| bf16 on a GPU older than compute capability 8.0 | Refused; suggests fp16/fp32. |
| fp16 on CPU | Refused as not representative; use fp32/bf16 on CPU. |
| int8 / int4 | Refused: quantization is not implemented. |
| Out of memory, context window exceeded, model not found offline, unreadable folder | Failed run with a specific message. |

## Optimize (Phase 3)

The **Optimize** page turns saved runs into findings. Nothing on it is a prediction: every number is a measured difference between saved runs, shown with its uncertainty.

- **Fairness.** Each pair of runs is classified from its setup alone: *controlled* (one setting differs), *replicate* (identical setup, measures noise), *several settings changed* (no single cause can be named) or *not like-for-like* (different model, prompt/output length, backend, or simulated vs measured; no metric is compared). Software differences are flagged.
- **Uncertainty.** Percent changes carry a seeded 95% bootstrap interval (2,000 resamples). "Better" or "worse" requires the interval to exclude zero and the change to reach a minimum size (default 2%, adjustable). Changes no larger than the run-to-run difference between replicate runs are not reported as effects. Metrics with one value per run (GPU peak memory) get no interval and no confidence claim.
- **Confidence** (high / medium / low / insufficient) comes from listed checks: single-factor attribution, iteration count, noise, drift, warm-up, matching software, replication, interval width. Each check is shown.
- **Trade-offs.** A change that helps one metric and hurts another is shown as a trade-off, never as a win. "Outperformed" is claimed only from like-for-like comparisons.
- **Cost** (optional): you enter an hourly price per device; cost per 1M output tokens is derived from the measured throughput change. It assumes a fully busy device and ignores load and idle time. Refused for simulated data.
- **Not yet measured.** Untried settings are listed with no numbers.
- **Memory.** CPU memory is whole-process peak RSS and is shown for information only, never used for a verdict.
- Simulated runs are analysed to demonstrate the workflow and are labelled "not evidence". Compare Runs uses the same fairness and interval logic. Exports: study JSON, metrics CSV, Markdown report.

## Pages

Overview, Run Benchmark, Compare Runs, Optimize, Results and Reports, Benchmark History, System Information. Every page, run, chart and export states whether data is SIMULATED or MEASURED; comparisons that mix the two are flagged. Recommendations are rule-based, show the evidence they fired on, and give no GPU advice for CPU runs.

## Verification status

Checked in the environment this was built in (2 vCPU Intel Xeon, 8 GB RAM, **no GPU**, torch 2.14.1, transformers 5.20.1):

- **All automated tests pass** (251 with torch installed; 217 plus 4 skipped modules without it), including statistical calibration of the engine on synthetic data with known effects (false-positive rate on identical setups, power for a 5% effect, 95% interval coverage ~96%).
- Most tests need neither torch nor a GPU: device and precision rules, CUDA call sequence and units (against a *fake* `torch.cuda`), timing logic (scripted clock and stub model), missing dependencies, failure handling, storage and exports.
- **A real CPU sweep** (tiny model, fp32/bf16, batch 2/4, replicates) was run through the runner, database and study builder; the test asserts structure and honesty, not speed.
- **Real CPU inference was executed** end to end with a tiny random-weight Llama in fp32 and bf16: throughput matched an independent recomputation from the samples, TTFT never exceeded latency, and every sequence produced the exact token count.

**Not verified:**
- Any run on a real CUDA GPU. The GPU code (synchronize, `max_memory_allocated`, device properties, bf16 capability rule) is covered only by fake-device tests.
- Any pretrained model from the Hugging Face Hub, and the *Allow downloading* path (the build environment had no access to the Hub).
- Other torch/transformers versions (the `dtype` vs `torch_dtype` switch for older transformers is tested by logic only).
- The Optimize page was checked in desktop Chromium on synthetic measured data; not reviewed at phone width.
- The optimizer on real GPU runs or real Hub models: only synthetic runs with known effects and tiny-model CPU runs were used.

## Architecture

```
app.py                       Streamlit entry (st.navigation, six pages)
ui/                          theme, components, charts, pages
voltix/
  schemas.py                 typed dataclasses (BenchmarkConfig/Run/Metrics, DataSource, ...)
  validation.py              input limits, model-id and device checks, name sanitising
  metrics.py                 percentiles, throughput, TTFT, TPOT, deltas
  estimation.py              analytic model (simulation + recommendations)
  backends/
    base.py                  InferenceBackend interface + error types
    simulated.py             demo mode
    transformers_backend.py  REAL inference (lazy torch import, timing, environment record)
    devices.py               device discovery/selection and precision rules (pure logic)
    vllm_backend.py          placeholder: not implemented
  hostmem.py                 host RAM / RSS / CPU model helpers
  testmodel.py               tiny random-weight model generator for offline testing
  runner.py                  backend-agnostic orchestration
  stats.py / fairness.py     bootstrap intervals; comparability rules
  optimize.py                study builder: findings, confidence, trade-offs, cost, experiments
  recommendations.py         explainable rules
  compare.py / exports.py    comparison; CSV, JSON, Markdown
  db.py / demo.py / sysinfo.py
check_setup.py                read-only setup self-check
SETUP.md / AUDIT.md          setup + troubleshooting; audit status
tests/
```

Database: `data/voltix.db` (override with `VOLTIX_DB_PATH`).

## Roadmap (see AUDIT.md for the prioritised list)

1. **Run on a real GPU** and fix whatever the fake-device tests could not catch; compare against the simulation's trends.
2. Test a real pretrained model including the download path; add gated-model/token handling.
3. GPU utilization, power and clock sampling; multi-GPU.
4. Background execution and cancellation (Streamlit currently blocks while a run executes; a huge model can exhaust RAM and kill the process).
5. Real prompt datasets and concurrent-request load testing; an output-quality check for quantized models.
6. Quantization (bitsandbytes) and vLLM as a second real backend.
7. Database migrations; visual QA in a browser, including phone width.
