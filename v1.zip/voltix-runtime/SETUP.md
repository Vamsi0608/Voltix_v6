# Setting up VOLTIX Runtime

Plain steps for Windows, macOS and Linux. Nothing is installed outside the project folder (a virtual environment, `.venv`, holds the packages).

## 1. What you need

- **Python 3.10 or newer** (3.11 or 3.12 recommended). Check with `python --version` (Windows: also try `py --version`; Mac/Linux: `python3 --version`). Get it from python.org; on Windows tick **"Add python.exe to PATH"** in the installer.
- About 300 MB of disk for the demo mode. Real inference adds PyTorch (roughly 0.3 GB for the CPU build, over 2 GB with NVIDIA CUDA libraries) plus any model you download.
- No GPU is needed for the demo mode or for small CPU benchmarks.

## 2. Install and start (demo mode)

Open a terminal **inside the unzipped `voltix-runtime` folder**.

**Windows (Command Prompt or PowerShell)**
```
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python check_setup.py
python -m streamlit run app.py
```
If PowerShell refuses to activate: `Set-ExecutionPolicy -Scope Process RemoteSigned`, then activate again. If `python` is not found, use `py` instead.

**macOS / Linux**
```
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python check_setup.py
python -m streamlit run app.py
```

Open **http://localhost:8501** if the browser does not open by itself. Stop the app with **Ctrl+C** in the terminal.

Every later session: open a terminal in the folder, **activate the environment again** (the `activate` line), then run the last line. The prompt shows `(.venv)` when it is active.

`python check_setup.py` is a read-only self-check. It tells you what is missing and how to fix it.

## 3. Real inference (optional)

In the same activated environment:
```
python -m pip install -r requirements-hf.txt
```
then **stop and restart the app** (it checks for these packages at startup).

- NVIDIA GPU on Windows or Linux: the default pip build may be CPU-only. Get the install command for your driver from https://pytorch.org/get-started/locally/ first, then `python -m pip install "transformers>=4.50"`.
- First test: on the Run Benchmark page choose **Hugging Face Transformers**, click **Create tiny test model** (a random-weight toy model; it proves the pipeline works and says nothing about real models), and run it.
- Real models: enter a repo id such as `org/name` and tick **Allow downloading** (needs internet), or point to a local model folder. Gated or private models are not supported (no access token is accepted).
- Models run with `trust_remote_code` **off**: models that need custom code will not load.

## 4. Where your data lives

- Runs are stored in `data/voltix.db` (SQLite). Set the environment variable `VOLTIX_DB_PATH` to use another file.
- **Back up** by copying that file while the app is stopped. Exports (JSON, CSV, Markdown) are one-way downloads; there is no import.
- The database records the machine's CPU/GPU model, RAM, software versions and the **model path you entered** (a local path can contain your user name). Check exports before sharing them.

## 5. Security notes

- The app has **no login** and listens on `127.0.0.1` only (this computer). Do not change the address to `0.0.0.0` or expose the port to a network without an authenticating proxy in front: anyone who can open the page can run benchmarks, read saved runs and probe which folders exist on the machine.
- Models from the internet are third-party code and data. Use trusted repositories only.
- The project has not had an independent security review. See `AUDIT.md`.

## 6. Troubleshooting

| What you see | Cause and fix |
|---|---|
| `'streamlit' is not recognized` / `command not found` | The environment is not active or packages are not installed. Activate `.venv`, run `python -m pip install -r requirements.txt`, and start with `python -m streamlit run app.py`. |
| `Missing dependencies: torch, transformers` | Real inference needs the optional packages. `python -m pip install -r requirements-hf.txt` in the environment that runs the app, then restart it. |
| `No module named ...` | Wrong Python. Run `python check_setup.py`; it names the interpreter's missing packages. |
| `Port 8501 is already in use` | VOLTIX is already running in another window, or another program uses the port. Close it, or `python -m streamlit run app.py --server.port 8502`. |
| `Storage problem: Could not open the database ... not a SQLite database` | The file at `data/voltix.db` (or `VOLTIX_DB_PATH`) is damaged or not a VOLTIX database. Move it aside; a new one is created on next start. |
| `...written by a newer version of VOLTIX` | Run the newer VOLTIX, or use a different `VOLTIX_DB_PATH`. The file is not modified. |
| `N saved run(s) could not be read` | A row is damaged. The rest of your history still works; open the notice and use **Remove unreadable runs**, or keep the file for inspection. |
| `CUDA requested but not available` | No NVIDIA GPU/driver, or a CPU-only torch build. Choose `cpu` or `auto`. |
| `is not in the local Hugging Face cache and downloading is turned off` | Tick **Allow downloading** (needs internet) or give a local folder. |
| `model files ... GB but only ... GB of RAM is free` | A local model larger than free memory was refused before loading. Close programs or choose a smaller model. |
| Memory shows `n/a` for a CPU run | Memory reading failed on this OS. Windows and macOS support is new and untested on real machines (see `AUDIT.md`); please report it. |
| A real run seems stuck | Runs happen in the background with a progress bar and a **Cancel** button (stops at the next generated token). Loading or downloading a model cannot be interrupted. Runs also stop on their own after 30 min total or 5 min per iteration (`VOLTIX_MAX_RUN_SECONDS`, `VOLTIX_MAX_ITERATION_SECONDS`; `0` disables). |

## 7. Tests (developers)

```
python -m pip install -r requirements-dev.txt
python -m pytest -q
```
Most tests need neither torch nor a GPU; those that use torch skip themselves when it is not installed.
