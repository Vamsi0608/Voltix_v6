@echo off
rem Start VOLTIX on this computer (127.0.0.1 only). See SECURITY.md before sharing it.
cd /d "%~dp0"
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python check_setup.py
if errorlevel 1 exit /b 1
python -m streamlit run app.py %*
