# VOLTIX security notes

**Status: suitable for a supervised demo on your own machine, or a controlled pilot behind HTTPS with an access token. Not hardened for public internet exposure. No independent security review has been done.**

## Modes
| Mode | How | Who can use it |
|---|---|---|
| Local (default) | `streamlit run app.py` (binds 127.0.0.1, no login) | Only the person at this computer |
| Shared | set `VOLTIX_ACCESS_TOKEN` (16+ random characters) and put an HTTPS reverse proxy in front | Anyone holding the token |

The app **refuses to serve** on a non-loopback address without a valid token. It also refuses a token that is too short or has leading/trailing whitespace.

```bash
# Linux/macOS
export VOLTIX_ACCESS_TOKEN="$(python -c 'import secrets;print(secrets.token_urlsafe(24))')"
# Windows PowerShell
$env:VOLTIX_ACCESS_TOKEN = python -c "import secrets;print(secrets.token_urlsafe(24))"
```
Example Caddy proxy (automatic HTTPS): `voltix.example.com { reverse_proxy 127.0.0.1:8501 }` — keep VOLTIX itself on 127.0.0.1.

## What the token mode does
- Nothing (pages, data, runs) is shown before sign-in; the token field is masked and never logged or echoed back.
- Constant-time comparison; after 5 wrong attempts, attempts are refused for 10 s, doubling up to 15 min (process-wide). Failures are logged without the attempted value.
- **Restricted mode** (on whenever a token is set, or `VOLTIX_RESTRICTED=1`): local model folders must be inside `VOLTIX_MODEL_DIR` (default `data/models`; symlink and `..` escapes are resolved and rejected); Hugging Face downloads are off unless `VOLTIX_ALLOW_DOWNLOADS=1`.

## What it does NOT do (unresolved risks)
1. **One shared token, no user identity.** Everyone with it sees, imports and deletes the same runs. Use one deployment and database per customer. No per-user audit trail.
2. **Session state is in memory.** A signed-in browser stays signed in until the tab/session ends; there is no idle timeout or sign-out button.
3. **No TLS inside the app.** Without the HTTPS proxy the token crosses the network in clear text.
4. **Brake is process-wide.** An attacker can lock out legitimate users for up to 15 min (denial of service) — accepted over allowing unlimited guessing.
5. **Authenticated users can consume the machine's CPU/GPU/RAM** (one benchmark at a time, 30 min cap; model sizes are only pre-checked for local folders).
6. **Model files execute code paths of PyTorch/Transformers.** `trust_remote_code` is never enabled, but only load models you trust.
7. Streamlit itself may contact an external host (e.g. checkip) to display its Network URL when bound to a non-loopback address; usage statistics are off.
8. Data at rest (SQLite file) is not encrypted. Deleting runs in the app removes the rows; delete the database file to remove everything. Backups are your responsibility.

## Already in place
Output escaping for user-controlled text (names, notes, model ids) in HTML and Markdown exports; JSON import size/structure limits (50 MB, 100k samples) with no code execution and no overwrite of existing runs; server-side upload cap 50 MB; XSRF/CORS protection on; parameterised SQL; dependency audit clean (`pip-audit`, 2026-10-25).

## Reporting
Run `python -m pip install pip-audit && pip-audit` before each release.
