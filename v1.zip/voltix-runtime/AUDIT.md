# VOLTIX Runtime: audit status (v0.5.0 + work packages 1–6, 2026-10-26)

## Current status

**Classification: B (supervised demo ready). Not C (controlled customer pilot ready). Not D (production ready).** Nothing here is a certification.

Automated tests: **516 passed** (with torch; Linux, Python 3.13, CPU only). In a clean install without torch: 406 passed, 22 skipped (WP4 count; later tests were added). `pip-audit`: no known vulnerabilities (2026-10-26). Every work package has an evidence section below (WP1–WP5; WP6 below).

### What stands between B and C (all must be closed, in this order)
1. **Real-GPU evidence.** 3 GPU rows of the validation matrix are NOT RUN; the only GPU data is one user-reported Colab T4 session (two repeats), not re-verified here. Run `python run_matrix.py` on a GPU machine and keep the result.
2. **Windows verification.** The pilot customer machine may be Windows; the launcher and memory readers are untested on any real Windows machine here.
3. **Second pair of eyes.** SECURITY.md and DEPLOY.md have not been reviewed, and the clean install has not been repeated, by anyone other than the author.
4. **Hugging Face download path** and revision pinning never exercised (no Hub access from the build environment).
5. **Support process** (who answers, how fast, how problems are triaged) is not defined; the pilot scope leaves it to be agreed.
6. Real customer-style workload (a real model of the customer's choice) run end to end by someone else, with the output reviewed.

### Unresolved defects and functional gaps
1. Model loading/download and hung GPU kernels cannot be cancelled; limits only apply at safe points (fix needs process isolation).
2. Windows/macOS memory readers and launcher unverified on real machines.
3. GPU path: one session only; no bf16 GPU run; multi-GPU, vLLM and int8/int4 real inference not implemented.
4. A Streamlit restart mid-run loses the run; one benchmark per process.
5. No database migrations beyond refusing newer versions; SQLite not in WAL mode; concurrency tested with threads only.
6. Output quality is never measured; synthetic inputs, one request at a time (no traffic/concurrency model).
7. Requirements page treats each saved run as one measurement; the 5 % "thin margin" flag is a floor, not a noise estimate (short CPU runs showed ≈10 % run-to-run CV).
8. Streamlit logs harmless 404s on `/_stcore/*` for direct deep links.

### Unresolved security risks
1. One shared token: no user identity, no per-user audit trail, no idle timeout/sign-out; TLS not enforced by the app.
2. No independent security review (reviews so far by the code's author).
3. Lockout brake is process-wide (denial of service against legitimate users, up to 15 min).
4. Import accepts any well-formed, self-consistent file as "measured"; origin cannot be proven.
5. Model paths (possibly containing user names) are stored/exported without redaction.
6. SQLite data and logs unencrypted; retention/deletion is manual (`DEPLOY.md`).
7. Downloaded models trusted from the Hub; revision pin is optional and unverified against a real Hub.

### Release checklist as of WP1 (superseded by the checklist above)
- [x] WP1 core functionality verified (independent recalculation, real tiny-model pipeline, browser E2E, mutation testing)
- [x] WP2 cancel/timeouts/progress/provenance/minimum-observation rules
- [x] WP3 token access control, fail-closed binding, restricted mode, security tests
- [x] WP4 clean install, health check, logging, backup, config example
- [x] WP5 test matrix (7 CPU rows run, 3 GPU + 1 model row NOT RUN), constraint-aware recommendations
- [x] WP6 demo script, onboarding guide, questionnaire, known limitations, draft pilot scope, sample report from real (tiny-model CPU) measurements; consistency tests
- [ ] Run the matrix on a real GPU; import and review the T4 files (limit 1 above)
- [ ] Windows end-to-end check (2)
- [ ] Independent review of SECURITY.md/DEPLOY.md and clean install by someone else (3)
- [ ] Real model through the Hub download path (4); support process (5)
- [ ] Independent security review, long-run/soak tests, monitoring, legal review of pilot terms — required before D

## WP6 evidence: pilot readiness
| Deliverable | Where | Evidence |
|---|---|---|
| Demo workflow | `pilot/DEMO_SCRIPT.md` | page names and features match the app (Requirements, Cancel, p99 n/a) |
| Sample report from real measurements | `pilot/sample_report/` (regenerate: `make_sample_report.py`) | 4 real CPU runs of the tiny random-weight model; files import as MEASURED with the procedure block (tests); README states the model says nothing about real models |
| Onboarding guide | `pilot/ONBOARDING_GUIDE.md` | steps follow the verified install; Python version claim corrected to "only 3.13 tested" |
| Feedback questionnaire | `pilot/FEEDBACK_QUESTIONNAIRE.md` | — |
| Known limitations | `pilot/KNOWN_LIMITATIONS.md` | consistent with this audit; states no certifications, SLA, warranty or references |
| Draft pilot scope | `pilot/PILOT_SCOPE_DRAFT.md` | marked draft/not a contract; success defined by the customer; no promised speed-up, saving or uptime; data statement corrected (Streamlit may contact an external service to show its network URL) |
Tests: `tests/test_wp6_pilot.py` (9): documents exist, referenced files exist, sample files import as measured, no un-negated promise/certification/testimonial wording.
Not verified: that a real prospective customer finds the material clear (no pilot customer has used it); legal adequacy of the scope draft.

---

# Phase 4 audit (historical record; items below were current on 2026-10-23 and are SUPERSEDED where the status above differs)

## What was verified

| Area | Evidence |
|---|---|
| Clean install | Fresh virtual environment from `requirements.txt` only (no torch): every page loads on an empty database; 217 tests pass, 4 torch-dependent modules skip themselves. |
| Browser workflow | Chromium: load demo data, run, save, download JSON / summary CSV / samples CSV / Markdown (all parse), history count, Optimize and Compare pages, no page errors, no "Deploy" button. |
| Persistence | 13 saved runs survived a server restart. 100 runs of 1,000 samples each: 12.7 MB database, 0.19 s to read all. 4 threads saving 40 runs concurrently: no errors, no lost rows. |
| Exports | JSON round-trips to an identical run. CSV neutralises formula injection (`=`, `+`, `-`, `@`, tab). Markdown now escapes names, notes and findings (HTML, links, headings, table breaks). |
| Failure handling | Garbage file as database, newer-version database, damaged row, missing/empty/invalid model folders, file instead of folder, URLs, traversal and Windows paths as model ids, offline Hub id, CUDA on a CPU-only machine, fp16 on CPU: each gives a specific message and no crash. |
| Dependencies | `pip-audit` on the base and the torch/transformers environments: no known vulnerabilities after the fixes below (it found 35 Pillow advisories in 12.x). Scan reflects advisories known on the audit date only. |
| Tests | 251 automated tests pass with torch installed. |

## Findings and fixes

| # | Severity | Finding | Status |
|---|---|---|---|
| 1 | High | One damaged row in the database made History, Optimize, Compare, Results and Overview crash with a traceback. | **Fixed.** Damaged rows are skipped, reported, and can be removed from the UI. Tests for all five pages. |
| 2 | High | On Windows (and partly macOS) total RAM, current and peak process memory were unavailable, so CPU runs had no memory figure. | **Code added, unverified.** Windows (ctypes) and macOS (sysctl/ps) readers written; only structure sizes and fallback logic could be tested here. Must be checked on real machines. |
| 3 | High | The server listened on all network interfaces with no login. | **Fixed** by default: `127.0.0.1` only. Still has no authentication (see open items). |
| 4 | Medium | A database from a newer version was opened and its version number silently rewritten. | **Fixed.** Refused with an explanation; file untouched. |
| 5 | Medium | Markdown exports passed run names, notes and finding text through unescaped (HTML, links, headings, table breaks). | **Fixed**, with tests. |
| 6 | Medium | Loading a local model larger than free RAM could exhaust memory and kill the app. | **Partly fixed.** Local folders are checked against free RAM before loading (file size is a lower bound). Hub models are not checked. |
| 7 | Medium | Pillow 12.x (via Streamlit) had 35 published advisories. | **Fixed:** `streamlit>=1.66.1`, `pillow>=13.0.0`. VOLTIX itself does not process uploaded images. |
| 8 | Medium | Old torch/transformers combinations load pickle-based `.bin` weights without safety restrictions. | **Mitigated by version floor** (`torch>=2.6`, `transformers>=4.50`). Not tested against a malicious file. |
| 9 | Low | Install/ database / model errors did not say what to do (e.g. "Install with pip install torch transformers" ignoring the environment and restart). | **Fixed**; `SETUP.md` and `check_setup.py` added. |
| 10 | Low | The Optimize page scrolled sideways at phone width. | **Fixed** (tables scroll inside their box; charts are clipped). Only horizontal overflow and the top of one page were checked at phone width. |
| 11 | Low | A leftover duplicate module (`hf_support.py`) with a second, inconsistent memory helper. | **Removed.** |
| 12 | Low | Streamlit logs harmless 404s for `/_stcore/*` when a deep link such as `/history` is loaded directly. | Observed, not changed. Pages work. |

## Open gaps as of 2026-10-23 (partly superseded: cancellation, authentication, backup, logging and health checks have since been added)

**Security**
- No authentication, authorisation or multi-user separation. Anyone who can reach the port can use everything, including entering local folder paths (which reveals whether a folder exists). Localhost-only binding is the only control.
- No independent security review or penetration test. The review above was by the same author as the code.
- No pinning of model revisions or hash verification for downloaded models; downloads trust the Hub and the network.
- Run records include the model path you typed (may contain a user name). No redaction option.
- No audit log.

**Reliability**
- Real benchmarks run in the background with Cancel, but **model loading/download and hung GPU kernels cannot be interrupted**; limits (30 min run / 5 min iteration) apply only at safe points. One benchmark at a time per process.
- SQLite is not in WAL mode; concurrent use was tested with threads only, not several app processes. No migrations beyond refusing newer versions. No backup, restore or import; exports are one-way.
- A damaged database file cannot be repaired by the app.

**Correctness and coverage**
- **Never run on a real GPU.** CUDA code is tested only against a fake device.
- **No pretrained model from the Hugging Face Hub was run**, and the download path was not exercised (no network access to the Hub from the build environment). Only a tiny random-weight model on a 2-vCPU CPU was measured.
- Simulated results come from an analytic model that has not been compared against real hardware; they are labelled as such everywhere.
- The optimization engine's statistics were calibrated on synthetic data with known effects and on a tiny model. They were not checked against real multi-GPU or production measurements. Quantisation (int8/int4) and vLLM are not implemented.
- Memory on CPU is whole-process peak RSS and is never used for a verdict.
- Output quality is not measured: precision changes are speed/memory comparisons only.

**Platforms and usability**
- Tested on Linux with Chromium only. Windows and macOS: setup steps and memory readers are untested on real machines. Firefox, Safari, Edge: untested.
- Phone-width layout and accessibility (screen readers, keyboard navigation, contrast audit) were not reviewed beyond the overflow fix.
- Dependency versions have lower bounds only; tested with Python 3.13, Streamlit 1.66.1, Plotly 7.1, pandas 3.x, numpy 2.5, torch 2.14, transformers 5.20.

## Before showing this to a paying customer (2026-10-23 advice; see 'What stands between B and C')

1. Run `python check_setup.py` and the demo on the exact machine you will present from. Check that RAM and CPU memory figures appear (finding 2).
2. Use demo mode and the tiny test model; say plainly that nothing is measured on real hardware or real models yet.
3. Do not offer it on a shared network, as a hosted service, or with a customer's confidential models until authentication, cancellation and real-GPU validation exist.
4. Do not quote performance or savings from simulated runs.

## Suggested next steps (in priority order)

1. Run on a real NVIDIA GPU with a real downloaded model; fix what the fake-device tests could not catch.
2. Verify Windows and macOS memory readers and the setup steps on real machines.
3. Background execution with cancellation and a time limit.
4. Authentication (or a documented reverse-proxy setup), then a third-party security review.
5. Database backup/restore/import, WAL mode and migrations.


---

# Work package 1: core functionality (verified 2026-10-24)

Scope: Import, Optimize, comparison, history, report export; input schemas, missing values, units, failed runs, calculation correctness; recommendations tied to real measurements.

**Provenance note.** When this work package started, the repository already contained import-hardening code, two test files (`test_wp1_calculations.py`, `test_wp1_import_hardening.py`) and a recommendation-threshold change that were not in the last delivered build. They were reviewed and kept, not assumed correct: every claim below was re-checked by the new tests, the mutation run and the browser run.

## Requirements and evidence

| Requirement | Evidence | Result |
|---|---|---|
| Import validates schema, types, ranges, units, consistency | `tests/test_wp1_import_hardening.py`: 50+ rejected-file cases (edited metrics, wrong units, NaN/inf, bool-as-number, path-like run ids, contradictory device/data source, failed run with samples, huge/nested files), each with a specific message and no Python internals. Valid files from VOLTIX itself (simulated and measured) always round-trip. | Pass |
| Import never overwrites or relabels | Duplicate id is refused and the stored run is unchanged; measured stays measured. | Pass |
| Failed and missing-value runs | Failed runs import, stay failed, are excluded from comparison; missing memory is left out, never zero. | Pass |
| Metric calculations correct | `tests/test_wp1_calculations.py` and `tests/test_wp1_pipeline.py`: hand-worked example, independent numpy reference over 32 parameter combinations, percentile equals numpy, scale/batch invariants, units (ms, tokens/s, GB = 10^9 bytes). | Pass |
| Optimize/comparison calculations correct | Study change % equals a hand calculation from the stored runs; interval brackets the estimate; exports (study JSON/CSV/Markdown) carry the same numbers; CPU process memory never produces a verdict or appears as finding evidence; p99 not assessed under 100 iterations; cost formula hand-computed. | Pass |
| Recommendations use actual measurements | Tail, prefill and cold-start evidence quotes the run's own percentiles, shares and first-iteration time; rules do not fire below their thresholds or without enough iterations; no rule fires on a metric the run lacks; measured advice never mixes in catalog estimates; every recommendation declares kind and how to verify. | Pass |
| End to end on real measurements | `tests/test_wp1_pipeline.py`: tiny model on CPU through the runner CLI, 4 JSON files, import, history, compare, optimize, every export, each number re-derived independently from the raw stored samples; five UI pages render with no exception. | Pass (CPU, tiny model) |
| Same workflow in a real browser | Chromium: import of 4 files, Optimize (confidence, controlled comparison), study JSON/CSV/Markdown downloads (all parse, all `measured`), Compare, Results and report download; no page errors. | Pass (CPU, tiny model) |
| Tests detect wrong calculations | Mutation run: 18 deliberate code breakages (units, off-by-one percentile, sign/direction, removed checks, wrong CSV column/data source, tail rule on the wrong percentile, thresholds, sort order). 16 were caught immediately; 1 survivor was a real gap (history sort order), now covered by a test that kills that mutation; 1 survivor (reordering CSV columns) is an equivalent mutant that changes no value. | Pass |

## Defects found and fixed in WP1

| # | Defect | Fix |
|---|---|---|
| W1 | On CPU runs, "memory nearly exhausted" called whole-process RAM "device memory" and could append catalog-based estimates to a measured run. | Wording now says process peak RAM of this computer; estimates only appear for simulated runs. Tested. |
| W2 | A "tail latency" recommendation told users to re-run with 50-100 iterations although p99 needs 100. | Now quotes the shared threshold. |
| W3 | Finding cards for CPU runs showed a meaningless "peak memory -77.8%" line (process RAM of a tiny model). | Not-assessed CPU memory is no longer quoted as evidence (still in the metrics table with its note). Tested both ways. |
| W4 | Newest-first ordering of history was untested (found by mutation). | Test added. |

## Test results (actual)

- Full suite with torch installed (Linux, Python 3.13): **406 passed, 0 failed**.
- Same suite from a fresh copy in a torch-free environment: **360 passed, 0 failed, 16 skipped** (the skipped tests need torch).
- Not run: any test on a GPU, Windows or macOS.

## What WP1 did NOT verify

- The imported **Tesla T4** results from your Colab run were not available to me, so the import and Optimize paths have not been exercised on those real GPU files in my environment. The validation logic is covered by CPU-measured files and synthetic GPU-shaped fixtures. Please import your T4 files and report any rejection message.
- Statistics were calibrated on synthetic data and a toy model, not on large real workloads.
- Throughput of a real GPU model, any model other than the tiny test model, and bf16/fp16 on a GPU (not on the CPU) remain unmeasured by the automated tests.
- Customer-defined constraints (latency/throughput/memory limits) are not yet implemented in recommendations: that is work package 5.

# Unresolved defects and risks (as of WP1; superseded by the lists above)

**Defects / functional gaps**
1. No run cancellation, time limit or per-iteration timeout (WP2).
2. Windows and macOS memory readers unverified on real machines.
3. GPU path verified only by your single T4 session (not re-verified by automated tests here); no bf16-capable GPU run; multi-GPU not supported.
4. Model revision/commit is recorded only when the Hub provides it (`commit_hash` may be null); NVIDIA driver version is not recorded; workload settings and timestamps are recorded.
5. Recommendations ignore customer-defined constraints (WP5).
6. Streamlit logs harmless 404s on `/_stcore/*` when a deep link is opened directly.
7. No database backup/restore, migrations beyond refusing newer versions, or WAL mode.

**Security risks (open)**
1. No authentication or authorization; localhost-only binding is the only control.
2. No independent security review; the reviews so far are by the code's author.
3. Import accepts any well-formed file: it cannot prove origin, and a hand-written, self-consistent file would be accepted as "measured".
4. Downloaded models are not revision-pinned or hash-verified.
5. Model paths (possibly containing a user name) are stored and exported without redaction.
6. No audit log, retention or deletion policy beyond manual delete.

# Classification criteria (requirements checked, not aspirations)

| Level | Requirement | Status |
|---|---|---|
| A. Internal prototype | Runs and is tested by the developers | Met |
| **B. Supervised demo ready** | Documented setup tested from a clean install; end-to-end workflow verified; simulated/measured clearly separated; failure messages; known limitations documented; local-only by default | **Met on the evidence above** (Linux, CPU and one T4 session; Windows reported working by the owner but unverified here) |
| C. Controlled customer pilot ready | B plus: cancellation and time limits, repeatable measurement procedure, verified GPU workflow on supported hardware matrix, authentication or a protected access path, security tests, pilot documents, support process | **Not met** (WP2-WP6 outstanding) |
| D. Production ready | C plus independent security review, monitoring, backups, long-run reliability, support and legal readiness | **Not met** |

# Prioritized release checklist

Done: [x] WP1 core functionality verification.

Next, in order (each must be verified before moving a level):
1. [ ] **WP2** cancellation, timeouts, progress/failure states, documented warm-up/measurement/repetition procedure, full provenance record (revision, driver, timestamps).
2. [ ] Import and verify your real T4 files; record the result.
3. [ ] **WP5** hardware/model test matrix; constraint-aware recommendations; repeat-run comparability checks.
4. [ ] **WP3** authentication or documented authenticated access path; security tests; secret handling; deletion policy.
5. [ ] **WP4** health check, logging, config example, clean-install test by someone who did not write the code.
6. [ ] **WP6** pilot scope, onboarding guide, questionnaire, known-limitations document, sample report from real measurements.
7. [ ] Independent security review (required before D, recommended before any external access).
8. [ ] Windows and macOS verification on real machines.


## WP2 evidence: benchmark reliability

| Requirement | Evidence |
|---|---|
| Safe cancellation | `voltix/control.py`; `tests/test_wp2_control.py` (20), `tests/test_wp2_jobs_cli.py` (10): cancel before/mid-run, per-token cancel on real tiny model, Ctrl+C path (exit 130), browser test (Cancel button → CANCELLED shown, Run re-enabled) |
| Configurable timeouts | `RunLimits`, env `VOLTIX_MAX_*`, CLI `--max-run-seconds/--max-iteration-seconds`; exit code 4 tested |
| Progress/failure states | background job + progress bar; FAILED/CANCELLED/TIMED_OUT shown, imported, excluded from comparison |
| One run at a time | `JobManager` lock; test + browser (Run disabled while running) |
| Consistent procedure | `MEASUREMENT.md`, `environment.procedure` (tests in `test_wp2_provenance.py`) |
| Provenance | model id, `--revision`/`revision` (validated, passed to `from_pretrained`), commit hash, versions, driver, timestamps |
| Variability/percentiles only if supported | central `MIN_OBSERVATIONS` (p95 ≥20, p99 ≥100, std ≥5), boundary tests, exports show reason |
| Repeatability | CPU tiny model 5×30: CV 3.4 % (MEASUREMENT.md); not evidence for GPUs |

Full suite: 450 passed (with torch).

Not verified / still open: hung-kernel and load-time interruption (needs process isolation); revision pinning against the real Hub (no Hub access here); cancel on a real GPU; the limits are per-process, not per-user; state is lost if the Streamlit process restarts mid-run.

Classification remains **B (supervised demo ready)**.


## WP3 evidence: security

| Requirement | Evidence |
|---|---|
| Access control | `voltix/security.py`, `ui/auth.py`; token gate verified in the browser (login shown, wrong token rejected, right token opens, a new session must sign in again, token absent from server log) |
| Fail-closed exposure | non-loopback bind without a valid token → app refuses to serve (browser-verified on `--server.address 0.0.0.0`; test with `get_option` patched) |
| Brute-force brake | `LoginLimiter` unit tests (block after 5, no compare while blocked, backoff cap 900 s, reset on success) |
| Filesystem/download confinement | restricted-mode tests: symlink, `..`, absolute path, download flag; applied inside `validate_config`, so UI, CLI and jobs all obey it |
| Uploads | 50 MB server cap (`.streamlit/config.toml`), importer structure/size limits (WP1 tests) |
| Dependencies | `pip-audit` on requirements and on the installed environment: no known vulnerabilities |
| Secrets | token only from environment; never rendered, logged or stored (log grep = 0) |

Tests: `tests/test_wp3_security.py` (21). Full suite: 471 passed.

Unresolved security risks: see SECURITY.md "What it does NOT do" (shared token / no user identity, no idle timeout or sign-out, no TLS in-app, lockout DoS, DB not encrypted, no independent review, no per-user deletion/retention policy beyond manual delete). Not tested: behaviour behind a real reverse proxy; WebSocket origin handling with a proxy host name.

Classification: **B**. Moving to C additionally needs the WP4 deployment checks, a pilot-scope with the data-handling terms, and a person other than the author reviewing SECURITY.md.


## WP4 evidence: deployment and usability

| Requirement | Evidence |
|---|---|
| Reproducible setup | zip unpacked into an empty folder, fresh venv, `pip install -r requirements-dev.txt` (30 s), `check_setup.py` Ready, 406 tests passed / 22 skipped (torch-dependent) |
| Config without secrets | `.env.example` (all variables commented, no values); app reads environment only |
| Health checks | `python -m voltix.admin health [--url]`; tests: healthy, corrupt DB, weak token, server down; verified against a running clean-install server (`web_server ok`) |
| Logging | rotating file, redaction of the token, idempotent, falls back to stderr when the path is unwritable (tests); job and sign-in events logged |
| Backup/restore | online SQLite backup; restore equality test, no overwrite, source unchanged |
| Operator docs | `DEPLOY.md` |

Tests: `tests/test_wp4_ops.py` (9). Full suite with torch: 480 passed.

Not verified: Windows launcher and Windows paths end-to-end, Docker, reverse proxy/TLS, service management, macOS, real GPU install from scratch (the user's Colab run is the only GPU evidence).
Classification: **B**.


## WP5 evidence: validation and recommendations

| Requirement | Evidence |
|---|---|
| Hardware/model test matrix, only runnable rows executed | `voltix/matrix.py`, `run_matrix.py`, `MATRIX_RESULTS.md`: 11 rows defined; 7 executed on CPU (tiny random-weight model), **6 PASS, 1 FAIL**; 4 NOT RUN (3 GPU rows: no GPU; 1 real-model row: not cached). Earlier 20-iteration pass had 4 FAIL; kept in the record with the reason the setting changed |
| Recommendations respect customer-defined limits | `voltix/constraints.py`, Requirements page, `recommend(run, constraints)`; limits on p95, mean TTFT, throughput, memory |
| No unsupported claims | p95 limit not assessed under 20 iterations; CPU process memory never compared with a device limit; unknown ≠ eligible; failed/cancelled runs ignored; simulated/measured never ranked together; "no run meets it" is not stated as "impossible" |
| Repeat comparability | identical repeats must be judged `replicate` by the existing fairness engine (matrix check + tests) |
| Tests | `test_wp5_constraints.py` (15, hand-computed expectations), `test_wp5_ui.py` (5), `test_wp5_matrix.py` (7). Mutation test of constraints logic: 7 mutants, 1 survived (completed-only filter) → test added → all 7 caught |

Full suite: 507 passed (with torch).

Findings that matter for customers: short runs are noisy (CV ≈ 10 % at 20 iterations, ≈ 5 % at 120 on this CPU); a limit passed by less than that is not reliable; the Requirements page says so. The 5 % "thin margin" flag is a floor, not a noise estimate.

Not verified: any real-model or GPU row (except the user's one T4 session); constraint results against real customer workloads; behaviour with more than a handful of saved runs.

Classification: **B**. Reaching C additionally needs WP6 pilot material, a second reviewer of SECURITY.md, a real-GPU matrix run, and pilot-scoped data terms.
