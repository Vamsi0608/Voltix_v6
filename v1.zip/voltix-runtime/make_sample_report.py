"""Generate the sample pilot report from REAL measurements made on THIS machine, using VOLTIX's own code paths.

    python make_sample_report.py [--out pilot/sample_report]

The model is VOLTIX's tiny RANDOM-WEIGHT test model on the CPU. The numbers are real measurements of that model on
this computer; they say nothing about real models or GPUs. Output: importable run JSON files, a per-run report, and a
study report (replicates, precision change, batch change), plus a README stating exactly what was run.
"""
from __future__ import annotations

import argparse
import platform
from pathlib import Path

from voltix.exports import run_to_json, run_to_markdown, study_to_markdown
from voltix.optimize import build_study
from voltix.recommendations import recommend
from voltix.runner import run_benchmark
from voltix.schemas import BenchmarkConfig, Precision
from voltix.testmodel import create_tiny_model

ITER, WARM = 100, 3


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="pilot/sample_report")
    out = Path(ap.parse_args(argv).out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    # Build the model under a short RELATIVE name so exports do not carry this computer's absolute folder paths.
    import os
    import tempfile
    work = tempfile.mkdtemp(prefix="voltix_sample_")
    os.chdir(work)
    tiny = str(create_tiny_model(Path("tiny-random-test-model")))
    tiny = "tiny-random-test-model"

    def cfg(prec, batch):
        return BenchmarkConfig(model_id=tiny, precision=prec, batch_size=batch, prompt_tokens=64, output_tokens=16, iterations=ITER,
                               warmup_iterations=WARM, seed=1, backend="transformers", hardware_id="cpu")

    plan = [("baseline fp32 b1 (run 1)", Precision.FP32, 1), ("baseline fp32 b1 (run 2, repeat)", Precision.FP32, 1),
            ("bf16 b1", Precision.BF16, 1), ("fp32 b4", Precision.FP32, 4)]
    runs = []
    for name, prec, batch in plan:
        print("running", name, flush=True)
        r = run_benchmark(cfg(prec, batch), name)
        assert r.status.value == "completed", r.error
        runs.append(r)
        (out / f"{r.run_id}.json").write_text(run_to_json(r, recommend(r)), encoding="utf-8")
    (out / "run_reports.md").write_text("\n\n---\n\n".join(run_to_markdown(r, recommend(r)) for r in runs), encoding="utf-8")
    study = build_study(runs[0], runs)
    (out / "study_report.md").write_text(study_to_markdown(study, {r.run_id: r.name for r in runs}), encoding="utf-8")
    (out / "README.md").write_text(f"""# Sample report (real measurements, tiny test model)

**What this is.** Four real benchmark runs executed by VOLTIX on {platform.platform()}, Python {platform.python_version()}, CPU only.
Each run: {WARM} warm-up + {ITER} measured iterations, prompt 64 tokens, output 16 tokens, seed 1.

**What the model is.** VOLTIX's built-in tiny *random-weight* test model. It was chosen because it needs no download. Its speed says
**nothing** about any real model, any GPU, or any saving you could expect.

**What it shows.** The shape of the output a pilot customer receives: per-run report, a replicate pair (identical setup run twice,
which measures run-to-run noise), a precision change, and a batch-size change, each with confidence statements and caveats.

**Files.** `run_*.json` can be imported on the Benchmark History page (they import as MEASURED). `run_reports.md` and `study_report.md`
are the app's own exports, unedited.

**Reproduce.** `python make_sample_report.py` (numbers will differ run to run; that variation is the point of the replicate pair).
""", encoding="utf-8")
    print("written", out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
