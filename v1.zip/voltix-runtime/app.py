"""VOLTIX Runtime: entry point.  Launch with:  streamlit run app.py"""

from pathlib import Path

import streamlit as st

from ui import auth, nav, theme
from voltix.logging_setup import configure_logging
from ui.pages import compare_runs, history, optimize, overview, requirements, results, run_benchmark, system_info

@st.cache_resource
def _logging_once():
    return configure_logging()


_logging_once()

st.set_page_config(
    page_title="VOLTIX Runtime",
    page_icon=":material/bolt:",
    layout="wide",
    initial_sidebar_state="auto",
)
theme.inject_css()
auth.gate()  # nothing below runs until the visitor is allowed (see voltix/security.py)

_logo = Path(__file__).parent / "assets" / "voltix_logo.svg"
if _logo.exists():
    st.logo(str(_logo), size="large")

nav.PAGES.update(
    {
        "overview": st.Page(overview.render, title="Overview", icon=":material/dashboard:", default=True),
        "run": st.Page(run_benchmark.render, title="Run Benchmark", icon=":material/play_circle:", url_path="run"),
        "compare": st.Page(compare_runs.render, title="Compare Runs", icon=":material/compare_arrows:", url_path="compare"),
        "optimize": st.Page(optimize.render, title="Optimize", icon=":material/tune:", url_path="optimize"),
        "requirements": st.Page(requirements.render, title="Requirements", icon=":material/rule:", url_path="requirements"),
        "results": st.Page(results.render, title="Results and Reports", icon=":material/description:", url_path="results"),
        "history": st.Page(history.render, title="Benchmark History", icon=":material/history:", url_path="history"),
        "system": st.Page(system_info.render, title="System Information", icon=":material/memory:", url_path="system"),
    }
)

st.navigation(list(nav.PAGES.values())).run()
