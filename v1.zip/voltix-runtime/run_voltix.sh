#!/usr/bin/env bash
# Start VOLTIX on this computer (127.0.0.1 only). Set VOLTIX_ACCESS_TOKEN first to serve others (see SECURITY.md).
set -euo pipefail
cd "$(dirname "$0")"
[ -d .venv ] && source .venv/bin/activate
python check_setup.py || exit 1
exec python -m streamlit run app.py "$@"
