"""Visual identity: graphite surfaces, restrained electric-cyan chrome accent.

Data series use the validated categorical palette (dark mode steps); the cyan
accent is reserved for interface chrome (active nav, primary buttons, focus).
"""

from __future__ import annotations

import streamlit as st

BG = "#0E1013"
SURFACE = "#151820"
SURFACE_2 = "#1B1F27"
BORDER = "#262B35"
TEXT = "#E6E9EE"
TEXT_2 = "#B4BBC8"
MUTED = "#8B94A3"
ACCENT = "#3DD6F5"  # brand chrome only

# Validated dark-mode categorical slots (fixed order, never cycled).
SERIES = ["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#9085e9"]
SERIES_NAMES = ["blue", "orange", "aqua", "yellow", "magenta", "violet"]
MAX_SERIES = len(SERIES)

# Status colors (fixed; always paired with an icon and a label).
GOOD = "#0ca30c"
WARNING = "#fab219"
SERIOUS = "#ec835a"
CRITICAL = "#d03b3b"

CSS = f"""
<style>
:root {{
  --bg: {BG}; --surface: {SURFACE}; --surface-2: {SURFACE_2}; --border: {BORDER};
  --text: {TEXT}; --text-2: {TEXT_2}; --muted: {MUTED}; --accent: {ACCENT};
}}
html, body, [data-testid="stAppViewContainer"], .stApp {{ background: var(--bg); }}
[data-testid="stHeader"] {{ background: transparent; }}
.block-container {{ padding-top: 2.2rem; padding-bottom: 4rem; max-width: 1280px; }}
h1, h2, h3, h4 {{ letter-spacing: -0.01em; color: var(--text); }}
h1 {{ font-weight: 700; }}
[data-testid="stSidebar"] {{ background: #0B0D10; border-right: 1px solid var(--border); }}
[data-testid="stSidebarNav"] a, [data-testid="stSidebar"] a {{ border-radius: 8px; }}
[data-testid="stSidebar"] [aria-current="page"], [data-testid="stSidebar"] a[aria-current="page"] {{
  background: rgba(61,214,245,0.10); box-shadow: inset 2px 0 0 var(--accent);
}}
.stButton > button, .stDownloadButton > button {{
  border-radius: 8px; border: 1px solid var(--border); background: var(--surface-2); color: var(--text);
  font-weight: 500; transition: border-color .15s, background .15s;
}}
.stButton > button:hover, .stDownloadButton > button:hover {{ border-color: var(--accent); color: var(--accent); }}
.stButton > button[kind="primary"] {{
  background: var(--accent); color: #05181D; border: 1px solid var(--accent); font-weight: 600;
}}
.stButton > button[kind="primary"]:hover {{ background: #6BE3F8; color: #05181D; }}
[data-testid="stDataFrame"] {{ border: 1px solid var(--border); border-radius: 10px; overflow: hidden; }}
[data-testid="stExpander"] {{ border: 1px solid var(--border); border-radius: 10px; background: var(--surface); }}

.vx-header {{ margin-bottom: 1.2rem; }}
.vx-header .vx-eyebrow {{ color: var(--accent); font-size: .72rem; font-weight: 600; letter-spacing: .16em; text-transform: uppercase; }}
.vx-header h1 {{ margin: .15rem 0 .2rem 0; font-size: 1.9rem; }}
.vx-header p {{ color: var(--muted); margin: 0; font-size: .95rem; }}

.vx-banner {{
  display: flex; gap: .7rem; align-items: flex-start; padding: .65rem .9rem; margin: 0 0 1.2rem 0;
  border: 1px solid rgba(250,178,25,.35); background: rgba(250,178,25,.07); border-radius: 10px;
  color: var(--text-2); font-size: .86rem; line-height: 1.4;
}}
.vx-banner b {{ color: {WARNING}; letter-spacing: .06em; }}

.vx-card {{ background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 1rem 1.1rem; }}
.vx-kpi {{ background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: .9rem 1.1rem; height: 100%; }}
.vx-kpi .vx-kpi-label {{ color: var(--muted); font-size: .74rem; letter-spacing: .08em; text-transform: uppercase; }}
.vx-kpi .vx-kpi-value {{ color: var(--text); font-size: clamp(1rem, 1.55vw, 1.55rem); font-weight: 650; margin-top: .2rem;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  font-variant-numeric: tabular-nums; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }}
.vx-kpi .vx-kpi-sub {{ color: var(--muted); font-size: .78rem; margin-top: .15rem; }}

.vx-pill {{ display: inline-block; padding: .08rem .55rem; border-radius: 999px; font-size: .7rem; font-weight: 650;
  letter-spacing: .07em; border: 1px solid; vertical-align: middle; white-space: nowrap; }}
.vx-pill.sim {{ color: {WARNING}; border-color: rgba(250,178,25,.5); background: rgba(250,178,25,.10); }}
.vx-pill.real {{ color: {GOOD}; border-color: rgba(12,163,12,.5); background: rgba(12,163,12,.10); }}
.vx-pill.failed {{ color: {CRITICAL}; border-color: rgba(208,59,59,.55); background: rgba(208,59,59,.10); }}
.vx-pill.ok {{ color: var(--text-2); border-color: var(--border); background: transparent; }}

.vx-rec {{ background: var(--surface); border: 1px solid var(--border); border-left-width: 3px; border-radius: 10px;
  padding: .8rem 1rem; margin-bottom: .7rem; }}
.vx-rec.critical {{ border-left-color: {CRITICAL}; }}
.vx-rec.warning {{ border-left-color: {WARNING}; }}
.vx-rec.info {{ border-left-color: {SERIES[0]}; }}
.vx-rec .vx-rec-title {{ font-weight: 650; color: var(--text); }}
.vx-rec .vx-rec-sev {{ font-size: .7rem; letter-spacing: .08em; text-transform: uppercase; margin-right: .5rem; }}
.vx-rec.critical .vx-rec-sev {{ color: {CRITICAL}; }}
.vx-rec.warning .vx-rec-sev {{ color: {WARNING}; }}
.vx-rec.info .vx-rec-sev {{ color: {SERIES[0]}; }}
.vx-rec p {{ color: var(--text-2); margin: .35rem 0 0 0; font-size: .9rem; }}
.vx-rec ul {{ margin: .35rem 0 .2rem 1.1rem; padding: 0; color: var(--text-2); font-size: .86rem; }}
.vx-rec .vx-label {{ color: var(--muted); font-size: .72rem; letter-spacing: .08em; text-transform: uppercase; margin-top: .5rem; }}

.vx-find {{ background: var(--surface); border: 1px solid var(--border); border-left-width: 3px; border-radius: 10px;
  padding: .8rem 1rem; margin-bottom: .7rem; }}
.vx-find.win {{ border-left-color: {GOOD}; }}
.vx-find.trade_off {{ border-left-color: {WARNING}; }}
.vx-find.regression {{ border-left-color: {SERIOUS}; }}
.vx-find.no_difference, .vx-find.no_improvement {{ border-left-color: var(--muted); }}
.vx-find.dominated {{ border-left-color: {SERIES[0]}; }}
.vx-find .vx-find-title {{ font-weight: 650; color: var(--text); }}
.vx-find .vx-find-kind {{ font-size: .7rem; letter-spacing: .08em; text-transform: uppercase; margin-right: .5rem; color: var(--muted); }}
.vx-find p {{ color: var(--text-2); margin: .35rem 0 0 0; font-size: .9rem; }}
.vx-find ul {{ margin: .35rem 0 .2rem 1.1rem; padding: 0; color: var(--text-2); font-size: .86rem; }}
.vx-find .vx-label {{ color: var(--muted); font-size: .72rem; letter-spacing: .08em; text-transform: uppercase; margin-top: .5rem; }}
.vx-pill.conf-high {{ color: {GOOD}; border-color: rgba(12,163,12,.5); background: rgba(12,163,12,.10); }}
.vx-pill.conf-medium {{ color: {WARNING}; border-color: rgba(250,178,25,.5); background: rgba(250,178,25,.10); }}
.vx-pill.conf-low {{ color: {SERIOUS}; border-color: rgba(236,131,90,.55); background: rgba(236,131,90,.10); }}
.vx-pill.conf-insufficient {{ color: var(--muted); border-color: var(--border); background: transparent; }}
.vx-pill.conf-simulated {{ color: {WARNING}; border-color: rgba(250,178,25,.5); background: rgba(250,178,25,.10); }}
.vx-check-pass {{ color: {GOOD}; }} .vx-check-warn {{ color: {WARNING}; }} .vx-check-fail {{ color: {SERIOUS}; }} .vx-check-info {{ color: var(--muted); }}
.vx-level {{ border: 1px solid var(--border); border-left-width: 3px; border-radius: 10px; padding: .7rem 1rem; background: var(--surface); margin: .4rem 0 1rem 0; }}
.vx-level.controlled {{ border-left-color: {GOOD}; }}
.vx-level.replicate {{ border-left-color: var(--muted); }}
.vx-level.multi_factor {{ border-left-color: {WARNING}; }}
.vx-level.not_like_for_like, .vx-level.not_comparable {{ border-left-color: {CRITICAL}; }}
.vx-level b {{ color: var(--text); }}
.vx-level p {{ color: var(--text-2); margin: .3rem 0 0 0; font-size: .88rem; }}
.vx-better {{ color: {GOOD}; font-weight: 600; }}
.vx-worse {{ color: {SERIOUS}; font-weight: 600; }}
.vx-same {{ color: var(--muted); }}
[data-testid="stPlotlyChart"] {{ overflow: hidden; max-width: 100%; }}
.vx-scroll {{ overflow-x: auto; max-width: 100%; }}
table.vx-table td, table.vx-table th {{ overflow-wrap: anywhere; }}
table.vx-table {{ width: 100%; border-collapse: collapse; font-size: .86rem; }}
table.vx-table th {{ text-align: left; color: var(--muted); font-weight: 600; font-size: .72rem; letter-spacing: .08em;
  text-transform: uppercase; padding: .5rem .6rem; border-bottom: 1px solid var(--border); }}
table.vx-table td {{ padding: .5rem .6rem; border-bottom: 1px solid var(--border); color: var(--text-2);
  font-variant-numeric: tabular-nums; }}
table.vx-table td.vx-diff {{ color: var(--text); background: rgba(61,214,245,.06); }}
.vx-swatch {{ display: inline-block; width: 10px; height: 10px; border-radius: 2px; margin-right: .45rem; }}
</style>
"""


def inject_css() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


def plotly_layout(height: int = 340) -> dict:
    """Shared layout so every chart matches the dark theme and stays responsive."""
    return dict(
        height=height,
        autosize=True,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color=TEXT_2, size=12, family="Inter, Segoe UI, system-ui, sans-serif"),
        margin=dict(l=8, r=8, t=44, b=8),
        title=dict(font=dict(size=14, color=TEXT), x=0, xanchor="left"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1, font=dict(size=11, color=TEXT_2)),
        xaxis=dict(gridcolor="rgba(255,255,255,0.04)", zerolinecolor=BORDER, linecolor=BORDER, ticks="", automargin=True),
        yaxis=dict(gridcolor="rgba(255,255,255,0.06)", zerolinecolor=BORDER, linecolor="rgba(0,0,0,0)", ticks="", automargin=True),
        hoverlabel=dict(bgcolor=SURFACE_2, bordercolor=BORDER, font=dict(color=TEXT, size=12)),
        bargap=0.35,
    )
