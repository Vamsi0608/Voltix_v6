"""Plotly chart builders. Simulated data is always marked on the chart itself."""

from __future__ import annotations

from typing import Sequence

import plotly.graph_objects as go

from voltix.catalog import MODELS, model_label
from voltix.metrics import METRIC_BY_KEY, metric_value, percentile
from voltix.schemas import BenchmarkRun

from . import theme


def _source_flag(runs: Sequence[BenchmarkRun]) -> str | None:
    """Text for the chart title when any plotted run is simulated (None for purely measured charts)."""
    sims = [r.is_simulated for r in runs]
    if not sims or not any(sims):
        return None
    return "SIMULATED DATA" if all(sims) else "INCLUDES SIMULATED DATA"


def _finish(fig: go.Figure, height: int, flag: str | None) -> go.Figure:
    fig.update_layout(**theme.plotly_layout(height))
    if flag:
        title = fig.layout.title.text or ""
        fig.update_layout(title_text=f'{title}  <span style="color:{theme.WARNING};font-size:11px">⚠ {flag}</span>')
    return fig


def model_color(model_id: str) -> str:
    ids = list(MODELS)
    idx = ids.index(model_id) if model_id in ids else len(ids)
    return theme.SERIES[idx % theme.MAX_SERIES]


def latency_histogram(run: BenchmarkRun, height: int = 320) -> go.Figure:
    lat = [s.latency_ms for s in run.samples]
    fig = go.Figure(go.Histogram(x=lat, nbinsx=min(30, max(5, len(lat) // 2)), marker=dict(color=theme.SERIES[0], line=dict(color=theme.SURFACE, width=2)),
                                 hovertemplate="%{x:.0f} ms: %{y} iterations<extra></extra>", name="Iterations"))
    if len(lat) >= 2:
        for q, dash in ((50, "dot"), (95, "dash")):
            v = percentile(lat, q)
            fig.add_vline(x=v, line=dict(color=theme.TEXT_2, width=1.5, dash=dash),
                          annotation_text=f"p{q} {v:,.0f} ms", annotation_font=dict(size=10, color=theme.TEXT_2),
                          annotation_position="top")
    fig.update_layout(title_text="Latency distribution", xaxis_title="End-to-end latency (ms)", yaxis_title="Iterations", showlegend=False)
    return _finish(fig, height, _source_flag([run]))


def latency_timeline(run: BenchmarkRun, height: int = 320) -> go.Figure:
    x = [s.index for s in run.samples]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=x, y=[s.latency_ms for s in run.samples], mode="lines+markers", name="Latency",
                             line=dict(color=theme.SERIES[0], width=2), marker=dict(size=7, line=dict(color=theme.SURFACE, width=2)),
                             hovertemplate="Iteration %{x}: %{y:,.0f} ms<extra>Latency</extra>"))
    fig.add_trace(go.Scatter(x=x, y=[s.ttft_ms for s in run.samples], mode="lines+markers", name="Time to first token",
                             line=dict(color=theme.SERIES[1], width=2), marker=dict(size=7, line=dict(color=theme.SURFACE, width=2)),
                             hovertemplate="Iteration %{x}: %{y:,.0f} ms<extra>TTFT</extra>"))
    fig.update_layout(title_text="Per-iteration timing", xaxis_title="Iteration", yaxis_title="ms", hovermode="x unified")
    return _finish(fig, height, _source_flag([run]))


def throughput_vs_latency(runs: Sequence[BenchmarkRun], height: int = 380) -> go.Figure:
    """Each completed run is a point. Color follows the model (fixed slot per model)."""
    fig = go.Figure()
    seen: dict[str, list[BenchmarkRun]] = {}
    for r in runs:
        if r.metrics:
            seen.setdefault(r.config.model_id, []).append(r)
    unknown = 0
    for model_id, group in seen.items():
        symbol = "circle"
        if model_id not in MODELS:  # custom models share the last slot and are told apart by marker shape
            symbol = ["diamond", "square", "triangle-up", "x", "cross"][unknown % 5]
            unknown += 1
        fig.add_trace(go.Scatter(
            x=[r.metrics.latency_p95_ms for r in group], y=[r.metrics.throughput_tokens_per_s for r in group],
            mode="markers", name=model_label(model_id) if len(model_label(model_id)) <= 36 else "…" + model_label(model_id)[-35:],
            marker=dict(size=11, symbol=symbol, color=model_color(model_id), line=dict(color=theme.SURFACE, width=2)),
            text=[r.name for r in group], customdata=[r.config.precision.value for r in group],
            hovertemplate="<b>%{text}</b><br>p95 latency %{x:,.0f} ms<br>throughput %{y:,.1f} tok/s<br>%{customdata}<extra></extra>",
        ))
    fig.update_layout(title_text="Throughput vs tail latency (one point per run)",
                      xaxis_title="p95 latency (ms), lower is better", yaxis_title="Throughput (tok/s), higher is better")
    return _finish(fig, height, _source_flag(runs))


def run_bars(runs: Sequence[BenchmarkRun], metric_key: str, height: int = 340, title: str | None = None) -> go.Figure:
    spec = METRIC_BY_KEY[metric_key]
    names = [r.name if len(r.name) <= 28 else r.name[:27] + "…" for r in runs]
    scale = 100.0 if metric_key == "memory_utilization" else 1.0
    unit = "%" if metric_key == "memory_utilization" else spec.unit
    values = [(metric_value(r.metrics, metric_key) or 0.0) * scale if r.metrics else 0.0 for r in runs]
    fig = go.Figure(go.Bar(
        x=names, y=values, marker=dict(color=[theme.SERIES[i % theme.MAX_SERIES] for i in range(len(runs))], line=dict(color=theme.SURFACE, width=2)),
        text=[f"{v:,.{spec.decimals}f}" for v in values], textposition="outside", textfont=dict(color=theme.TEXT_2, size=11),
        hovertemplate="%{x}<br>%{y:,.2f} " + unit + "<extra></extra>", cliponaxis=False,
    ))
    fig.update_layout(title_text=title or f"{spec.label} ({unit})", showlegend=False, yaxis_title=unit)
    fig.update_yaxes(rangemode="tozero")
    return _finish(fig, height, _source_flag(runs))


def latency_percentiles(runs: Sequence[BenchmarkRun], height: int = 340) -> go.Figure:
    """Grouped bars: one group per run, bars for p50 / p95 / p99 (position-coded, fixed slots)."""
    names = [r.name if len(r.name) <= 22 else r.name[:21] + "…" for r in runs]
    fig = go.Figure()
    for i, (key, label) in enumerate((("latency_p50_ms", "p50"), ("latency_p95_ms", "p95"), ("latency_p99_ms", "p99"))):
        fig.add_trace(go.Bar(x=names, y=[metric_value(r.metrics, key) if r.metrics else 0 for r in runs], name=label,
                             marker=dict(color=theme.SERIES[i], line=dict(color=theme.SURFACE, width=2)),
                             hovertemplate="%{x}<br>" + label + " %{y:,.0f} ms<extra></extra>"))
    fig.update_layout(title_text="Latency percentiles (ms)", barmode="group", yaxis_title="ms")
    return _finish(fig, height, _source_flag(runs))


def memory_breakdown_chart(runs: Sequence[BenchmarkRun], height: int = 340) -> go.Figure | None:
    """Stacked memory composition (estimated); only runs that recorded a breakdown are shown."""
    rows = [(r, r.environment.get("memory_breakdown_gb")) for r in runs]
    rows = [(r, b) for r, b in rows if b]
    if not rows:
        return None
    names = [r.name if len(r.name) <= 22 else r.name[:21] + "…" for r, _ in rows]
    fig = go.Figure()
    for i, (key, label) in enumerate((("weights", "Weights"), ("kv_cache", "KV cache"), ("overhead", "Overhead"))):
        fig.add_trace(go.Bar(x=names, y=[b[key] for _, b in rows], name=label,
                             marker=dict(color=theme.SERIES[i], line=dict(color=theme.SURFACE, width=2)),
                             hovertemplate="%{x}<br>" + label + " %{y:.2f} GB<extra></extra>"))
    fig.update_layout(title_text="Estimated memory composition (GB)", barmode="stack", yaxis_title="GB")
    return _finish(fig, height, _source_flag([r for r, _ in rows]))


# ---------------------------------------------------------------------------
# Phase 3: optimization charts
# ---------------------------------------------------------------------------

VERDICT_STYLE = {
    "improved": (theme.GOOD, "better"),
    "regressed": (theme.SERIOUS, "worse"),
    "negligible": (theme.MUTED, "negligible"),
    "no_detectable_change": (theme.MUTED, "no detectable change"),
    "not_assessed": (theme.MUTED, "not assessed"),
}


def change_intervals(pa, height: int = 340) -> go.Figure:
    """Forest-style chart: each metric's % change vs baseline with its 95% interval."""
    rows = [m for m in pa.metrics.values() if m.change_pct is not None]
    fig = go.Figure()
    labels = [f"{m.label} ({'higher' if m.higher_is_better else 'lower'} is better)" for m in rows][::-1]
    rows = rows[::-1]
    for m, label in zip(rows, labels):
        color, word = VERDICT_STYLE[m.verdict]
        has_ci = m.has_ci and m.ci_low_pct is not None and m.ci_high_pct is not None
        fig.add_trace(go.Scatter(
            x=[m.change_pct], y=[label], mode="markers+text", showlegend=False,
            marker=dict(size=11, color=color, symbol="diamond" if has_ci else "circle-open", line=dict(color=color, width=2)),
            error_x=dict(type="data", symmetric=False, array=[m.ci_high_pct - m.change_pct], arrayminus=[m.change_pct - m.ci_low_pct],
                         color=color, thickness=2, width=6) if has_ci else None,
            text=[f"  {m.change_pct:+.1f}% · {word}"], textposition="middle right", textfont=dict(size=11, color=theme.TEXT_2),
            hovertemplate=f"<b>{m.label}</b><br>change %{{x:+.1f}}%"
                          + (f"<br>95% CI {m.ci_low_pct:+.1f}% to {m.ci_high_pct:+.1f}%" if has_ci else "<br>single measurement, no interval")
                          + f"<br>{word}<extra></extra>"))
    fig.add_vline(x=0, line=dict(color=theme.TEXT_2, width=1))
    fig.update_layout(title_text="Change vs baseline, with 95% interval", xaxis_title="% change (diamond = interval; open circle = single measurement)",
                      yaxis_title=None)
    # Leave room on the right for the value labels, which would otherwise be clipped for large changes.
    lows = [min(m.ci_low_pct if m.has_ci and m.ci_low_pct is not None else m.change_pct, m.change_pct, 0.0) for m in rows]
    highs = [max(m.ci_high_pct if m.has_ci and m.ci_high_pct is not None else m.change_pct, m.change_pct, 0.0) for m in rows]
    lo, hi = min(lows, default=0.0), max(highs, default=0.0)
    span = max(hi - lo, 10.0)
    fig.update_xaxes(zeroline=False, range=[lo - 0.1 * span, hi + 0.55 * span])
    return _finish(fig, height, "SIMULATED DATA" if pa.data_source == "simulated" else None)


_LABEL_POSITIONS = ["top center", "bottom center", "middle right", "middle left"]


def tradeoff_map(study, runs_by_id: dict, height: int = 400) -> go.Figure:
    """Throughput vs p95 latency. Frontier runs are filled circles; dominated runs are crosses."""
    fig = go.Figure()
    frontier = set(study.frontier)
    for ids, name, symbol, color in (
        ([i for i in study.run_ids if i in frontier], "Not outperformed", "circle", theme.SERIES[0]),
        ([i for i in study.run_ids if i not in frontier], "Outperformed by another run", "x", theme.MUTED),
    ):
        pts = [runs_by_id[i] for i in ids if i in runs_by_id and runs_by_id[i].metrics]
        if not pts:
            continue
        fig.add_trace(go.Scatter(
            x=[r.metrics.latency_p95_ms for r in pts], y=[r.metrics.throughput_tokens_per_s for r in pts],
            mode="markers+text", name=name, text=[("BASELINE: " if r.run_id == study.baseline_id else "") + r.name[:26] for r in pts],
            textposition=[_LABEL_POSITIONS[i % len(_LABEL_POSITIONS)] for i in range(len(pts))],  # keeps near-identical points readable
            textfont=dict(size=10, color=theme.TEXT_2),
            marker=dict(size=[16 if r.run_id == study.baseline_id else 11 for r in pts], symbol=symbol, color=color,
                        line=dict(color=theme.TEXT if symbol == "circle" else color, width=2)),
            hovertemplate="<b>%{text}</b><br>p95 latency %{x:,.0f} ms<br>throughput %{y:,.1f} tok/s<extra></extra>"))
    fig.update_layout(title_text="Throughput vs p95 latency (point estimates; close points may be noise)",
                      xaxis_title="p95 latency per batch (ms), lower is better", yaxis_title="Throughput (tok/s), higher is better")
    return _finish(fig, height, "SIMULATED DATA" if study.data_source == "simulated" else None)
