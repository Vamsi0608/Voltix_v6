"""Results and Reports page: inspect one saved run in depth and export it."""

from __future__ import annotations

import streamlit as st

from voltix.catalog import hardware_label, model_label
from voltix.db import StorageError
from voltix.exports import run_to_json, run_to_markdown, runs_to_csv, samples_to_csv
from voltix.metrics import METRIC_SPECS, MIN_OBSERVATIONS, format_metric, metric_value
from voltix.recommendations import recommend
from voltix.schemas import RunStatus
from voltix.validation import MAX_NOTES_LEN

from .. import charts, nav
from ..components import (
    load_runs,
    demo_banner,
    environment_panel,
    esc,
    fmt_time,
    get_repo,
    kpi_row,
    memory_label,
    page_header,
    recommendation_cards,
    run_option_label,
    source_pill,
    status_pill,
)


def render() -> None:
    page_header("Results and Reports", "Inspect and export a run", "Metrics, charts, explainable recommendations and downloadable reports.")
    demo_banner()
    repo = get_repo()
    summaries = load_runs(repo)
    if not summaries:
        st.info("No saved runs yet. Run a benchmark and save it, or load the demo experiments from the Overview page.")
        if st.button("Go to Run Benchmark", key="res_go"):
            nav.go("run")
        return

    by_id = {r.run_id: r for r in summaries}
    pre = st.session_state.pop("open_run_id", None)
    if pre in by_id:
        st.session_state["res_select"] = pre
    if st.session_state.get("res_select") not in by_id:
        default = next((r for r in summaries if r.status == RunStatus.COMPLETED), summaries[0])
        st.session_state["res_select"] = default.run_id
    run_id = st.selectbox("Saved run", list(by_id), format_func=lambda i: run_option_label(by_id[i]), key="res_select")

    try:
        run = repo.get(run_id)
    except StorageError as exc:
        st.error(str(exc))
        return
    if run is None:
        st.error("That run no longer exists.")
        return

    st.markdown(f"### {esc(run.name)}", unsafe_allow_html=True)
    st.markdown(f"{source_pill(run)} &nbsp; {status_pill(run)} &nbsp; "
                f"<span style='color:#8B94A3'>`{run.run_id}` · saved {fmt_time(run.created_at)} · backend {esc(run.backend)}</span>",
                unsafe_allow_html=True)
    if run.is_simulated:
        st.warning("These results are SIMULATED by an analytic model. They are not measurements of real hardware.")
    if run.status != RunStatus.COMPLETED:
        (st.warning if run.status != RunStatus.FAILED else st.error)(run.error or "The run did not complete.")

    c = run.config
    with st.expander("Configuration", expanded=run.status != RunStatus.COMPLETED):
        st.markdown(
            f"**Model** {esc(model_label(c.model_id))} · **Hardware** {esc(hardware_label(c.hardware_id))}"
            f"{' (simulated profile)' if run.is_simulated else ''} · **Precision** {c.precision.value}  \n"
            f"**Batch** {c.batch_size} · **Prompt** {c.prompt_tokens:,} tok · **Output** {c.output_tokens:,} tok · "
            f"**Iterations** {c.iterations} (+{c.warmup_iterations} warmup) · **Seed** {c.seed}"
        )

    environment_panel(run)

    if run.metrics:
        m = run.metrics
        kpi_row([
            ("Throughput", f"{m.throughput_tokens_per_s:,.1f} tok/s", f"{m.sequences_per_s:,.2f} seq/s"),
            ("Latency p50 / p95 / p99", " / ".join([f"{m.latency_p50_ms:,.0f}"] + [(f"{v:,.0f}" if (v := metric_value(m, k)) is not None else "n/a")
                                                             for k in ("latency_p95_ms", "latency_p99_ms")]),
             "milliseconds" + ("" if m.iterations >= MIN_OBSERVATIONS["latency_p99_ms"] else f" (n/a: p95 needs ≥{MIN_OBSERVATIONS['latency_p95_ms']}, p99 ≥{MIN_OBSERVATIONS['latency_p99_ms']} iterations)")),
            ("TTFT mean", f"{m.ttft_mean_ms:,.0f} ms", f"TPOT {m.tpot_mean_ms:,.2f} ms/token"),
            (memory_label(run),
             f"{m.peak_memory_gb:.1f} GB" if m.peak_memory_gb is not None else "n/a",
             f"{m.memory_utilization * 100:.0f}% of device" if m.memory_utilization is not None else ""),
        ])
        st.write("")
        if run.samples:
            a, b = st.columns(2)
            a.plotly_chart(charts.latency_histogram(run), width="stretch", key="res_hist")
            b.plotly_chart(charts.latency_timeline(run), width="stretch", key="res_time")
        with st.expander("All metrics"):
            st.dataframe(
                [{"Metric": s.label, "Value": format_metric(s.key, metric_value(m, s.key))} for s in METRIC_SPECS]
                + [{"Metric": "Iterations", "Value": str(m.iterations)}, {"Metric": "Total output tokens", "Value": f"{m.total_output_tokens:,}"}],
                hide_index=True, width="stretch")

    st.markdown("#### Recommendations")
    recs = recommend(run)
    recommendation_cards(recs, run.is_simulated)

    st.markdown("#### Notes")
    notes = st.text_area("Notes", value=run.notes, max_chars=MAX_NOTES_LEN, label_visibility="collapsed",
                         placeholder="What were you testing? What did you learn?", key=f"res_notes_{run.run_id}")
    if st.button("Save notes", key="res_save_notes"):
        try:
            repo.update_notes(run.run_id, notes)
            st.toast("Notes saved.")
            st.rerun()
        except StorageError as exc:
            st.error(str(exc))
    run.notes = notes

    st.markdown("#### Export")
    e1, e2, e3, e4 = st.columns(4)
    e1.download_button("JSON (full run)", run_to_json(run, recs), f"{run.run_id}.json", "application/json", key="res_json")
    e2.download_button("Summary CSV", runs_to_csv([run]), f"{run.run_id}_summary.csv", "text/csv", key="res_csv")
    e3.download_button("Samples CSV", samples_to_csv(run), f"{run.run_id}_samples.csv", "text/csv", disabled=not run.samples, key="res_samples")
    e4.download_button("Markdown report", run_to_markdown(run, recs), f"{run.run_id}_report.md", "text/markdown", key="res_md")

    with st.expander("Danger zone"):
        confirm = st.checkbox("I understand this permanently deletes the run", key=f"res_confirm_{run.run_id}")
        if st.button("Delete run", disabled=not confirm, key="res_delete"):
            try:
                repo.delete(run.run_id)
            except StorageError as exc:
                st.error(f"Could not delete the run: {exc}")
            else:
                st.session_state.pop("res_select", None)
                st.toast("Run deleted.")
                st.rerun()
