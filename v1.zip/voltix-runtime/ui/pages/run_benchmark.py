"""Run Benchmark page: configure, run, inspect, save, export."""

from __future__ import annotations

import streamlit as st

from voltix import estimation as est
from voltix.backends import TransformersBackend, all_statuses
from voltix.backends.devices import AcceleratorProbe, probe_accelerators
from voltix.catalog import DEFAULT_HARDWARE_ID, DEFAULT_MODEL_ID, HARDWARE, MODELS
from voltix.db import StorageError
from voltix.exports import run_to_json, run_to_markdown, runs_to_csv, samples_to_csv
from voltix.recommendations import recommend
from voltix.metrics import MIN_OBSERVATIONS, metric_value
from voltix.jobs import JobBusy, manager
from voltix.schemas import BenchmarkConfig, Precision, RunStatus
from voltix.testmodel import create_tiny_model
from voltix.validation import LIMITS, TRANSFORMERS_PRECISIONS, validate_config

from .. import charts
from ..components import (
    demo_banner,
    environment_panel,
    get_repo,
    kpi_row,
    memory_label,
    page_header,
    recommendation_cards,
    source_pill,
    status_pill,
)


@st.cache_resource(show_spinner="Probing PyTorch and GPUs (the first import can take a while)…")
def _probe() -> AcceleratorProbe:
    return probe_accelerators()


def _precision_help(p: Precision) -> str:
    return {"fp32": "Full precision. Slow and memory hungry.", "fp16": "Half precision (GPU only on the Transformers backend).",
            "bf16": "bfloat16 (needs an Ampere-class GPU or newer; works on CPU).", "int8": "8-bit weight-only quantization (simulated only).",
            "int4": "4-bit weight-only quantization (simulated only)."}[p.value]


def _make_tiny_model() -> None:
    """Button callback: build a random-weight local model so real inference can be tried without downloads."""
    try:
        path = create_tiny_model()
        st.session_state["rb_model_id"] = str(path)
        st.session_state["rb_tiny_msg"] = ("ok", f"Created a tiny RANDOM-WEIGHT test model at {path}. It checks the pipeline only; its speed says nothing about real models.")
    except Exception as exc:  # noqa: BLE001 - shown to the user
        st.session_state["rb_tiny_msg"] = ("err", f"Could not create the test model: {type(exc).__name__}: {exc}")


def _hardware_caption(probe: AcceleratorProbe) -> str:
    if not probe.torch_installed:
        return f"torch is not installed ({probe.error})."
    if probe.error and not probe.cuda_available:
        return probe.error
    if probe.cuda_available:
        return "Detected GPU(s): " + ", ".join(f"cuda:{d.index} {d.name} ({d.total_gb:.0f} GB)" for d in probe.devices)
    return (f"No usable CUDA GPU (torch {probe.torch_version}, CUDA build {probe.cuda_build or 'none'}). "
            "The Transformers backend will run on CPU.")


def _simulated_form() -> tuple[BenchmarkConfig, str]:
    c1, c2 = st.columns(2)
    model_id = c1.selectbox("Model profile", list(MODELS), index=list(MODELS).index(DEFAULT_MODEL_ID),
                            format_func=lambda k: f"{MODELS[k].display_name} ({MODELS[k].params_billion:g}B params)", key="rb_model")
    hw_id = c2.selectbox("Simulated hardware", list(HARDWARE), index=list(HARDWARE).index(DEFAULT_HARDWARE_ID),
                         format_func=lambda k: f"{HARDWARE[k].display_name}", key="rb_hw",
                         help="Approximate public specs used by the simulation only.")
    precision = st.selectbox("Precision", list(Precision), index=1, format_func=lambda p: p.value, key="rb_prec")
    st.caption(_precision_help(precision))
    return _workload(model_id, precision, "simulated", hw_id, False)


def _transformers_form() -> tuple[BenchmarkConfig, str]:
    status = TransformersBackend.status()
    if not status.available:
        st.error(status.detail)
        probe = AcceleratorProbe(False, error="not installed")
    else:
        probe = _probe()
        st.caption(_hardware_caption(probe))

    m1, m2 = st.columns([3, 1])
    model_id = m1.text_input("Model: Hugging Face repo id or local folder", key="rb_model_id", max_chars=200,
                             placeholder="e.g. org/model-name   or   /path/to/model",
                             help="Models are loaded with AutoModelForCausalLM. trust_remote_code is never enabled.").strip()
    m2.write("")
    m2.write("")
    m2.button("Create tiny test model", key="rb_tiny", on_click=_make_tiny_model, disabled=not status.available,
              help="Builds a small random-weight model locally so you can try real inference without any download.")
    msg = st.session_state.get("rb_tiny_msg")
    if msg:
        (st.success if msg[0] == "ok" else st.error)(msg[1])

    devices = ["auto", "cpu"] + [f"cuda:{d.index}" for d in probe.devices]
    d1, d2 = st.columns(2)
    device = d1.selectbox("Device", devices, key="rb_device",
                          format_func=lambda v: {"auto": "auto (GPU if available, else CPU)", "cpu": "CPU"}.get(v, v))
    precision = d2.selectbox("Precision", list(TRANSFORMERS_PRECISIONS), index=0, format_func=lambda p: p.value, key="rb_prec_tf")
    d2.caption(_precision_help(precision))
    allow = st.checkbox("Allow downloading the model from the Hugging Face Hub", value=False, key="rb_allow_dl",
                        help="Off by default: only local folders and the existing Hugging Face cache are used. "
                             "Large models can be many GB.")
    revision = st.text_input("Model revision (optional)", key="rb_revision", max_chars=100, placeholder="branch, tag or commit id",
                             help="Pins the exact Hub weights so a result can be reproduced later. Ignored for local folders. "
                                  "The commit actually loaded is recorded when the library reports it.").strip() or None
    config, name = _workload(model_id, precision, "transformers", device, allow)
    config.revision = revision
    return config, name


def _workload(model_id: str, precision: Precision, backend: str, hardware_id: str, allow_download: bool) -> tuple[BenchmarkConfig, str]:
    st.markdown("#### 3 · Workload")
    w1, w2, w3 = st.columns(3)
    batch = w1.number_input("Batch size", *LIMITS["batch_size"], value=8 if backend == "simulated" else 1, step=1, key=f"rb_batch_{backend}")
    prompt = w2.number_input("Prompt tokens", *LIMITS["prompt_tokens"], value=512 if backend == "simulated" else 128, step=64, key=f"rb_prompt_{backend}")
    output = w3.number_input("Output tokens", *LIMITS["output_tokens"], value=128 if backend == "simulated" else 32, step=16, key=f"rb_out_{backend}")
    w4, w5, w6 = st.columns(3)
    iters = w4.number_input("Measured iterations", *LIMITS["iterations"], value=40 if backend == "simulated" else 10, step=5, key=f"rb_iters_{backend}")
    warm = w5.number_input("Warmup iterations", *LIMITS["warmup_iterations"], value=3 if backend == "simulated" else 2, step=1, key=f"rb_warm_{backend}")
    seed = w6.number_input("Random seed", *LIMITS["seed"], value=42, step=1, key=f"rb_seed_{backend}",
                           help="Seeds the synthetic prompt (and the simulation noise).")
    name = st.text_input("Run name", value="", max_chars=80, placeholder="Optional, e.g. Mistral fp16 baseline", key=f"rb_name_{backend}")
    config = BenchmarkConfig(
        model_id=model_id, precision=precision, batch_size=int(batch), prompt_tokens=int(prompt), output_tokens=int(output),
        iterations=int(iters), warmup_iterations=int(warm), seed=int(seed), backend=backend, hardware_id=hardware_id,
        allow_download=allow_download)
    return config, name


def _config_form() -> tuple[BenchmarkConfig, str]:
    statuses = {s.key: s for s in all_statuses()}
    with st.container(border=True):
        st.markdown("#### 1 · Backend")
        labels = {
            "simulated": "Simulated (demo mode): runs now, no model executed",
            "transformers": "Hugging Face Transformers: real inference, MEASURED"
            + ("" if statuses["transformers"].available else " (dependencies missing)"),
            "vllm": "vLLM: not implemented yet",
        }
        choice = st.radio("Inference backend", list(labels), format_func=labels.get, horizontal=True,
                          key="rb_backend", label_visibility="collapsed")
        st.caption(statuses[choice].detail)
        st.markdown("#### 2 · Model and hardware")
        if choice == "simulated":
            return _simulated_form()
        if choice == "transformers":
            return _transformers_form()
        # vLLM placeholder: keep a valid-looking config so the page can still render and explain.
        return _workload("", Precision.FP16, "vllm", "auto", False)


def _preview(config: BenchmarkConfig) -> None:
    model, hw = MODELS.get(config.model_id), HARDWARE.get(config.hardware_id or "")
    if not model or not hw:
        return
    b = est.memory_breakdown(model, config.precision, config.batch_size, config.prompt_tokens, config.output_tokens)
    frac = b.total_gb / hw.memory_gb
    msg = (f"Estimated memory: **{b.total_gb:.1f} GB** of {hw.memory_gb:.0f} GB ({frac * 100:.0f}%): "
           f"weights {b.weights_gb:.1f} + KV cache {b.kv_cache_gb:.1f} + overhead {b.overhead_gb:.1f} GB (analytic estimate).")
    if frac > 1:
        st.warning(msg + " This will fail with a simulated out-of-memory error.")
    elif frac > 0.9:
        st.warning(msg + " Very little headroom.")
    else:
        st.caption(msg)


def _ms(m, key: str, short: bool = False) -> str:
    """Whole-millisecond value, or an honest 'n/a' when too few iterations support the statistic."""
    v = metric_value(m, key)
    if v is not None:
        return f"{v:,.0f} ms"
    need = MIN_OBSERVATIONS[key]
    return f"n/a (≥{need} iter.)" if short else f"n/a (≥{need})"


def _show_result(run) -> None:
    repo = get_repo()
    st.markdown(f"### Result: {run.name}")
    st.markdown(f"{source_pill(run)} &nbsp; {status_pill(run)} &nbsp; <span style='color:#8B94A3'>run id `{run.run_id}`</span>",
                unsafe_allow_html=True)
    if run.status != RunStatus.COMPLETED:
        (st.warning if run.status != RunStatus.FAILED else st.error)(run.error or "The run did not complete.")
    else:
        m = run.metrics
        kpi_row([
            ("Throughput", f"{m.throughput_tokens_per_s:,.1f} tok/s", "aggregate output tokens"),
            ("Latency p50 / p95", f"{m.latency_p50_ms:,.0f} / {_ms(m, 'latency_p95_ms')}", f"p99 {_ms(m, 'latency_p99_ms', short=True)}"),
            ("Time to first token", f"{m.ttft_mean_ms:,.0f} ms", f"p95 {_ms(m, 'ttft_p95_ms', short=True)}"),
            (memory_label(run), f"{m.peak_memory_gb:.2f} GB" if m.peak_memory_gb is not None else "n/a",
             f"{m.memory_utilization * 100:.0f}% of device" if m.memory_utilization is not None else ""),
        ])
        st.write("")
        c1, c2 = st.columns(2)
        c1.plotly_chart(charts.latency_histogram(run), width="stretch", key="rb_hist")
        c2.plotly_chart(charts.latency_timeline(run), width="stretch", key="rb_time")
    environment_panel(run)

    st.markdown("#### Recommendations")
    recs = recommend(run)
    recommendation_cards(recs, run.is_simulated)

    st.markdown("#### Save and export")
    saved = repo.exists(run.run_id)
    s1, s2, s3, s4, s5 = st.columns(5)
    if saved:
        s1.success("Saved to history")
    elif s1.button("Save run", type="primary", key="rb_save"):
        try:
            repo.save(run)
            st.toast("Run saved to history.")
            st.rerun()
        except StorageError as exc:
            st.error(f"Could not save: {exc}")
    s2.download_button("JSON", run_to_json(run, recs), f"{run.run_id}.json", "application/json", key="rb_dl_json")
    s3.download_button("Summary CSV", runs_to_csv([run]), f"{run.run_id}_summary.csv", "text/csv", key="rb_dl_csv")
    s4.download_button("Samples CSV", samples_to_csv(run), f"{run.run_id}_samples.csv", "text/csv",
                       disabled=not run.samples, key="rb_dl_samples")
    s5.download_button("Markdown report", run_to_markdown(run, recs), f"{run.run_id}_report.md", "text/markdown", key="rb_dl_md")
    if not saved:
        st.caption("This result is not saved yet. Saving adds it to Benchmark History and makes it available in Compare Runs.")


def _collect_finished() -> None:
    """Move a finished job's outcome into session state (once)."""
    job = manager().get(st.session_state.get("rb_job", ""))
    if job is None:
        st.session_state.pop("rb_job", None)
        return
    snap = job.snapshot()
    if snap.state != "finished":
        return
    st.session_state.pop("rb_job", None)
    if snap.run is not None:
        st.session_state["last_run"] = snap.run
    if snap.error:
        st.session_state["rb_job_error"] = snap.error


@st.fragment(run_every=1)
def _job_panel() -> None:
    job = manager().current()
    if job is None:
        return
    snap = job.snapshot()
    if snap.state == "finished":
        if st.session_state.get("rb_job") == snap.job_id:
            _collect_finished()
        st.rerun()
        return
    mine = st.session_state.get("rb_job") == snap.job_id
    st.progress(min(snap.done / max(snap.total, 1), 1.0), text=f"{snap.label}: {snap.done}/{snap.total} · {snap.elapsed_s:,.0f} s")
    if not mine:
        st.info("A benchmark started from another browser tab is running. Only one runs at a time.")
    if snap.cancel_requested:
        st.caption("Cancel requested. The run stops at the next generated token or iteration boundary (model loading cannot be interrupted).")
    elif st.button("Cancel benchmark", key="rb_cancel"):
        job.cancel()
        st.rerun(scope="fragment")


def render() -> None:
    page_header("Run Benchmark", "Configure and run", "Select a configuration, run it, inspect the result, then save it.")
    demo_banner()
    config, name = _config_form()

    problems: list[str] = []
    runnable = config.backend in ("simulated", "transformers")
    if config.backend == "vllm":
        st.warning("vLLM is a placeholder and cannot run. Choose the simulated or Transformers backend.")
    elif config.backend == "transformers" and not config.model_id:
        st.info("Enter a Hugging Face repo id or a local model folder, or click 'Create tiny test model'.")
        runnable = False
    else:
        problems = validate_config(config)
        if config.backend == "transformers" and not problems:
            if not TransformersBackend.status().available:
                runnable = False
            else:
                problems = TransformersBackend.preflight(config, _probe())
        for e in problems:
            st.error(e)
        if config.backend == "simulated" and not problems:
            _preview(config)
    if config.backend == "transformers" and runnable and not problems:
        st.caption("This runs REAL inference on this machine in the background. You can cancel it; cancellation takes effect "
                   "at the next generated token, but loading a model cannot be interrupted. Large models may take minutes to load.")

    busy = manager().current() is not None and manager().current().running
    if st.button("Run benchmark", type="primary", disabled=bool(problems) or not runnable or busy, key="rb_run"):
        try:
            job = manager().start(config, name)
            st.session_state["rb_job"] = job.job_id
            st.session_state.pop("rb_job_error", None)
            st.session_state.pop("last_run", None)
            st.rerun()
        except JobBusy as exc:
            st.error(str(exc))
    if busy:
        _job_panel()
    elif st.session_state.get("rb_job"):
        _collect_finished()
    err = st.session_state.get("rb_job_error")
    if err:
        st.error(err)

    run = st.session_state.get("last_run")
    if run is not None:
        st.divider()
        _show_result(run)
