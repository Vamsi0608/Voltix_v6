"""Benchmark History page."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from voltix.catalog import hardware_label, model_label
from voltix.exports import runs_to_csv
from voltix.db import StorageError
from voltix.importer import ImportRejected, import_run_with_warnings
from voltix.metrics import metric_value
from voltix.schemas import RunStatus

from .. import nav, theme
from ..components import demo_banner, fmt_time, get_repo, page_header, load_runs


def _import_panel(repo) -> None:
    """Bring runs measured elsewhere (e.g. a cloud GPU notebook) into this history."""
    n = st.session_state.setdefault("hist_import_n", 0)
    with st.expander("Import runs from JSON files (for example from a GPU notebook)", expanded=not st.session_state.get("hist_has_runs", True)):
        st.caption("Use the JSON files written by run_real_benchmark.py or exported by VOLTIX. A run keeps the data source it was "
                   "exported with (measured stays measured). Files are checked for damage and for metrics that do not match "
                   "their samples; a file cannot be proven to come from a real GPU, so only import files you trust.")
        files = st.file_uploader("JSON files", type=["json"], accept_multiple_files=True, key=f"hist_upload_{n}")
        if files and st.button(f"Import {len(files)} file(s)", key="hist_import"):
            ok_msgs: list[str] = []
            bad_msgs: list[str] = []
            for f in files:
                try:
                    result = import_run_with_warnings(repo, f.getvalue())
                    run = result.run
                except ImportRejected as exc:
                    bad_msgs.append(f"{f.name}: {exc}")
                except StorageError as exc:
                    bad_msgs.append(f"{f.name}: could not save: {exc}")
                else:
                    ok_msgs.append(f"{f.name}: imported '{run.name}' ({run.data_source.value.upper()})."
                                   + "".join(f" WARNING: {w}" for w in result.warnings))
            if ok_msgs:
                st.session_state["hist_import_n"] = n + 1
                st.session_state["hist_flash"] = (ok_msgs, bad_msgs)
                st.rerun()
            for m in bad_msgs:
                st.error(m)


def render() -> None:
    page_header("Benchmark History", "Every saved run", "Filter, select runs to compare or inspect, and export.")
    demo_banner()
    repo = get_repo()
    all_runs = load_runs(repo)
    st.session_state["hist_has_runs"] = bool(all_runs)
    flash = st.session_state.pop("hist_flash", None)
    if flash:
        for m in flash[0]:
            st.success(m)
        for m in flash[1]:
            st.error(m)
    _import_panel(repo)
    if not all_runs:
        st.info("History is empty. Run a benchmark and save it, or load the demo experiments from the Overview page.")
        return

    f1, f2, f3, f4 = st.columns([1, 1, 1, 2])
    source = f1.selectbox("Data source", ["All", "Simulated", "Measured"], key="hist_source")
    status = f2.selectbox("Status", ["All", "Completed", "Failed", "Cancelled", "Timed out"], key="hist_status")
    models = sorted({r.config.model_id for r in all_runs})
    model = f3.selectbox("Model", ["All"] + models, format_func=lambda k: k if k == "All" else model_label(k), key="hist_model")
    query = f4.text_input("Search name", placeholder="e.g. int8", key="hist_query")

    runs = all_runs
    if source != "All":
        runs = [r for r in runs if r.data_source.value == source.lower()]
    if status != "All":
        runs = [r for r in runs if r.status.value == status.lower().replace(" ", "_")]
    if model != "All":
        runs = [r for r in runs if r.config.model_id == model]
    if query.strip():
        q = query.strip().lower()
        runs = [r for r in runs if q in r.name.lower()]

    st.caption(f"Showing {len(runs)} of {len(all_runs)} runs.")
    if not runs:
        st.info("No runs match these filters.")
        return

    df = pd.DataFrame([{
        "Name": r.name,
        "Source": "SIMULATED" if r.is_simulated else "MEASURED",
        "Status": r.status.value,
        "Model": model_label(r.config.model_id),
        "Hardware": hardware_label(r.config.hardware_id),
        "Precision": r.config.precision.value,
        "Batch": r.config.batch_size,
        "Throughput (tok/s)": round(r.metrics.throughput_tokens_per_s, 1) if r.metrics else None,
        "p95 latency (ms)": (round(metric_value(r.metrics, "latency_p95_ms"), 1) if r.metrics and metric_value(r.metrics, "latency_p95_ms") is not None else None),
        "Saved": fmt_time(r.created_at),
    } for r in runs])
    event = st.dataframe(df, hide_index=True, width="stretch", on_select="rerun", selection_mode="multi-row", key="hist_table")
    picked = [runs[i] for i in event.selection.rows if i < len(runs)]

    b1, b2, b3, b4 = st.columns(4)
    comparable = [r for r in picked if r.status == RunStatus.COMPLETED and r.metrics]
    if b1.button(f"Compare selected ({len(comparable)})", type="primary", disabled=len(comparable) < 2, key="hist_cmp",
                 help="Select 2-6 completed runs in the table."):
        st.session_state["compare_ids"] = [r.run_id for r in comparable[: theme.MAX_SERIES]]
        nav.go("compare")
    if b2.button("Open selected", disabled=len(picked) != 1, key="hist_open", help="Select exactly one run."):
        st.session_state["open_run_id"] = picked[0].run_id
        nav.go("results")
    b3.download_button("Export filtered CSV", runs_to_csv(runs), "voltix_history.csv", "text/csv", key="hist_csv")
    with b4.popover("Delete selected", disabled=not picked):
        st.write(f"Permanently delete {len(picked)} run(s)?")
        if st.button("Yes, delete", key="hist_del"):
            try:
                for r in picked:
                    repo.delete(r.run_id)
            except StorageError as exc:
                st.error(f"Could not delete: {exc}")
            else:
                st.toast(f"Deleted {len(picked)} run(s).")
                st.rerun()
