"""Optimize page: fair comparisons and evidence-based findings from saved runs.

Nothing on this page predicts a result. Every figure is a measured difference between saved
runs (or arithmetic on them), shown with its uncertainty, its trade-offs and a confidence level.
"""

from __future__ import annotations

import streamlit as st

from voltix.exports import study_to_csv, study_to_json, study_to_markdown
from voltix.fairness import LEVEL_LABEL, explain_level
from voltix.optimize import ConfidenceLevel, build_study, price_keys, suggest_baseline
from voltix.schemas import RunStatus
from voltix.stats import DEFAULT_MIN_EFFECT_PCT

from .. import charts, nav
from ..components import demo_banner, esc, get_repo, kpi_row, page_header, run_option_label, load_runs

KIND_LABEL = {"win": "Supported improvement", "trade_off": "Trade-off", "regression": "Got worse",
              "no_difference": "No detectable difference", "dominated": "Outperformed",
              "no_improvement": "No clear improvement found"}
SIM_KIND_LABEL = {"win": "Simulated: better in the model", "trade_off": "Simulated: trade-off in the model",
                  "regression": "Simulated: worse in the model", "no_difference": "Simulated: no difference in the model",
                  "dominated": "Simulated: outperformed in the model", "no_improvement": "Simulated: no clear improvement"}
KIND_ORDER = {k: i for i, k in enumerate(["win", "trade_off", "dominated", "regression", "no_improvement", "no_difference"])}
CONF_LABEL = {"high": "HIGH CONFIDENCE", "medium": "MEDIUM CONFIDENCE", "low": "LOW CONFIDENCE",
              "insufficient": "INSUFFICIENT DATA", "simulated": "SIMULATED: NOT EVIDENCE"}
CHECK_ICON = {"pass": ("✓", "vx-check-pass"), "warn": ("▲", "vx-check-warn"), "fail": ("✕", "vx-check-fail"), "info": ("●", "vx-check-info")}
VERDICT_TEXT = {"improved": "▲ better", "regressed": "▼ worse", "negligible": "≈ negligible",
                "no_detectable_change": "≈ no detectable change", "not_assessed": "not assessed"}
VERDICT_CLASS = {"improved": "vx-better", "regressed": "vx-worse"}


def _conf_pill(level: ConfidenceLevel) -> str:
    return f'<span class="vx-pill conf-{level.value}">{CONF_LABEL[level.value]}</span>'


def _finding_card(f) -> str:
    ev = "".join(f"<li>{esc(e)}</li>" for e in f.evidence)
    tr = "".join(f"<li>{esc(t)}</li>" for t in f.tradeoffs)
    label = (SIM_KIND_LABEL if f.basis == "simulated" else KIND_LABEL)[f.kind]
    return (f'<div class="vx-find {f.kind}"><span class="vx-find-kind">{esc(label)}</span>{_conf_pill(f.confidence)} '
            f'<span class="vx-find-title">{esc(f.title)}</span><p>{esc(f.statement)}</p>'
            + (f'<div class="vx-label">Measured evidence</div><ul>{ev}</ul>' if ev else "")
            + (f'<div class="vx-label">What you give up</div><ul>{tr}</ul>' if tr else "") + "</div>")


def _level_panel(pa) -> str:
    rep = pa.comparability
    items = "".join(f"<li>{esc(i.message)}</li>" for i in rep.issues if i.severity in ("warning", "blocker", "note") and i.code != "simulated")
    factors = f"<p><b>Changed:</b> {esc('; '.join(rep.factors_changed))}</p>" if rep.factors_changed else ""
    return (f'<div class="vx-level {rep.level.value}"><b>{esc(LEVEL_LABEL[rep.level])}</b><p>{esc(explain_level(rep))}</p>{factors}'
            + (f"<ul style='color:#B4BBC8;font-size:.86rem;margin:.4rem 0 0 1.1rem;padding:0'>{items}</ul>" if items else "") + "</div>")


def _metric_table(pa) -> str:
    head = "<tr><th>Metric</th><th>Baseline</th><th>Candidate</th><th>Change (95% interval)</th><th>Verdict</th></tr>"
    body = ""
    for m in pa.metrics.values():
        b = "n/a" if m.baseline is None else f"{m.baseline:,.2f} {m.unit}"
        c = "n/a" if m.candidate is None else f"{m.candidate:,.2f} {m.unit}"
        if m.change_pct is None:
            chg = "n/a"
        elif m.has_ci and m.ci_low_pct is not None:
            chg = f"{m.change_pct:+.1f}% ({m.ci_low_pct:+.1f}% to {m.ci_high_pct:+.1f}%)"
        else:
            chg = f"{m.change_pct:+.1f}% (no interval)"
        verdict = f'<span class="{VERDICT_CLASS.get(m.verdict, "vx-same")}">{VERDICT_TEXT[m.verdict]}</span>'
        note = f'<br><span class="vx-same" style="font-size:.76rem">{esc(m.note)}</span>' if m.note else ""
        body += f"<tr><td>{esc(m.label)}</td><td>{esc(b)}</td><td>{esc(c)}</td><td>{esc(chg)}</td><td>{verdict}{note}</td></tr>"
    return f'<div class="vx-scroll"><table class="vx-table">{head}{body}</table></div>'


def _confidence_block(pa) -> None:
    st.markdown(f"{_conf_pill(pa.confidence.level)} &nbsp; {esc(pa.confidence.summary)}", unsafe_allow_html=True)
    rows = ""
    for c in pa.confidence.checks:
        icon, cls = CHECK_ICON[c.status]
        rows += f'<li><span class="{cls}">{icon} {esc(c.name)}</span>: {esc(c.detail)}</li>'
    st.markdown(f"<ul style='color:#B4BBC8;font-size:.88rem;margin:.3rem 0 .6rem 1.1rem;padding:0'>{rows}</ul>", unsafe_allow_html=True)


def render() -> None:
    page_header("Optimize", "What does your data actually support?",
                "Fair comparisons and optimization findings drawn only from measured differences between saved runs, "
                "with trade-offs and confidence. Nothing here is a prediction.")
    demo_banner()
    repo = get_repo()
    runs = [r for r in load_runs(repo, include_samples=True) if r.status == RunStatus.COMPLETED and r.metrics]
    if len(runs) < 2:
        st.info("Optimization needs at least two saved, completed runs of the same workload. Run benchmarks and save them, "
                "or load the demo experiments (simulated) from the Overview page.")
        if st.button("Open Run Benchmark", key="opt_go_run"):
            nav.go("run")
        return

    by_id = {r.run_id: r for r in runs}
    default = suggest_baseline(runs).run_id  # type: ignore[union-attr]
    if st.session_state.get("opt_baseline") not in by_id:
        st.session_state["opt_baseline"] = default
    baseline_id = st.selectbox("Baseline run (the configuration you use today)", list(by_id), key="opt_baseline",
                               format_func=lambda i: run_option_label(by_id[i]),
                               help="Every other saved run of the same workload is compared against this one.")
    baseline = by_id[baseline_id]

    prices: dict[str, float] = {}
    with st.expander("Analysis settings"):
        min_effect = st.slider("Smallest change that matters (%)", 0.5, 10.0, DEFAULT_MIN_EFFECT_PCT, 0.5, key="opt_min_effect",
                               help="A change is only called an improvement or regression if its 95% interval excludes zero "
                                    "AND it is at least this large.")
        if baseline.is_simulated:
            st.caption("Cost per token is not available for simulated data: a price on a simulated device would be meaningless.")
        else:
            st.markdown("**Optional: cost per 1M output tokens.** Enter your own hourly price for each device. "
                        "Leave at 0 to skip. Cost is derived from measured throughput; it assumes the device is fully busy and "
                        "ignores model load time, idle time and every other cost.")
            same_model = [r for r in runs if not r.is_simulated and r.config.model_id == baseline.config.model_id]
            for dev in price_keys(same_model):
                v = st.number_input(f"Price per hour: {dev}", min_value=0.0, value=0.0, step=0.1, key=f"opt_price_{dev}")
                if v > 0:
                    prices[dev] = float(v)

    try:
        study = build_study(baseline, runs, prices=prices or None, min_effect_pct=min_effect)
    except ValueError as exc:
        st.error(str(exc))
        return

    n_cmp = len(study.analyses)
    kpi_row([
        ("Runs compared", f"{n_cmp}", f"{len(study.excluded)} left out as not like-for-like"),
        (("Better in the model" if study.data_source == "simulated" else "Supported improvements"),
         f"{sum(f.kind == 'win' for f in study.findings)}",
         ("simulated: not evidence" if study.data_source == "simulated" else "better on something, worse on nothing")),
        ("Trade-offs", f"{sum(f.kind == 'trade_off' for f in study.findings)}", "better on some, worse on others"),
        ("Not outperformed", f"{len(study.frontier)} of {len(study.run_ids)}", "by any other compared run"),
    ])
    if study.data_source == "simulated":
        st.warning("These runs are SIMULATED. The analysis shows how the workflow works; its findings are not evidence about real hardware.")
    if n_cmp == 0:
        st.info("No other saved run is a fair comparison with this baseline. Benchmark the same model and prompt/output length "
                "with one setting changed (precision, batch size or hardware), then come back.")
    else:
        st.markdown("#### What the evidence supports")
        ordered = sorted(study.findings, key=lambda f: KIND_ORDER[f.kind])
        main = [f for f in ordered if f.kind != "no_difference"]
        for f in main:
            st.markdown(_finding_card(f), unsafe_allow_html=True)
        quiet = [f for f in ordered if f.kind == "no_difference"]
        if quiet:
            with st.expander(f"{len(quiet)} comparison(s) with no detectable difference"):
                for f in quiet:
                    st.markdown(_finding_card(f), unsafe_allow_html=True)

        st.markdown("#### Trade-off map")
        st.plotly_chart(charts.tradeoff_map(study, by_id), width="stretch", key="opt_map")
        st.caption("Point estimates only. A run is marked 'outperformed' only when a like-for-like comparison shows another run "
                   "better on something and not worse on anything assessed, outside measurement noise.")

        st.markdown("#### Inspect one comparison")
        labels = {a.candidate_id: f"{a.candidate_name}: {a.classification.replace('_', ' ')}" for a in study.analyses}
        if st.session_state.get("opt_candidate") not in labels:
            st.session_state["opt_candidate"] = next(iter(labels))
        cand_id = st.selectbox("Candidate", list(labels), format_func=labels.get, key="opt_candidate")
        pa = next(a for a in study.analyses if a.candidate_id == cand_id)
        st.markdown(_level_panel(pa), unsafe_allow_html=True)
        st.markdown(f"**{esc(pa.headline)}**", unsafe_allow_html=True)
        if pa.metrics:
            st.plotly_chart(charts.change_intervals(pa), width="stretch", key="opt_forest")
            st.markdown(_metric_table(pa), unsafe_allow_html=True)
            st.write("")
        st.markdown("##### Confidence")
        _confidence_block(pa)

    st.markdown("#### Not yet measured")
    cov = study.coverage
    st.caption(f"Tried so far for this workload: precision {', '.join(cov.precisions)}; batch size "
               f"{', '.join(map(str, cov.batch_sizes))}; device {', '.join(cov.devices)}. "
               "Untried settings have no number here, because none has been measured.")
    for e in study.next_experiments:
        st.markdown(f"- **{esc(e.suggestion)}.** {esc(e.reason)}")
    if study.excluded:
        with st.expander(f"{len(study.excluded)} run(s) left out (not a fair comparison)"):
            for name, why in study.excluded:
                st.markdown(f"- **{esc(name)}**: {esc(why)}")

    st.markdown("#### Export")
    names = {r.run_id: r.name for r in runs}
    e1, e2, e3 = st.columns(3)
    e1.download_button("Study JSON", study_to_json(study), f"voltix_study_{baseline_id}.json", "application/json", key="opt_json")
    e2.download_button("Metrics CSV", study_to_csv(study), f"voltix_study_{baseline_id}.csv", "text/csv", key="opt_csv", disabled=not study.analyses)
    e3.download_button("Markdown report", study_to_markdown(study, names), f"voltix_study_{baseline_id}.md", "text/markdown", key="opt_md")
    with st.expander("How to read this page"):
        for n in study.notes:
            st.markdown(f"- {esc(n)}")
