"""Compare Runs page."""

from __future__ import annotations

import json

import streamlit as st

from voltix.compare import (
    ComparisonError,
    build_comparison,
    comparison_rows,
    comparison_warnings,
    config_diff_rows,
)
from voltix.exports import generic_rows_to_csv
from voltix.fairness import LEVEL_LABEL, explain_level
from voltix.metrics import METRIC_BY_KEY, format_metric
from voltix.optimize import analyze_pair, replicate_noise
from voltix.schemas import RunStatus

from .. import charts, theme
from ..components import demo_banner, esc, get_repo, page_header, run_option_label, load_runs


def _delta_cell(delta: float | None, mr) -> str:
    """Change vs baseline. A verdict is shown only when it accounts for uncertainty."""
    if mr is not None and mr.change_pct is not None and mr.verdict != "not_assessed":
        d = mr.change_pct
        interval = (f" (95% CI {mr.ci_low_pct:+.1f}% to {mr.ci_high_pct:+.1f}%)" if mr.has_ci and mr.ci_low_pct is not None
                    else " (single measurement)")
        if mr.verdict == "improved":
            return f'<span class="vx-better">▲ {d:+.1f}% better</span><br><span class="vx-same">{interval.strip()}</span>'
        if mr.verdict == "regressed":
            return f'<span class="vx-worse">▼ {d:+.1f}% worse</span><br><span class="vx-same">{interval.strip()}</span>'
        word = "negligible" if mr.verdict == "negligible" else "within noise"
        return f'<span class="vx-same">≈ {d:+.1f}%, {word}</span><br><span class="vx-same">{interval.strip()}</span>'
    if delta is None:
        return '<span class="vx-same">n/a</span>'
    return f'<span class="vx-same">{delta:+.1f}% (no verdict: no uncertainty estimate)</span>'


def _metrics_table(runs, comparison, baseline_id: str, analyses) -> str:
    head = "<tr><th>Metric</th>"
    for i, r in enumerate(runs):
        color = theme.SERIES[i % theme.MAX_SERIES]
        base = " (baseline)" if r.run_id == baseline_id else ""
        head += f'<th><span class="vx-swatch" style="background:{color}"></span>{esc(r.name[:30])}{base}</th>'
    head += "</tr>"
    body = ""
    for mc in comparison:
        body += f"<tr><td>{esc(mc.label)}</td>"
        for r in runs:
            val = format_metric(mc.key, mc.values[r.run_id])
            if r.run_id == baseline_id:
                body += f"<td>{esc(val)}</td>"
                continue
            pa = analyses.get(r.run_id)
            mr = pa.metrics.get(mc.key) if pa is not None else None
            body += f"<td>{esc(val)}<br>{_delta_cell(mc.deltas_pct[r.run_id], mr)}</td>"
        body += "</tr>"
    return f'<div class="vx-scroll"><table class="vx-table">{head}{body}</table></div>'


def _config_table(runs) -> str:
    rows = config_diff_rows(runs)
    head = "<tr><th>Setting</th>" + "".join(f"<th>{esc(r.name[:30])}</th>" for r in runs) + "</tr>"
    body = ""
    for row in rows:
        cls = ' class="vx-diff"' if row["differs"] else ""
        body += f"<tr><td>{esc(row['field'])}</td>" + "".join(f"<td{cls}>{esc(row[r.run_id])}</td>" for r in runs) + "</tr>"
    return f'<div class="vx-scroll"><table class="vx-table">{head}{body}</table></div>'


def render() -> None:
    page_header("Compare Runs", "Side-by-side comparison", "Pick two to six saved, completed runs and see exactly what changed.")
    demo_banner()
    repo = get_repo()
    runs = [r for r in load_runs(repo, include_samples=True) if r.status == RunStatus.COMPLETED and r.metrics]
    if len(runs) < 2:
        st.info("You need at least two saved, completed runs. Run a benchmark and save it, or load the demo experiments from the Overview page.")
        return

    by_id = {r.run_id: r for r in runs}
    preselected = [i for i in st.session_state.pop("compare_ids", []) if i in by_id][: theme.MAX_SERIES]
    if preselected:
        st.session_state["cmp_select"] = preselected
    st.session_state.setdefault("cmp_select", [r.run_id for r in runs[:2]])
    st.session_state["cmp_select"] = [i for i in st.session_state["cmp_select"] if i in by_id]

    selected_ids = st.multiselect("Runs to compare", list(by_id), format_func=lambda i: run_option_label(by_id[i]),
                                  max_selections=theme.MAX_SERIES, key="cmp_select")
    if len(selected_ids) < 2:
        st.info("Select at least two runs.")
        return
    selected = [by_id[i] for i in selected_ids]
    baseline_id = st.selectbox("Baseline", selected_ids, format_func=lambda i: by_id[i].name, key="cmp_baseline")
    if baseline_id not in selected_ids:
        baseline_id = selected_ids[0]

    for w in comparison_warnings(selected):
        st.warning(w) if "mix" in w else st.caption("⚠ " + w)

    try:
        comparison = build_comparison(selected, baseline_id)
    except ComparisonError as exc:
        st.error(str(exc))
        return

    noise = replicate_noise(runs, like=by_id[baseline_id]) if not by_id[baseline_id].is_simulated else None
    analyses = {r.run_id: analyze_pair(by_id[baseline_id], r, noise=noise) for r in selected if r.run_id != baseline_id}
    st.markdown("#### Is this a fair comparison?")
    for r in selected:
        pa = analyses.get(r.run_id)
        if pa is None:
            continue
        rep_ = pa.comparability
        st.markdown(f'<div class="vx-level {rep_.level.value}"><b>{esc(r.name)}: {esc(LEVEL_LABEL[rep_.level])}</b>'
                    f'<p>{esc(explain_level(rep_))}</p></div>', unsafe_allow_html=True)
    st.caption("Open the Optimize page for trade-offs, confidence checks and what has not been measured.")

    st.markdown("#### Configuration differences")
    st.caption("Highlighted cells differ between runs.")
    st.markdown(_config_table(selected), unsafe_allow_html=True)

    st.markdown("#### Metrics vs baseline")
    st.caption("▲ / ▼ appear only when the 95% interval of the change excludes zero and the change is at least 2%. "
               "Otherwise the difference is within measurement noise. Metrics recorded once per run have no interval and get no verdict.")
    st.markdown(_metrics_table(selected, comparison, baseline_id, analyses), unsafe_allow_html=True)
    st.write("")

    c1, c2 = st.columns(2)
    c1.plotly_chart(charts.run_bars(selected, "throughput_tokens_per_s"), width="stretch", key="cmp_thr")
    c2.plotly_chart(charts.latency_percentiles(selected), width="stretch", key="cmp_lat")
    c3, c4 = st.columns(2)
    c3.plotly_chart(charts.run_bars(selected, "ttft_mean_ms", title="Time to first token, mean (ms)"), width="stretch", key="cmp_ttft")
    mem = charts.memory_breakdown_chart(selected)
    if mem is not None:
        c4.plotly_chart(mem, width="stretch", key="cmp_mem")
    else:
        c4.plotly_chart(charts.run_bars(selected, "peak_memory_gb"), width="stretch", key="cmp_mem2")

    st.markdown("#### Export comparison")
    rows = comparison_rows(selected, comparison)
    for row in rows:
        pa = analyses.get(row["run_id"])
        mr = pa.metrics.get(row["metric_key"]) if pa is not None else None
        row["comparability"] = pa.comparability.level.value if pa is not None else None
        row["ci95_low_pct"] = mr.ci_low_pct if mr is not None else None
        row["ci95_high_pct"] = mr.ci_high_pct if mr is not None else None
        row["verdict"] = mr.verdict if mr is not None else None
    d1, d2, _ = st.columns([1, 1, 3])
    d1.download_button("Comparison CSV", generic_rows_to_csv(rows), "voltix_comparison.csv", "text/csv", key="cmp_csv")
    d2.download_button("Comparison JSON", json.dumps({"baseline_run_id": baseline_id, "rows": rows,
                                                     "warnings": comparison_warnings(selected)}, indent=2),
                       "voltix_comparison.json", "application/json", key="cmp_json")
