"""Overview page."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from voltix.catalog import hardware_label, model_label
from voltix.demo import has_demo_runs, remove_demo_runs, seed_demo_runs
from voltix.metrics import metric_value
from voltix.schemas import RunStatus

from .. import charts, nav
from ..components import demo_banner, fmt_time, get_repo, kpi_row, page_header, load_runs


def render() -> None:
    page_header("Overview", "Inference benchmarking, made explainable",
                "Benchmark, compare and optimize LLM inference configurations.")
    demo_banner()
    repo = get_repo()
    runs = load_runs(repo)
    done = [r for r in runs if r.status == RunStatus.COMPLETED and r.metrics]
    simulated = [r for r in runs if r.is_simulated]
    measured = [r for r in runs if not r.is_simulated]

    if not runs:
        st.markdown("### Start here")
        c1, c2 = st.columns(2)
        with c1:
            st.markdown('<div class="vx-card"><b>Explore with demo experiments</b><br>'
                        '<span style="color:#8B94A3">Load 12 pre-built, clearly labelled SIMULATED experiments '
                        '(precision, batch size, hardware, one expected out-of-memory failure).</span></div>',
                        unsafe_allow_html=True)
            if st.button("Load demo experiments", type="primary", key="ov_seed"):
                n = seed_demo_runs(repo)
                st.toast(f"Loaded {n} simulated demo runs.")
                st.rerun()
        with c2:
            st.markdown('<div class="vx-card"><b>Run your own benchmark</b><br>'
                        '<span style="color:#8B94A3">Pick a model profile, precision and batch size and run a simulated benchmark.</span></div>',
                        unsafe_allow_html=True)
            if st.button("Open Run Benchmark", key="ov_run"):
                nav.go("run")
        return

    best_thr = max(done, key=lambda r: r.metrics.throughput_tokens_per_s) if done else None
    best_lat = min([r for r in done if metric_value(r.metrics, "latency_p95_ms") is not None], key=lambda r: r.metrics.latency_p95_ms, default=None)
    kpi_row([
        ("Saved runs", f"{len(runs)}", f"{len(simulated)} simulated · {len(measured)} measured"),
        ("Best throughput", f"{best_thr.metrics.throughput_tokens_per_s:,.0f} tok/s" if best_thr else "n/a",
         (best_thr.name[:34] + (" (sim)" if best_thr.is_simulated else "")) if best_thr else ""),
        ("Lowest p95 latency", f"{best_lat.metrics.latency_p95_ms:,.0f} ms" if best_lat else "n/a",
         (best_lat.name[:34] + (" (sim)" if best_lat.is_simulated else "")) if best_lat else ""),
        ("Not completed", f"{sum(r.status != RunStatus.COMPLETED for r in runs)}", "failed, cancelled or timed out"),
    ])
    st.write("")

    left, right = st.columns([5, 4])
    with left:
        sim_done = [r for r in done if r.is_simulated]
        real_done = [r for r in done if not r.is_simulated]
        options = [o for o, rs in (("Simulated", sim_done), ("Measured", real_done)) if rs]
        if options:
            # Simulated and measured runs are never plotted on the same axes: their scales are not comparable.
            shown = st.radio("Chart data source", options, horizontal=True, key="ov_source", label_visibility="collapsed",
                             format_func=lambda o: f"{o} ({len(sim_done) if o == 'Simulated' else len(real_done)})")
            st.plotly_chart(charts.throughput_vs_latency(sim_done if shown == "Simulated" else real_done),
                            width="stretch", key="ov_scatter")
        else:
            st.info("No completed runs yet.")
    with right:
        st.markdown("#### Recent runs")
        recent = runs[:8]
        df = pd.DataFrame([{
            "Run": r.name, "Source": "SIMULATED" if r.is_simulated else "MEASURED",
            "Status": r.status.value,
        } for r in recent])
        st.dataframe(df, hide_index=True, width="stretch", height=330,
                     column_config={"Run": st.column_config.TextColumn(width="medium"),
                                    "Source": st.column_config.TextColumn(width="small"),
                                    "Status": st.column_config.TextColumn(width="small")})

    st.markdown("#### Quick actions")
    a, b, c, d = st.columns(4)
    if a.button("Run a benchmark", type="primary", key="ov_a"):
        nav.go("run")
    if b.button("Compare runs", key="ov_b"):
        nav.go("compare")
    if c.button("Open history", key="ov_c"):
        nav.go("history")
    if has_demo_runs(repo):
        if d.button("Remove demo experiments", key="ov_rm"):
            n = remove_demo_runs(repo)
            st.toast(f"Removed {n} demo runs.")
            st.rerun()
    else:
        if d.button("Load demo experiments", key="ov_seed2"):
            n = seed_demo_runs(repo)
            st.toast(f"Loaded {n} simulated demo runs.")
            st.rerun()
