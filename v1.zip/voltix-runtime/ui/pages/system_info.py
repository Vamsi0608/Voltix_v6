"""System Information page."""

from __future__ import annotations

import streamlit as st

from voltix import APP_NAME, __version__
from voltix import estimation as est
from voltix.backends import all_statuses
from voltix.backends.devices import probe_accelerators
from voltix.catalog import HARDWARE, MODELS
from voltix.sysinfo import collect_system_info

from ..components import demo_banner, get_repo, kpi_row, page_header


@st.cache_data(ttl=30, show_spinner=False)
def _info() -> dict:
    return collect_system_info()


def render() -> None:
    page_header("System Information", "Environment and backend readiness", "What this machine can actually run today.")
    demo_banner()
    info = _info()
    gpu = info["gpu"]
    kpi_row([
        ("GPU", f"{len(gpu['gpus'])} detected" if gpu["available"] else "None detected", gpu["detail"][:60]),
        ("CPU cores", str(info["cpu_count"] or "n/a"), info["machine"]),
        ("System RAM", f"{info['ram_gb']} GB" if info["ram_gb"] else "n/a", info["os"]),
        ("Python", info["python"], f"{APP_NAME} {__version__}"),
    ])
    st.write("")

    st.markdown("#### Inference backends")
    st.dataframe([{
        "Backend": s.display_name,
        "Implemented": "Yes" if s.implemented else "No",
        "Can run now": "Yes" if s.available else "No",
        "Output type": "SIMULATED" if s.is_simulated else ("MEASURED" if s.implemented else "n/a (not implemented)"),
        "Detail": s.detail,
    } for s in all_statuses()], hide_index=True, width="stretch")
    st.caption("The Transformers backend runs real inference (CPU or CUDA GPU) and tags results MEASURED. "
               "vLLM is a placeholder. The simulated backend never executes a model.")

    st.markdown("#### PyTorch accelerators")
    st.caption("Importing torch can take a while the first time, so this is on demand.")
    if st.button("Probe PyTorch and CUDA", key="sys_probe"):
        with st.spinner("Importing torch…"):
            st.session_state["accel_probe"] = probe_accelerators().to_dict()
    probe = st.session_state.get("accel_probe")
    if probe:
        if not probe["torch_installed"]:
            st.warning("torch is not installed: " + (probe["error"] or "") + ". Install with `pip install -r requirements-hf.txt` in the environment that runs the app, then restart it.")
        else:
            st.markdown(f"torch **{probe['torch_version']}** · built for CUDA **{probe['cuda_build'] or 'none (CPU build)'}** · "
                        f"CUDA usable: **{'yes' if probe['cuda_available'] else 'no'}**")
            if probe["error"]:
                st.error(probe["error"])
            if probe["devices"]:
                st.dataframe(probe["devices"], hide_index=True, width="stretch")
            elif not probe["error"]:
                st.info("No CUDA GPU is usable from PyTorch here. The Transformers backend will run on CPU.")

    left, right = st.columns(2)
    with left:
        st.markdown("#### GPUs")
        if gpu["available"]:
            st.dataframe(gpu["gpus"], hide_index=True, width="stretch")
        else:
            st.info(gpu["detail"] + " Simulated demo mode works without a GPU.")
    with right:
        st.markdown("#### Python packages")
        st.dataframe([{"Package": k, "Version": v or "not installed"} for k, v in info["packages"].items()],
                     hide_index=True, width="stretch")

    st.markdown("#### Storage")
    try:
        repo = get_repo()
        st.markdown(f"Database: `{repo.path}` · {repo.count()} saved runs · {repo.size_bytes() / 1024:,.0f} KB")
    except Exception as exc:  # noqa: BLE001 - display any storage problem
        st.error(f"Storage unavailable: {exc}")

    with st.expander("How the simulation works (all assumptions)"):
        for k, v in est.ASSUMPTIONS.items():
            st.markdown(f"**{k}.** {v}")
    with st.expander("Simulated hardware and model profiles"):
        st.dataframe([{"Hardware": h.display_name, "Memory (GB)": h.memory_gb, "Bandwidth (GB/s)": h.memory_bandwidth_gbps,
                       "Peak fp16 TFLOPS": h.peak_tflops_fp16, "bf16": h.supports_bf16} for h in HARDWARE.values()],
                     hide_index=True, width="stretch")
        st.dataframe([{"Model": m.display_name, "Params (B)": m.params_billion, "Layers": m.num_layers, "Hidden": m.hidden_size,
                       "KV heads": m.num_kv_heads, "Max context": m.max_context} for m in MODELS.values()],
                     hide_index=True, width="stretch")
        st.caption("Approximate, rounded figures used only by the simulated backend.")
