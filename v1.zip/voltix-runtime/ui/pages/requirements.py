"""Requirements page: which saved runs meet YOUR latency / throughput / memory limits."""

from __future__ import annotations

import streamlit as st

from voltix.constraints import OBJECTIVES, Constraints, Eligibility, Verdict, select
from voltix.schemas import RunStatus

from .. import nav
from ..components import demo_banner, esc, get_repo, load_runs, page_header, run_option_label

_PILL = {Eligibility.ELIGIBLE: "✅ meets all", Eligibility.VIOLATES: "❌ does not meet", Eligibility.UNKNOWN: "❔ cannot be confirmed"}
_V = {Verdict.PASS: "✅ pass", Verdict.FAIL: "❌ fail", Verdict.NOT_ASSESSED: "❔ not assessed"}
_OBJ = {"throughput": "Highest throughput", "latency_p95": "Lowest p95 latency", "memory": "Lowest memory"}


def _limit(label: str, key: str, help_: str) -> float | None:
    v = st.number_input(label, min_value=0.0, value=0.0, step=1.0, key=key, help=help_ + " Leave at 0 for no requirement.")
    return float(v) if v > 0 else None


def render() -> None:
    page_header("Requirements", "Which setup meets your limits?",
                "State your own limits. Saved runs are checked against them, using only what was measured; "
                "limits that cannot be checked are reported as such, never assumed to pass.")
    demo_banner()
    runs = [r for r in load_runs(get_repo(), include_samples=True) if r.status == RunStatus.COMPLETED and r.metrics]
    if not runs:
        st.info("No completed runs are saved yet. Run and save a benchmark first.")
        if st.button("Open Run Benchmark", key="req_go_run"):
            nav.go("run")
        return

    st.caption("Each saved run is ONE measurement. On this project's own repeat tests, identical short CPU runs differed by 10% or more "
               "from each other (see MATRIX_RESULTS.md), so a run that passes by a thin margin may fail on the next try. Repeat important runs.")
    c1, c2 = st.columns(2)
    with c1:
        p95 = _limit("Latency p95 at most (ms)", "req_p95", "Needs at least 20 iterations in a run to be checked.")
        ttft = _limit("Time to first token (mean) at most (ms)", "req_ttft", "")
    with c2:
        thr = _limit("Throughput at least (tokens/s)", "req_thr", "")
        mem = _limit("Peak memory at most (GB)", "req_mem", "Checked for GPU runs only; CPU process memory is not comparable to a device limit.")
    objective = st.radio("Among runs that meet every limit, prefer", list(OBJECTIVES), format_func=_OBJ.get, horizontal=True, key="req_obj")
    try:
        cons = Constraints(max_latency_p95_ms=p95, max_ttft_ms=ttft, min_throughput_tokens_per_s=thr, max_memory_gb=mem)
    except ValueError as exc:
        st.error(str(exc))
        return
    if cons.empty:
        st.info("Enter at least one limit above.")
        return

    for sel in select(runs, cons, objective):
        _, model, prompt, out = sel.key
        st.markdown(f"#### {esc(model)} · {prompt} prompt + {out} output tokens · {sel.data_source.upper()}")
        (st.warning if sel.data_source == "simulated" else st.info)(sel.note)
        if sel.best is not None:
            st.success(f"Best saved run that meets every limit: **{sel.best.run.name}**")
        for ev in sel.evaluations:
            with st.expander(f"{_PILL[ev.eligibility]} · {run_option_label(ev.run)}", expanded=ev is sel.best):
                for r in ev.results:
                    st.markdown(f"- {_V[r.verdict]} **{esc(r.label or r.name)}**: {esc(r.reason)}" + (" *(thin margin)*" if r.marginal else ""))
