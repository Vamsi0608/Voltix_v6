"""Streamlit access gate. Call ``gate()`` first in app.py; it stops the script unless the visitor may proceed."""

from __future__ import annotations

import logging

import streamlit as st

from voltix import security

_LIMITER = security.LoginLimiter()


@st.cache_resource
def _limiter() -> security.LoginLimiter:
    return _LIMITER


def _bind_address() -> str | None:
    try:
        return st.get_option("server.address")
    except Exception:  # noqa: BLE001
        return None


def gate() -> None:
    problem = security.exposure_problem(_bind_address())
    if problem:
        st.error(f"VOLTIX will not serve in this configuration. {problem}")
        st.stop()
    token = security.configured_token()
    if token is None or st.session_state.get("vx_authed") is True:
        return
    st.title("VOLTIX Runtime")
    st.caption("Enter the access token to continue.")
    with st.form("vx_login"):
        supplied = st.text_input("Access token", type="password", max_chars=256, key="vx_token_input")
        go = st.form_submit_button("Sign in")
    if go:
        ok, wait = _limiter().attempt(supplied or "", token)
        st.session_state.pop("vx_token_input", None)
        logging.getLogger("voltix.security").info("sign-in %s", "accepted" if ok else ("refused (rate limited)" if wait > 0 else "rejected"))
        if ok:
            st.session_state["vx_authed"] = True
            st.rerun()
        st.error(f"Too many attempts. Try again in {wait:,.0f} s." if wait > 0 else "That token is not correct.")
    st.stop()
