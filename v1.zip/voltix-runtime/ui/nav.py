"""Page registry so any page can switch to another (populated by app.py each run)."""

from __future__ import annotations

import streamlit as st

PAGES: dict[str, "st.Page"] = {}


def go(key: str) -> None:
    page = PAGES.get(key)
    if page is not None:
        st.switch_page(page)
