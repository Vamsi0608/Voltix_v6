"""Reusable Streamlit UI pieces."""

from __future__ import annotations

import html
from typing import Optional, Sequence

import streamlit as st

from voltix.db import RunRepository, StorageError
from voltix.schemas import BenchmarkRun, Recommendation, RunStatus

from . import theme

SIM_BANNER_TEXT = (
    "<b>SIMULATED vs MEASURED</b><br>"
    "Runs tagged <b>SIMULATED</b> (demo mode) come from an analytic model: no model was loaded and nothing was measured. "
    "Runs tagged <b>MEASURED</b> were executed by the Hugging Face Transformers backend on the machine recorded in their environment."
)


def esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def page_header(eyebrow: str, title: str, subtitle: str = "") -> None:
    sub = f"<p>{esc(subtitle)}</p>" if subtitle else ""
    st.markdown(
        f'<div class="vx-header"><div class="vx-eyebrow">{esc(eyebrow)}</div><h1>{esc(title)}</h1>{sub}</div>',
        unsafe_allow_html=True,
    )


def demo_banner() -> None:
    st.markdown(f'<div class="vx-banner"><div>⚠</div><div>{SIM_BANNER_TEXT}</div></div>', unsafe_allow_html=True)


def source_pill(run: BenchmarkRun) -> str:
    if run.is_simulated:
        return '<span class="vx-pill sim">⚠ SIMULATED</span>'
    return '<span class="vx-pill real">● MEASURED</span>'


def status_pill(run: BenchmarkRun) -> str:
    if run.status == RunStatus.FAILED:
        return '<span class="vx-pill failed">✕ FAILED</span>'
    if run.status == RunStatus.CANCELLED:
        return '<span class="vx-pill failed">■ CANCELLED</span>'
    if run.status == RunStatus.TIMED_OUT:
        return '<span class="vx-pill failed">⏱ TIMED OUT</span>'
    return '<span class="vx-pill ok">✓ COMPLETED</span>'


def memory_label(run: BenchmarkRun) -> str:
    """Name the memory figure honestly: estimate, GPU tensors, or whole-process RAM."""
    if run.is_simulated:
        return "Peak memory (est.)"
    kind = (run.environment.get("measurement") or {}).get("memory_kind")
    return {"cuda_max_memory_allocated": "Peak GPU memory", "process_peak_rss": "Peak process RAM"}.get(kind, "Peak memory")


def environment_panel(run: BenchmarkRun) -> None:
    """Hardware/software record for a run. Simulated runs say plainly that nothing was measured."""
    env = run.environment
    if run.is_simulated:
        st.caption("Simulated run: no real hardware or software was involved. The profile below is an assumption, not a measurement.")
    elif env:
        dev, sw = env.get("device") or {}, env.get("software") or {}
        st.caption(f"Measured on {dev.get('name', 'unknown device')} ({dev.get('kind', '?')}) · torch {sw.get('torch', '?')} · "
                   f"transformers {sw.get('transformers', '?')} · Python {sw.get('python', '?')}")
    with st.expander("Hardware, software and measurement method"):
        if env:
            st.json(env, expanded=2)
        else:
            st.write("No environment was recorded for this run.")


def kpi(label: str, value: str, sub: str = "") -> str:
    sub_html = f'<div class="vx-kpi-sub">{esc(sub)}</div>' if sub else ""
    return (
        f'<div class="vx-kpi"><div class="vx-kpi-label">{esc(label)}</div>'
        f'<div class="vx-kpi-value">{esc(value)}</div>{sub_html}</div>'
    )


def kpi_row(items: Sequence[tuple[str, str, str]]) -> None:
    cols = st.columns(len(items))
    for col, (label, value, sub) in zip(cols, items):
        col.markdown(kpi(label, value, sub), unsafe_allow_html=True)


def recommendation_cards(recs: Sequence[Recommendation], simulated: bool) -> None:
    if simulated:
        st.caption("Recommendations below are based on SIMULATED data. Re-run on real hardware before acting on them.")
    st.caption("None of these states a predicted saving. Hypotheses are untested ideas: benchmark the change, then use Compare Runs or Optimize to see the measured result.")
    if not recs:
        st.success("No issues detected by the current rule set. This does not prove the configuration is optimal.")
        return
    icons = {"critical": "✕", "warning": "▲", "info": "●"}
    for rec in recs:
        sev = rec.severity.value
        evidence = "".join(f"<li>{esc(e)}</li>" for e in rec.evidence)
        caveat = f'<div class="vx-label">Caveat</div><p>{esc(rec.caveat)}</p>' if rec.caveat else ""
        kind_label = {"observation": "OBSERVED IN THIS RUN", "hypothesis": "UNTESTED HYPOTHESIS", "caveat": "READING THE RESULTS"}.get(rec.kind, rec.kind.upper())
        kind_cls = {"observation": "ok", "hypothesis": "sim", "caveat": "ok"}.get(rec.kind, "ok")
        st.markdown(
            f"""<div class="vx-rec {sev}">
<span class="vx-rec-sev">{icons[sev]} {sev}</span><span class="vx-pill {kind_cls}">{kind_label}</span> <span class="vx-rec-title">{esc(rec.title)}</span>
<p>{esc(rec.summary)}</p>
<div class="vx-label">Why this fired (evidence)</div><ul>{evidence}</ul>
<div class="vx-label">Suggested action</div><p>{esc(rec.action)}</p>
<div class="vx-label">How to verify</div><p>{esc(rec.how_to_verify)}</p>{caveat}
</div>""",
            unsafe_allow_html=True,
        )


@st.cache_resource(show_spinner=False)
def _repo_for(path_key: str) -> RunRepository:
    return RunRepository(path_key or None)


def get_repo() -> RunRepository:
    """Cached repository. Stops the page with a clear message if storage is unusable."""
    import os

    try:
        return _repo_for(os.environ.get("VOLTIX_DB_PATH", ""))
    except StorageError as exc:
        st.error(f"Storage problem: {exc}")
        st.stop()
        raise  # unreachable; keeps type checkers happy


def load_runs(repo: RunRepository, *, include_samples: bool = False) -> list[BenchmarkRun]:
    """All saved runs. A damaged row is reported and skipped instead of breaking the page."""
    try:
        runs, problems = repo.list_with_problems(include_samples=include_samples)
    except StorageError as exc:
        st.error(f"Could not read saved runs: {exc}")
        st.stop()
        raise
    if problems:
        with st.expander(f"⚠ {len(problems)} saved run(s) could not be read and are hidden", expanded=False):
            st.caption("The rest of your history is unaffected. You can remove an unreadable run below; nothing else is changed.")
            for run_id, msg in problems:
                st.markdown(f"- `{run_id}`: {esc(msg)}")
            if st.button("Remove unreadable runs", key=f"purge_bad_{abs(hash(tuple(p[0] for p in problems)))}"):
                for run_id, _ in problems:
                    repo.delete(run_id)
                st.rerun()
    return runs


def run_option_label(run: BenchmarkRun) -> str:
    tag = "SIM" if run.is_simulated else "MEASURED"
    status = "" if run.status == RunStatus.COMPLETED else f" [{run.status.value.replace('_', ' ').upper()}]"
    return f"{run.name} · {run.created_at[:16].replace('T', ' ')} · {tag}{status}"


def fmt_time(iso: str) -> str:
    return iso[:19].replace("T", " ") + " UTC"


def safe_get(repo: RunRepository, run_id: Optional[str]) -> Optional[BenchmarkRun]:
    if not run_id:
        return None
    try:
        return repo.get(run_id)
    except StorageError as exc:
        st.error(str(exc))
        return None
