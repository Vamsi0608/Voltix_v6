"""Explainable, rule-based optimization recommendations.

Each rule is a plain function over ONE completed run. Every recommendation lists
the evidence (actual numbers from the run), a suggested action, how to verify it
and a caveat, so a user can see exactly why it fired and disagree with it.

These rules never state how much a change will save. A recommendation is one of:
  observation: a fact read directly from this run (e.g. heavy tail latency);
  hypothesis:  an untested idea. The only way to learn its effect is to benchmark the
               change and compare (Compare Runs / Optimize), which reports measured
               differences with uncertainty;
  caveat:      a limit on how to read the results.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from . import estimation as est
from .catalog import get_hardware, get_model
from .metrics import percentile
from .schemas import (
    BenchmarkRun,
    DataSource,
    Precision,
    Recommendation,
    RunStatus,
    Severity,
)


@dataclass(frozen=True)
class Thresholds:
    memory_warning: float = 0.90
    memory_critical: float = 0.96
    headroom_utilization: float = 0.60  # fallback when the model profile is unknown
    projected_memory_limit: float = 0.85  # max projected utilization when suggesting a larger batch
    small_batch: int = 8
    prefill_share: float = 0.50
    tail_ratio_warning: float = 1.5
    tail_ratio_critical: float = 3.0
    min_samples_for_tail: int = 100  # p99 needs at least this many iterations (same threshold as the Optimize engine)
    min_samples_p95: int = 20
    cold_start_ratio: float = 1.5
    big_weights_share: float = 0.60


T = Thresholds()

_SEVERITY_ORDER = {Severity.CRITICAL: 0, Severity.WARNING: 1, Severity.INFO: 2}

Rule = Callable[[BenchmarkRun], Optional[Recommendation]]


def _basis(run: BenchmarkRun) -> str:
    return run.data_source.value


def _is_cpu(run: BenchmarkRun) -> bool:
    return run.environment.get("device_kind") == "cpu"


def _rule_memory_pressure(run: BenchmarkRun) -> Optional[Recommendation]:
    m = run.metrics
    if m is None or m.memory_utilization is None or m.peak_memory_gb is None:
        return None
    if m.memory_utilization < T.memory_warning:
        return None
    severity = Severity.CRITICAL if m.memory_utilization >= T.memory_critical else Severity.WARNING
    cpu_ram = (not run.is_simulated) and _is_cpu(run)
    what = "Process peak RAM" if cpu_ram else "Peak memory"
    of_what = "this computer's RAM (whole-process peak, includes everything the program held)" if cpu_ram else "device memory"
    evidence = [
        f"{what} {m.peak_memory_gb:.1f} GB = {m.memory_utilization * 100:.0f}% of {of_what} "
        f"(warning at {T.memory_warning * 100:.0f}%)."
    ]
    action = "Options to test: a smaller batch, shorter sequences, or a lower precision."
    model = get_model(run.config.model_id) if run.is_simulated else None  # catalog sizes are assumptions: never mix them into measured evidence
    if model:
        b = est.memory_breakdown(model, run.config.precision, run.config.batch_size,
                                 run.config.prompt_tokens, run.config.output_tokens)
        w_share = b.weights_gb / b.total_gb
        evidence.append(
            f"Estimated composition: weights {b.weights_gb:.1f} GB ({w_share * 100:.0f}%), "
            f"KV cache {b.kv_cache_gb:.1f} GB, overhead {b.overhead_gb:.1f} GB."
        )
        if w_share >= T.big_weights_share:
            action = "Weights are the largest part of the estimate: options to test are a lower precision or a smaller model."
        else:
            action = "The KV cache is a large part of the estimate: options to test are a smaller batch or a shorter context."
    return Recommendation(
        rule_id="memory-pressure",
        title="Memory is nearly exhausted",
        severity=severity,
        summary=("Process memory is close to this computer's RAM, so a longer prompt, a larger batch or another program may exhaust it."
                 if cpu_ram else "Peak memory is close to the device limit, so a longer prompt or larger batch may run out of memory."),
        evidence=evidence,
        action=action,
        how_to_verify="Re-run with a smaller batch, shorter sequences or lower precision and compare peak memory in "
                      "Compare Runs. No reduction is assumed until it is measured.",
        caveat="Lower precision can change output quality; verify on your own evaluation set.",
        basis=_basis(run),
        kind="observation",
    )


def _rule_full_precision(run: BenchmarkRun) -> Optional[Recommendation]:
    if run.config.precision != Precision.FP32 or _is_cpu(run):
        return None  # fp16/bf16 advice is GPU advice; CPU fp16 is unsupported here
    hw = get_hardware(run.config.hardware_id)
    target = Precision.BF16 if (hw is None or hw.supports_bf16) else Precision.FP16
    evidence = ["Run used fp32 weights (4 bytes per parameter)."]
    model = get_model(run.config.model_id)
    if model:
        evidence.append(
            f"Arithmetic, not a measurement: weights would take {model.params_billion * 2:.1f} GB instead of "
            f"{model.params_billion * 4:.1f} GB at {target.value}."
        )
    if hw is not None and not hw.supports_bf16:
        evidence.append(f"{hw.display_name} has no native bf16 support, so fp16 is suggested instead.")
    return Recommendation(
        rule_id="fp32-weights",
        title=f"Hypothesis: {target.value} instead of fp32",
        severity=Severity.INFO,
        summary="Half-precision weights take half the memory of fp32 (arithmetic). Whether that changes speed for this "
                "workload on this hardware has not been measured.",
        evidence=evidence,
        action=f"Benchmark precision {target.value} with everything else unchanged.",
        how_to_verify=f"Save the {target.value} run and open Optimize with this run as the baseline: a controlled "
                      "comparison reports the measured throughput, latency and memory change with its uncertainty.",
        caveat="Check output parity for your use case; some models are sensitive to fp16 overflow.",
        basis=_basis(run),
        kind="hypothesis",
    )


def _rule_headroom_small_batch(run: BenchmarkRun) -> Optional[Recommendation]:
    m = run.metrics
    if m is None or m.memory_utilization is None or _is_cpu(run):
        return None  # CPU decoding is compute-bound, so "free extra batch" does not apply
    if run.config.batch_size >= T.small_batch:
        return None
    target = run.config.batch_size * 4
    evidence = [
        f"Batch size is {run.config.batch_size} (small-batch threshold: below {T.small_batch}).",
        f"Memory utilization is {m.memory_utilization * 100:.0f}%; current throughput {m.throughput_tokens_per_s:,.1f} tok/s.",
    ]
    model, hw = get_model(run.config.model_id), get_hardware(run.config.hardware_id)
    if model and hw:
        projected = est.memory_breakdown(model, run.config.precision, target,
                                         run.config.prompt_tokens, run.config.output_tokens).total_gb
        fraction = projected / hw.memory_gb
        if fraction > T.projected_memory_limit:
            return None
        evidence.append(
            f"Analytic estimate (not a measurement) at batch {target}: {projected:.1f} GB = {fraction * 100:.0f}% of "
            f"{hw.display_name} (fits under the {T.projected_memory_limit * 100:.0f}% safety limit)."
        )
    else:
        return None  # cannot verify that a larger batch fits without a known model/hardware profile
    return Recommendation(
        rule_id="unused-headroom",
        title="Hypothesis: a larger batch may fit in memory",
        severity=Severity.INFO,
        summary="Larger batches often trade per-batch latency for throughput. The memory estimate suggests batch "
                f"{target} may fit; whether it helps this workload has not been measured.",
        evidence=evidence,
        action=f"Benchmark batch size {target} with everything else unchanged.",
        how_to_verify="Save that run and open Optimize with this run as the baseline: it reports the measured throughput "
                      "gain (if any) and the latency cost, with uncertainty.",
        caveat="Only relevant if your workload can batch requests together. The memory figure is an analytic estimate.",
        basis=_basis(run),
        kind="hypothesis",
    )


def _rule_prefill_dominated(run: BenchmarkRun) -> Optional[Recommendation]:
    m = run.metrics
    if m is None or m.latency_mean_ms <= 0:
        return None
    share = m.ttft_mean_ms / m.latency_mean_ms
    if share < T.prefill_share:
        return None
    return Recommendation(
        rule_id="prefill-dominated",
        title="Prompt processing dominates latency",
        severity=Severity.INFO,
        summary="Time to first token makes up most of end-to-end latency in this run.",
        evidence=[
            f"TTFT {m.ttft_mean_ms:,.0f} ms is {share * 100:.0f}% of mean latency {m.latency_mean_ms:,.0f} ms "
            f"(threshold {T.prefill_share * 100:.0f}%).",
            f"Prompt {run.config.prompt_tokens:,} tokens vs {run.config.output_tokens:,} generated tokens, batch {run.config.batch_size}.",
        ],
        action="Ideas to test (none measured): a shorter prompt, a smaller batch, or hardware with more compute.",
        how_to_verify="Benchmark one of those changes alone and compare TTFT in Compare Runs or Optimize.",
        caveat="Prefix caching and chunked prefill need a serving engine that supports them (not available in this build).",
        basis=_basis(run),
        kind="observation",
    )


def _rule_tail_latency(run: BenchmarkRun) -> Optional[Recommendation]:
    m = run.metrics
    if m is None or m.latency_p50_ms <= 0 or m.iterations < T.min_samples_for_tail:
        return None
    ratio = m.latency_p99_ms / m.latency_p50_ms
    if ratio < T.tail_ratio_warning:
        return None
    severity = Severity.CRITICAL if ratio >= T.tail_ratio_critical else Severity.WARNING
    return Recommendation(
        rule_id="tail-latency",
        title="Heavy tail latency",
        severity=severity,
        summary="A few iterations are much slower than the median, which hurts p99 service-level targets.",
        evidence=[
            f"p99 {m.latency_p99_ms:,.0f} ms is {ratio:.2f}x the p50 {m.latency_p50_ms:,.0f} ms "
            f"(warning at {T.tail_ratio_warning:.1f}x).",
            f"Slowest iteration {m.latency_max_ms:,.0f} ms over {m.iterations} iterations.",
        ],
        action="Check for contention, thermal throttling or allocator stalls; use warmup iterations and more iterations.",
        how_to_verify=f"Re-run with at least {T.min_samples_for_tail} iterations and see whether the p99/p50 ratio persists. A tail that vanishes was noise.",
        caveat="With few iterations, p99 is close to the maximum and is noisy.",
        basis=_basis(run),
        kind="observation",
    )


def _rule_low_sample_count(run: BenchmarkRun) -> Optional[Recommendation]:
    m = run.metrics
    if m is None or m.iterations >= T.min_samples_for_tail:
        return None
    return Recommendation(
        rule_id="few-iterations",
        title="Too few iterations for reliable tail metrics",
        severity=Severity.INFO,
        summary="Percentiles estimated from a handful of samples are dominated by single outliers.",
        evidence=[f"Only {m.iterations} measured iterations: p99 needs at least {T.min_samples_for_tail} and p95 at least {T.min_samples_p95}."],
        action=f"Run at least {T.min_samples_for_tail} iterations before trusting p99 (at least {T.min_samples_p95} for p95).",
        how_to_verify="More iterations narrow the confidence intervals shown in Compare Runs and Optimize.",
        basis=_basis(run),
        kind="observation",
    )


def _rule_cold_start(run: BenchmarkRun) -> Optional[Recommendation]:
    if not run.samples or run.config.warmup_iterations > 0 or len(run.samples) < 3:
        return None
    lat = [s.latency_ms for s in run.samples]
    median = percentile(lat, 50)
    first = run.samples[0].latency_ms
    if median <= 0 or first / median < T.cold_start_ratio:
        return None
    return Recommendation(
        rule_id="cold-start",
        title="First iteration looks like a cold start",
        severity=Severity.WARNING,
        summary="The first measured iteration is much slower than the median and is inflating the tail and mean.",
        evidence=[
            f"Iteration 0 took {first:,.0f} ms, {first / median:.2f}x the median {median:,.0f} ms.",
            "No warmup iterations were configured.",
        ],
        action="Use at least 2-3 warmup iterations so one-time initialization is excluded.",
        how_to_verify="Re-run with warmup and compare the mean and tail latency against this run.",
        basis=_basis(run),
        kind="observation",
    )


def _rule_quantization_quality(run: BenchmarkRun) -> Optional[Recommendation]:
    if run.config.precision not in (Precision.INT8, Precision.INT4):
        return None
    return Recommendation(
        rule_id="quantization-quality",
        title="Quantized run: speed numbers say nothing about quality",
        severity=Severity.INFO,
        summary="This benchmark measures speed and memory, not output quality, so it cannot say whether quantization is acceptable.",
        evidence=[f"Precision is {run.config.precision.value}."],
        action="Evaluate accuracy or perplexity on your own data before adopting this configuration.",
        how_to_verify="Run your own quality evaluation at this precision and at the baseline precision.",
        basis=_basis(run),
        kind="caveat",
    )


def _rule_failed_run(run: BenchmarkRun) -> Optional[Recommendation]:
    if run.status == RunStatus.COMPLETED:
        return None
    if run.status == RunStatus.CANCELLED:
        return Recommendation(
            rule_id="run-cancelled", title="This run was cancelled", severity=Severity.INFO,
            summary=run.error or "The run was stopped on request.",
            evidence=[f"Status: {run.status.value}."], action="Run it again to completion if you need its numbers.",
            how_to_verify="A cancelled run has no metrics and is never compared; only a completed run can be analysed.",
            basis=_basis(run), kind="observation")
    if run.status == RunStatus.TIMED_OUT:
        return Recommendation(
            rule_id="run-timed-out", title="This run hit a time limit", severity=Severity.WARNING,
            summary=run.error or "The run was stopped by a time limit.",
            evidence=[f"Status: {run.status.value}.", f"Batch {run.config.batch_size}, {run.config.prompt_tokens} prompt + {run.config.output_tokens} output tokens."],
            action="Options to try: fewer iterations, a smaller batch, shorter outputs, or a higher limit (VOLTIX_MAX_RUN_SECONDS / VOLTIX_MAX_ITERATION_SECONDS).",
            how_to_verify="Re-run the adjusted configuration; a timed-out run has no metrics, so nothing can be compared until one completes.",
            basis=_basis(run), kind="observation")
    return Recommendation(
        rule_id="run-failed",
        title="This run failed",
        severity=Severity.CRITICAL,
        summary=run.error or "The run did not complete.",
        evidence=[f"Status: {run.status.value}.", f"Batch {run.config.batch_size}, precision {run.config.precision.value}."],
        action="Options to try: a smaller batch, shorter sequences, a lower precision, or hardware with more memory.",
        how_to_verify="Re-run the adjusted configuration; a failed run has no metrics, so nothing can be compared until one completes.",
        basis=_basis(run),
        kind="observation",
    )


_RULES: list[Rule] = [
    _rule_failed_run,
    _rule_memory_pressure,
    _rule_full_precision,
    _rule_cold_start,
    _rule_tail_latency,
    _rule_low_sample_count,
    _rule_prefill_dominated,
    _rule_headroom_small_batch,
    _rule_quantization_quality,
]


def recommend(run: BenchmarkRun, constraints=None) -> list[Recommendation]:
    """Apply all rules and return recommendations ordered by severity.

    ``constraints`` (a ``voltix.constraints.Constraints``) adds findings about the customer's own limits.
    """
    found = [r for rule in _RULES if (r := rule(run)) is not None]
    if constraints is not None:
        from .constraints import constraint_recommendations  # local import: constraints imports optimize

        found += constraint_recommendations(run, constraints)
    return sorted(found, key=lambda r: _SEVERITY_ORDER[r.severity])


def basis_disclaimer(basis: str) -> str:
    if basis == DataSource.SIMULATED.value:
        return "Based on SIMULATED data. Re-run on real hardware before acting on this advice."
    return "Based on measured data."
