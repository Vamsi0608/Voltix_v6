"""CSV, JSON and Markdown exports. Every export states its data source."""

from __future__ import annotations

import csv
import io
import json
from typing import Any, Iterable, Sequence

from . import __version__
from .catalog import hardware_label, model_label
from .metrics import METRIC_SPECS, describe_metric, metric_support, metric_value
from .recommendations import basis_disclaimer
from .schemas import BenchmarkRun, Recommendation

SIMULATED_BANNER = (
    "SIMULATED DATA: these numbers were produced by an analytic model. "
    "No model was executed and no hardware was measured."
)


def _csv_safe(value: Any) -> Any:
    """Neutralize spreadsheet formula injection in user-controlled text."""
    if isinstance(value, str) and value[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + value
    return value


_MD_SPECIAL = str.maketrans({c: "\\" + c for c in "\\`*_[]<>|#~"})


def _md(value: Any) -> str:
    """Make user-controlled text inert in Markdown: no tags, links, headings or table breaks."""
    return " ".join(str(value).split()).translate(_MD_SPECIAL)


def _md_block(text: str) -> list[str]:
    """User notes as a fenced block, so their formatting cannot affect the report."""
    fence = "~~~"
    while fence in text:
        fence += "~"
    return [fence + "text", text, fence]


def _to_csv(rows: Sequence[dict[str, Any]], fieldnames: Sequence[str]) -> str:
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=list(fieldnames), extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    for row in rows:
        writer.writerow({k: _csv_safe(row.get(k)) for k in fieldnames})
    return buf.getvalue()


def run_to_json(run: BenchmarkRun, recommendations: Iterable[Recommendation] = ()) -> str:
    payload = {
        "exported_by": f"VOLTIX Runtime {__version__}",
        "data_source": run.data_source.value,
        "data_source_notice": SIMULATED_BANNER if run.is_simulated else "Measured on real hardware.",
        "run": run.to_dict(),
        "metric_support": metric_support(run.metrics) if run.metrics else None,
        "recommendations": [r.to_dict() for r in recommendations],
    }
    return json.dumps(payload, indent=2)


SUMMARY_FIELDS = [
    "run_id", "name", "created_at", "data_source", "status", "backend", "model_id", "hardware_id",
    "precision", "batch_size", "prompt_tokens", "output_tokens", "iterations", "warmup_iterations", "seed",
] + [spec.key for spec in METRIC_SPECS] + ["error"]


def summary_row(run: BenchmarkRun) -> dict[str, Any]:
    c = run.config
    row: dict[str, Any] = {
        "run_id": run.run_id,
        "name": run.name,
        "created_at": run.created_at,
        "data_source": run.data_source.value,
        "status": run.status.value,
        "backend": run.backend,
        "model_id": c.model_id,
        "hardware_id": c.hardware_id,
        "precision": c.precision.value,
        "batch_size": c.batch_size,
        "prompt_tokens": c.prompt_tokens,
        "output_tokens": c.output_tokens,
        "iterations": c.iterations,
        "warmup_iterations": c.warmup_iterations,
        "seed": c.seed,
        "error": run.error,
    }
    for spec in METRIC_SPECS:
        row[spec.key] = metric_value(run.metrics, spec.key) if run.metrics else None
    return row


def runs_to_csv(runs: Sequence[BenchmarkRun]) -> str:
    """One summary row per run. Always includes a ``data_source`` column."""
    return _to_csv([summary_row(r) for r in runs], SUMMARY_FIELDS)


def samples_to_csv(run: BenchmarkRun) -> str:
    rows = [
        {
            "run_id": run.run_id,
            "data_source": run.data_source.value,
            "iteration": s.index,
            "ttft_ms": s.ttft_ms,
            "latency_ms": s.latency_ms,
            "batch_size": s.batch_size,
            "output_tokens_per_seq": s.output_tokens_per_seq,
        }
        for s in run.samples
    ]
    return _to_csv(rows, ["run_id", "data_source", "iteration", "ttft_ms", "latency_ms", "batch_size", "output_tokens_per_seq"])


def generic_rows_to_csv(rows: Sequence[dict[str, Any]]) -> str:
    if not rows:
        return ""
    fieldnames: list[str] = []
    for row in rows:
        for k in row:
            if k not in fieldnames:
                fieldnames.append(k)
    return _to_csv(rows, fieldnames)


def run_to_markdown(run: BenchmarkRun, recommendations: Sequence[Recommendation] = ()) -> str:
    c = run.config
    lines: list[str] = [f"# VOLTIX Runtime report: {_md(run.name)}", ""]
    if run.is_simulated:
        lines += [f"> **{SIMULATED_BANNER}**", ""]
    else:
        lines += ["> Data source: **measured** on the machine and software listed under Environment.", ""]

    lines += [
        "## Run",
        "",
        f"- Run ID: `{run.run_id}`",
        f"- Created (UTC): {run.created_at}",
        f"- Status: {run.status.value}",
        f"- Data source: **{run.data_source.value}**",
        f"- Backend: {run.backend}",
        f"- VOLTIX Runtime version: {run.voltix_version or 'unknown'}",
        "",
        "## Configuration",
        "",
        "| Setting | Value |",
        "|---|---|",
        f"| Model | {_md(model_label(c.model_id))} ({_md(c.model_id)}) |",
        f"| {'Hardware profile' if run.is_simulated else 'Device'} | {_md(hardware_label(c.hardware_id))}{' (simulated)' if run.is_simulated else ''} |",
        f"| Precision | {c.precision.value} |",
        f"| Batch size | {c.batch_size} |",
        f"| Prompt tokens | {c.prompt_tokens:,} |",
        f"| Output tokens | {c.output_tokens:,} |",
        f"| Iterations / warmup | {c.iterations} / {c.warmup_iterations} |",
        f"| Seed | {c.seed} |",
        "",
    ]

    if run.error:
        lines += ["## Error", "", _md(run.error), ""]

    if not run.is_simulated and run.environment:
        lines += ["## Environment", "", "| Item | Value |", "|---|---|"]
        for group in ("device", "software", "host", "model", "measurement"):
            for key, value in (run.environment.get(group) or {}).items():
                lines.append(f"| {group}.{key} | {_md(value)} |")
        lines.append("")

    if run.metrics:
        label = "Simulated metrics" if run.is_simulated else "Metrics"
        lines += [f"## {label}", "", "| Metric | Value |", "|---|---|"]
        for spec in METRIC_SPECS:
            lines.append(f"| {spec.label} | {describe_metric(run.metrics, spec.key)} |")
        lines.append("")

    if recommendations:
        lines += ["## Recommendations", "", f"_{basis_disclaimer(run.data_source.value)}_", ""]
        for i, rec in enumerate(recommendations, 1):
            lines += [f"### {i}. {rec.title} ({rec.severity.value}; {rec.kind})", "", rec.summary, "", "**Evidence**", ""]
            lines += [f"- {e}" for e in rec.evidence]
            lines += ["", f"**Action:** {rec.action}", "", f"**How to verify:** {rec.how_to_verify}", ""]
            if rec.caveat:
                lines += [f"**Caveat:** {rec.caveat}", ""]

    if run.notes:
        lines += ["## Notes", ""] + _md_block(run.notes) + [""]

    if run.is_simulated:
        lines += ["---", f"_{SIMULATED_BANNER}_", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Optimization study exports (Phase 3)
# ---------------------------------------------------------------------------

STUDY_NOTICE_MEASURED = ("Every figure is a difference between saved runs (or arithmetic on them). Nothing here is a "
                         "prediction. Intervals describe measurement noise on one machine only.")

STUDY_FIELDS = [
    "baseline_id", "baseline_name", "candidate_id", "candidate_name", "data_source", "comparability",
    "factors_changed", "classification", "confidence", "metric", "unit", "baseline_value", "candidate_value",
    "change_pct", "ci95_low_pct", "ci95_high_pct", "verdict", "note",
]


def study_to_rows(study) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for pa in study.analyses:
        for m in pa.metrics.values():
            rows.append({
                "baseline_id": pa.baseline_id, "baseline_name": pa.baseline_name,
                "candidate_id": pa.candidate_id, "candidate_name": pa.candidate_name,
                "data_source": pa.data_source, "comparability": pa.comparability.level.value,
                "factors_changed": "; ".join(pa.comparability.factors_changed),
                "classification": pa.classification, "confidence": pa.confidence.level.value,
                "metric": m.label, "unit": m.unit, "baseline_value": m.baseline, "candidate_value": m.candidate,
                "change_pct": m.change_pct, "ci95_low_pct": m.ci_low_pct, "ci95_high_pct": m.ci_high_pct,
                "verdict": m.verdict, "note": m.note,
            })
    return rows


def study_to_csv(study) -> str:
    return _to_csv(study_to_rows(study), STUDY_FIELDS)


def study_to_json(study) -> str:
    simulated = study.data_source == "simulated"
    payload = {
        "exported_by": f"VOLTIX Runtime {__version__}",
        "data_source": study.data_source,
        "data_source_notice": SIMULATED_BANNER if simulated else STUDY_NOTICE_MEASURED,
        "study": study.to_dict(),
    }
    return json.dumps(payload, indent=2)


def _fmt_ci(m) -> str:
    if m.change_pct is None:
        return "n/a"
    if m.has_ci and m.ci_low_pct is not None:
        return f"{m.change_pct:+.1f}% ({m.ci_low_pct:+.1f}% to {m.ci_high_pct:+.1f}%)"
    return f"{m.change_pct:+.1f}% (no interval)"


def study_to_markdown(study, names: dict[str, str]) -> str:
    simulated = study.data_source == "simulated"
    lines = [f"# VOLTIX Runtime optimization study: {_md(names.get(study.baseline_id, study.baseline_id))}", ""]
    lines += [f"> **{SIMULATED_BANNER}**" if simulated else f"> {STUDY_NOTICE_MEASURED}", ""]
    w = study.workload
    lines += ["## Workload", "", f"- Model: {_md(w['model_id'])}", f"- Prompt / output tokens: {w['prompt_tokens']} / {w['output_tokens']}",
              f"- Backend: {w['backend']}", f"- Runs in this study: {len(study.run_ids)}", ""]

    if study.findings:
        lines += ["## Findings", ""]
        for f in study.findings:
            lines += [f"### {_md(f.title)}", "", f"_Kind: {f.kind}. Confidence: {f.confidence.value}._", "", _md(f.statement), ""]
            lines += [f"- {_md(e)}" for e in f.evidence]
            lines += [f"- Trade-off: {_md(t)}" for t in f.tradeoffs]
            lines.append("")

    lines += ["## Comparisons against the baseline", "", "| Candidate | Comparability | Result | Confidence |", "|---|---|---|---|"]
    for pa in study.analyses:
        lines.append(f"| {_md(pa.candidate_name)} | {pa.comparability.level.value} | {_md(pa.headline)} | {pa.confidence.level.value} |")
    lines.append("")
    for pa in study.analyses:
        if not pa.metrics:
            continue
        lines += [f"### {_md(pa.candidate_name)} vs {_md(pa.baseline_name)}", "", "| Metric | Baseline | Candidate | Change (95% CI) | Verdict |", "|---|---|---|---|---|"]
        for m in pa.metrics.values():
            b = "n/a" if m.baseline is None else f"{m.baseline:,.2f}"
            c = "n/a" if m.candidate is None else f"{m.candidate:,.2f}"
            lines.append(f"| {m.label} ({m.unit}) | {b} | {c} | {_fmt_ci(m)} | {m.verdict} |")
        lines += ["", f"**Confidence: {pa.confidence.level.value}.** {pa.confidence.summary}", ""]
        lines += [f"- [{c.status}] {c.name}: {c.detail}" for c in pa.confidence.checks]
        lines.append("")

    lines += ["## Not yet measured", ""]
    cov = study.coverage
    lines += [f"- Precisions tried: {', '.join(cov.precisions)}; batch sizes tried: {', '.join(map(str, cov.batch_sizes))}; "
              f"devices: {', '.join(cov.devices)}."]
    lines += [f"- {e.suggestion}: {e.reason}" for e in study.next_experiments]
    if study.excluded:
        lines += ["", "## Runs left out (not a fair comparison)", ""]
        lines += [f"- {_md(n)}: {_md(r)}" for n, r in study.excluded]
    lines += ["", "## How to read this", ""] + [f"- {n}" for n in study.notes]
    lines.append("")
    return "\n".join(lines)
