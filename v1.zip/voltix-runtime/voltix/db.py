"""SQLite persistence for benchmark runs.

A new connection is opened per operation (cheap for SQLite and safe under
Streamlit's threaded script runs). All SQL is parameterized.
"""

from __future__ import annotations

import json
import os
import sqlite3
from contextlib import closing, contextmanager
from pathlib import Path
from typing import Iterator, Optional

from .schemas import BenchmarkRun
from .validation import sanitize_notes

SCHEMA_VERSION = 1
DEFAULT_DB_PATH = Path(__file__).resolve().parent.parent / "data" / "voltix.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id        TEXT PRIMARY KEY,
    created_at    TEXT NOT NULL,
    name          TEXT NOT NULL,
    status        TEXT NOT NULL,
    data_source   TEXT NOT NULL,
    backend       TEXT NOT NULL,
    model_id      TEXT NOT NULL,
    hardware_id   TEXT,
    precision     TEXT NOT NULL,
    config_json   TEXT NOT NULL,
    metrics_json  TEXT,
    samples_json  TEXT NOT NULL DEFAULT '[]',
    environment_json TEXT NOT NULL DEFAULT '{}',
    error         TEXT,
    notes         TEXT NOT NULL DEFAULT '',
    tags_json     TEXT NOT NULL DEFAULT '[]',
    voltix_version TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_runs_created ON runs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_runs_source ON runs(data_source);
"""


class StorageError(RuntimeError):
    """Raised when the database cannot be read or written."""


class StorageVersionError(StorageError):
    """The database was written by a newer version of VOLTIX."""


def _explain(exc: Exception) -> str:
    text = str(exc)
    if "not a database" in text:
        return "the file is not a SQLite database (it may be damaged or a different kind of file)"
    if "readonly" in text or "read-only" in text or isinstance(exc, PermissionError):
        return "no permission to write there"
    if "locked" in text:
        return "the database is locked by another process; close other VOLTIX windows and retry"
    if "disk" in text and "full" in text:
        return "the disk is full"
    return text


def resolve_db_path(path: str | os.PathLike[str] | None = None) -> Path:
    if path is not None:
        return Path(path)
    env = os.environ.get("VOLTIX_DB_PATH")
    return Path(env) if env else DEFAULT_DB_PATH


class RunRepository:
    def __init__(self, path: str | os.PathLike[str] | None = None) -> None:
        self.path = resolve_db_path(path)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self._connect() as conn:
                found = int(conn.execute("PRAGMA user_version").fetchone()[0])
                if found > SCHEMA_VERSION:
                    raise StorageVersionError(
                        f"The database at {self.path} was written by a newer version of VOLTIX (schema {found}; "
                        f"this version understands {SCHEMA_VERSION}). Upgrade VOLTIX, or point VOLTIX_DB_PATH at a different file. "
                        "The file was not modified.")
                conn.executescript(_SCHEMA)
                conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        except StorageVersionError:
            raise
        except StorageError as exc:
            raise StorageError(
                f"Could not open the database at {self.path}: {str(exc).removeprefix('Database error: ').rstrip('.')}. "
                "Check that the folder is writable and the file is a VOLTIX database, or set VOLTIX_DB_PATH to another location.") from exc
        except (sqlite3.Error, OSError) as exc:
            raise StorageError(
                f"Could not open the database at {self.path}: {_explain(exc)}. Check that the folder is writable and the file is a "
                "VOLTIX database, or set VOLTIX_DB_PATH to another location.") from exc

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            with closing(conn):
                with conn:  # transaction: commit on success, rollback on error
                    yield conn
        except sqlite3.Error as exc:
            raise StorageError(f"Database error: {_explain(exc)}.") from exc

    # ---- writes ---------------------------------------------------------

    def save(self, run: BenchmarkRun) -> None:
        """Insert or replace a run (saving the same run twice is harmless)."""
        d = run.to_dict()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO runs (
                    run_id, created_at, name, status, data_source, backend, model_id,
                    hardware_id, precision, config_json, metrics_json, samples_json,
                    environment_json, error, notes, tags_json, voltix_version
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    run.run_id,
                    run.created_at,
                    run.name,
                    run.status.value,
                    run.data_source.value,
                    run.backend,
                    run.config.model_id,
                    run.config.hardware_id,
                    run.config.precision.value,
                    json.dumps(d["config"]),
                    json.dumps(d["metrics"]) if d["metrics"] else None,
                    json.dumps(d["samples"]),
                    json.dumps(d["environment"]),
                    run.error,
                    run.notes,
                    json.dumps(run.tags),
                    run.voltix_version,
                ),
            )

    def update_notes(self, run_id: str, notes: str) -> bool:
        with self._connect() as conn:
            cur = conn.execute("UPDATE runs SET notes = ? WHERE run_id = ?", (sanitize_notes(notes), run_id))
            return cur.rowcount > 0

    def delete(self, run_id: str) -> bool:
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM runs WHERE run_id = ?", (run_id,))
            return cur.rowcount > 0

    def delete_by_tag(self, tag: str) -> int:
        ids = [r.run_id for r in self.list_with_problems(include_samples=False)[0] if tag in r.tags]
        deleted = 0
        for run_id in ids:
            deleted += int(self.delete(run_id))
        return deleted

    # ---- reads ----------------------------------------------------------

    def _row_to_run(self, row: sqlite3.Row, include_samples: bool = True) -> BenchmarkRun:
        try:
            data = {
                "run_id": row["run_id"],
                "name": row["name"],
                "created_at": row["created_at"],
                "status": row["status"],
                "data_source": row["data_source"],
                "backend": row["backend"],
                "config": json.loads(row["config_json"]),
                "metrics": json.loads(row["metrics_json"]) if row["metrics_json"] else None,
                "samples": json.loads(row["samples_json"]) if include_samples else [],
                "environment": json.loads(row["environment_json"] or "{}"),
                "error": row["error"],
                "notes": row["notes"],
                "tags": json.loads(row["tags_json"] or "[]"),
                "voltix_version": row["voltix_version"],
            }
            return BenchmarkRun.from_dict(data)
        except (ValueError, KeyError, TypeError) as exc:
            raise StorageError(f"Run {row['run_id']} is corrupted in the database: {exc}") from exc

    def get(self, run_id: str) -> Optional[BenchmarkRun]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM runs WHERE run_id = ?", (run_id,)).fetchone()
        return self._row_to_run(row) if row else None

    def exists(self, run_id: str) -> bool:
        with self._connect() as conn:
            return conn.execute("SELECT 1 FROM runs WHERE run_id = ?", (run_id,)).fetchone() is not None

    def list(self, **kwargs) -> list[BenchmarkRun]:
        """All matching runs, newest first. Raises StorageError if any row is unreadable
        (use ``list_with_problems`` when one damaged row must not hide the rest)."""
        runs, problems = self.list_with_problems(**kwargs)
        if problems:
            raise StorageError(problems[0][1])
        return runs

    def list_with_problems(
        self,
        *,
        data_source: Optional[str] = None,
        status: Optional[str] = None,
        model_id: Optional[str] = None,
        limit: Optional[int] = None,
        include_samples: bool = True,
    ) -> tuple[list[BenchmarkRun], list[tuple[str, str]]]:
        """Readable runs plus a (run_id, message) pair for every row that could not be read."""
        clauses: list[str] = []
        params: list[object] = []
        for column, value in (("data_source", data_source), ("status", status), ("model_id", model_id)):
            if value:
                clauses.append(f"{column} = ?")
                params.append(value)
        sql = "SELECT * FROM runs"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY created_at DESC, rowid DESC"
        if limit is not None:
            sql += " LIMIT ?"
            params.append(int(limit))
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        runs: list[BenchmarkRun] = []
        problems: list[tuple[str, str]] = []
        for row in rows:
            try:
                runs.append(self._row_to_run(row, include_samples))
            except StorageError as exc:
                problems.append((row["run_id"], str(exc)))
        return runs, problems

    def count(self) -> int:
        with self._connect() as conn:
            return int(conn.execute("SELECT COUNT(*) FROM runs").fetchone()[0])

    def size_bytes(self) -> int:
        try:
            return self.path.stat().st_size
        except OSError:
            return 0
