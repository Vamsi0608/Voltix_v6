"""Benchmark metric calculations (pure functions, no I/O)."""

from __future__ import annotations

import math
import statistics
from dataclasses import dataclass
from typing import Optional, Sequence

from .schemas import BenchmarkMetrics, RequestSample


def percentile(values: Sequence[float], q: float) -> float:
    """Linear-interpolated percentile (same convention as numpy's default).

    ``q`` is in [0, 100]. Raises ValueError for empty input or invalid q.
    """
    if not values:
        raise ValueError("percentile() requires at least one value")
    if not 0 <= q <= 100 or math.isnan(q):
        raise ValueError(f"q must be within [0, 100], got {q}")
    data = sorted(values)
    if len(data) == 1:
        return float(data[0])
    rank = (q / 100.0) * (len(data) - 1)
    lo = math.floor(rank)
    hi = math.ceil(rank)
    if lo == hi:
        return float(data[lo])
    frac = rank - lo
    return float(data[lo] + (data[hi] - data[lo]) * frac)


def compute_metrics(
    samples: Sequence[RequestSample],
    peak_memory_gb: Optional[float] = None,
    device_memory_gb: Optional[float] = None,
) -> BenchmarkMetrics:
    """Aggregate per-iteration samples into run-level metrics."""
    if not samples:
        raise ValueError("compute_metrics() requires at least one sample")
    for s in samples:
        if not (s.latency_ms > 0) or not math.isfinite(s.latency_ms):
            raise ValueError(f"sample {s.index} has non-positive or non-finite latency")
        if not (0 <= s.ttft_ms <= s.latency_ms):
            raise ValueError(f"sample {s.index}: ttft must be within [0, latency]")

    lat = [s.latency_ms for s in samples]
    ttft = [s.ttft_ms for s in samples]
    total_tokens = sum(s.total_output_tokens for s in samples)
    total_time_s = sum(lat) / 1000.0
    total_sequences = sum(s.batch_size for s in samples)

    tpots = [
        (s.latency_ms - s.ttft_ms) / (s.output_tokens_per_seq - 1)
        for s in samples
        if s.output_tokens_per_seq > 1
    ]
    tpot = statistics.fmean(tpots) if tpots else 0.0

    utilization = None
    if peak_memory_gb is not None and device_memory_gb:
        utilization = peak_memory_gb / device_memory_gb

    return BenchmarkMetrics(
        iterations=len(samples),
        latency_mean_ms=statistics.fmean(lat),
        latency_p50_ms=percentile(lat, 50),
        latency_p95_ms=percentile(lat, 95),
        latency_p99_ms=percentile(lat, 99),
        latency_min_ms=min(lat),
        latency_max_ms=max(lat),
        latency_std_ms=statistics.pstdev(lat) if len(lat) > 1 else 0.0,
        ttft_mean_ms=statistics.fmean(ttft),
        ttft_p50_ms=percentile(ttft, 50),
        ttft_p95_ms=percentile(ttft, 95),
        tpot_mean_ms=tpot,
        throughput_tokens_per_s=total_tokens / total_time_s,
        sequences_per_s=total_sequences / total_time_s,
        total_output_tokens=total_tokens,
        total_time_s=total_time_s,
        peak_memory_gb=peak_memory_gb,
        memory_utilization=utilization,
    )


@dataclass(frozen=True)
class MetricSpec:
    key: str
    label: str
    unit: str
    higher_is_better: bool
    decimals: int = 1


METRIC_SPECS: list[MetricSpec] = [
    MetricSpec("throughput_tokens_per_s", "Throughput", "tok/s", True, 1),
    MetricSpec("sequences_per_s", "Sequences per second", "seq/s", True, 2),
    MetricSpec("latency_mean_ms", "Latency (mean)", "ms", False, 1),
    MetricSpec("latency_p50_ms", "Latency p50", "ms", False, 1),
    MetricSpec("latency_p95_ms", "Latency p95", "ms", False, 1),
    MetricSpec("latency_p99_ms", "Latency p99", "ms", False, 1),
    MetricSpec("ttft_mean_ms", "TTFT (mean)", "ms", False, 1),
    MetricSpec("ttft_p95_ms", "TTFT p95", "ms", False, 1),
    MetricSpec("tpot_mean_ms", "Time per output token", "ms", False, 2),
    MetricSpec("peak_memory_gb", "Peak memory", "GB", False, 2),
    MetricSpec("memory_utilization", "Memory utilization", "%", False, 1),
]

METRIC_BY_KEY: dict[str, MetricSpec] = {m.key: m for m in METRIC_SPECS}


# Minimum number of measured iterations before a statistic is reported. Below it the value is still stored (it is
# arithmetic on what was measured) but every display, comparison and export treats it as NOT SUPPORTED, because a
# tail percentile or a spread from a handful of points mostly reflects the sample maximum or luck.
MIN_OBSERVATIONS: dict[str, int] = {
    "latency_p95_ms": 20,
    "ttft_p95_ms": 20,
    "latency_p99_ms": 100,
    "latency_std_ms": 5,
}


def unsupported_reason(metrics: BenchmarkMetrics, key: str) -> Optional[str]:
    """None when ``key`` is supported by the number of observations, else a human-readable reason."""
    need = MIN_OBSERVATIONS.get(key)
    n = getattr(metrics, "iterations", 0) or 0
    if need is not None and n < need:
        return f"needs at least {need} measured iterations; this run has {n}"
    return None


def metric_value(metrics: BenchmarkMetrics, key: str) -> Optional[float]:
    """The value of ``key``, or None when missing or not supported by the number of observations."""
    if unsupported_reason(metrics, key):
        return None
    v = getattr(metrics, key, None)
    if v is None:
        return None
    return float(v)


def describe_metric(metrics: BenchmarkMetrics, key: str) -> str:
    """Formatted value, or 'n/a (reason)' so a reader can see WHY a number is absent."""
    reason = unsupported_reason(metrics, key)
    if reason:
        return f"n/a ({reason})"
    return format_metric(key, metric_value(metrics, key))


def metric_support(metrics: BenchmarkMetrics) -> dict[str, dict]:
    """Per-statistic support map recorded in exports."""
    return {k: {"supported": unsupported_reason(metrics, k) is None, "needs_iterations": need, "has_iterations": metrics.iterations}
            for k, need in MIN_OBSERVATIONS.items()}


def format_metric(key: str, value: Optional[float]) -> str:
    """Human-readable value including unit. Utilization is shown as a percent."""
    if value is None:
        return "n/a"
    spec = METRIC_BY_KEY.get(key)
    if spec is None:
        return f"{value:g}"
    if key == "memory_utilization":
        return f"{value * 100:.{spec.decimals}f}%"
    return f"{value:,.{spec.decimals}f} {spec.unit}"


def pct_change(baseline: Optional[float], value: Optional[float]) -> Optional[float]:
    """Percent change of ``value`` relative to ``baseline`` (None if undefined)."""
    if baseline is None or value is None or baseline == 0:
        return None
    return (value - baseline) / abs(baseline) * 100.0
