"""Import a run exported by VOLTIX (JSON) into the local history, with integrity checks.

The main use is moving a REAL measurement from the machine that has the GPU (for example a cloud
notebook) to the machine that runs the VOLTIX app. An imported run keeps the data source it was
exported with: measured stays measured and simulated stays simulated. Nothing is re-labelled.

What the checks can and cannot do. They catch damaged, truncated, contradictory or out-of-range files and
metrics that do not match the stored per-iteration samples. They cannot prove a file came from a real GPU
(anyone who can edit a JSON file can write self-consistent numbers) and they cannot detect samples that are
self-consistently scaled to the wrong unit; an implausibly fast result only raises a warning.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from .catalog import HARDWARE, MODELS
from .db import RunRepository
from .metrics import compute_metrics
from .schemas import BenchmarkRun, DataSource, Precision, RunStatus
from .validation import MAX_NAME_LEN, config_limit_errors, sanitize_name, sanitize_notes

MAX_IMPORT_BYTES = 50 * 1024 * 1024
MAX_SAMPLES = 100_000
MAX_TAGS, MAX_TAG_LEN = 20, 40
IMPORT_TAG = "imported"
_REL_TOL = 1e-6
_RUN_ID = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_DEVICE = re.compile(r"^(auto|cpu|cuda(:\d+)?)$")
_CONTROL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
MEASURABLE_PRECISIONS = (Precision.FP32, Precision.FP16, Precision.BF16)
_SAMPLE_INTS = ("index", "batch_size", "output_tokens_per_seq")
_SAMPLE_FLOATS = ("ttft_ms", "latency_ms")
_CONFIG_INTS = ("batch_size", "prompt_tokens", "output_tokens", "iterations", "warmup_iterations", "seed")


class ImportRejected(ValueError):
    """The file cannot be imported; the message says why in plain language."""


@dataclass
class ImportResult:
    run: BenchmarkRun
    warnings: list[str] = field(default_factory=list)


def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _is_num(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _close(a: Any, b: Any) -> bool:
    if a is None or b is None:
        return a is b
    return math.isclose(float(a), float(b), rel_tol=_REL_TOL, abs_tol=1e-9)


def _need(cond: bool, message: str) -> None:
    if not cond:
        raise ImportRejected(message)


def _parse_time(text: Any) -> datetime:
    _need(isinstance(text, str), "'created_at' must be a text timestamp.")
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        raise ImportRejected(f"'created_at' is not a valid ISO-8601 timestamp: {text[:40]!r}.") from None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _check_structure(d: dict[str, Any]) -> None:
    """Types and shapes of the raw JSON, before any object is built from it."""
    rid = d.get("run_id")
    _need(isinstance(rid, str) and bool(_RUN_ID.match(rid)), "'run_id' must be 1-64 letters, digits, '_' or '-'.")
    _need(isinstance(d.get("name"), str), "'name' must be text.")
    when = _parse_time(d.get("created_at"))
    _need(when <= datetime.now(timezone.utc) + timedelta(days=1), "'created_at' is in the future; the file's clock or contents are wrong.")
    tags = d.get("tags", [])
    _need(isinstance(tags, list) and len(tags) <= MAX_TAGS and all(isinstance(t, str) and len(t) <= MAX_TAG_LEN for t in tags),
          f"'tags' must be a list of at most {MAX_TAGS} short texts.")
    _need(isinstance(d.get("environment", {}), dict), "'environment' must be an object.")
    _need(d.get("error") is None or isinstance(d.get("error"), str), "'error' must be text or null.")
    cfg = d.get("config")
    _need(isinstance(cfg, dict), "'config' must be an object.")
    for k in _CONFIG_INTS:
        _need(_is_int(cfg.get(k)), f"config.{k} must be a whole number (got {cfg.get(k)!r}).")
    _need(isinstance(cfg.get("model_id"), str), "config.model_id must be text.")
    samples = d.get("samples", [])
    _need(isinstance(samples, list), "'samples' must be a list.")
    _need(len(samples) <= MAX_SAMPLES, f"More than {MAX_SAMPLES:,} samples.")
    for i, s in enumerate(samples):
        _need(isinstance(s, dict), f"sample {i} must be an object.")
        for k in _SAMPLE_INTS:
            _need(_is_int(s.get(k)), f"sample {i}: '{k}' is missing or not a whole number.")
        for k in _SAMPLE_FLOATS:
            _need(_is_num(s.get(k)), f"sample {i}: '{k}' is missing or not a number (got {s.get(k)!r}).")
    m = d.get("metrics")
    _need(m is None or isinstance(m, dict), "'metrics' must be an object or null.")
    for k, v in (m or {}).items():
        _need(v is None or _is_num(v), f"metrics.{k} must be a number or null (got {v!r}).")


def _check_semantics(run: BenchmarkRun) -> list[str]:
    """Consistency and range checks on the built run. Returns non-fatal warnings; raises for fatal problems."""
    warnings: list[str] = []
    cfg = run.config
    problems = config_limit_errors(cfg)
    _need(not problems, "Settings out of range: " + " ".join(problems))
    _need(0 < len(cfg.model_id) <= 200 and not _CONTROL.search(cfg.model_id), "config.model_id is empty, too long or contains control characters.")
    _need(len(run.name) <= 500, f"The run name is longer than {MAX_NAME_LEN} characters by a wide margin; the file looks wrong.")
    _need(run.backend in ("simulated", "transformers"), f"Unknown backend '{run.backend}'.")
    _need((run.data_source == DataSource.SIMULATED) == (run.backend == "simulated"),
          f"Inconsistent file: data source is '{run.data_source.value}' but backend is '{run.backend}'.")
    env = run.environment

    if run.backend == "simulated":
        _need(cfg.model_id in MODELS, f"Unknown model profile '{cfg.model_id}' for a simulated run.")
        _need(cfg.hardware_id in HARDWARE, f"Unknown hardware profile '{cfg.hardware_id}' for a simulated run.")
        _need(env.get("simulated", True) is True, "A simulated run's environment says it is not simulated.")
    else:
        _need(isinstance(cfg.hardware_id, str) and bool(_DEVICE.match(cfg.hardware_id)), f"Unknown device '{cfg.hardware_id}'.")
        _need(cfg.precision in MEASURABLE_PRECISIONS, f"A measured run cannot have precision {cfg.precision.value}; only fp32, fp16 and bf16 are supported.")
        _need(env.get("simulated") is not True, "Inconsistent file: a measured run's environment says it is simulated.")

    if run.status != RunStatus.COMPLETED:
        word = run.status.value.replace("_", " ")
        _need(bool((run.error or "").strip()), f"A {word} run must say why ('error' is empty).")
        _need(not run.samples and run.metrics is None, f"A {word} run must not contain samples or metrics.")
        return warnings

    # ---- completed runs -------------------------------------------------------------------
    _need(not (run.error or "").strip(), "A completed run must not carry an error message.")
    _need(bool(run.samples) and run.metrics is not None, "A completed run must include its per-iteration samples and metrics.")
    _need(len(run.samples) == cfg.iterations, f"The file has {len(run.samples)} samples but the run says {cfg.iterations} iterations.")
    _need([s.index for s in run.samples] == list(range(len(run.samples))), "Sample indexes must run 0, 1, 2, ... without gaps or repeats.")
    _need(all(s.batch_size == cfg.batch_size for s in run.samples), "A sample's batch size differs from the run's batch size.")
    _need(all(s.output_tokens_per_seq == cfg.output_tokens for s in run.samples),
          "A sample's output-token count differs from the run's output tokens, so throughput would be wrong.")
    if run.data_source == DataSource.MEASURED:
        _need(isinstance(env, dict) and env.get("device_kind") in ("cpu", "cuda"),
              "A measured run must include its environment record (with device_kind 'cpu' or 'cuda').")
        if cfg.hardware_id != "auto":
            _need((cfg.hardware_id.startswith("cuda")) == (env["device_kind"] == "cuda"),
                  f"The device setting '{cfg.hardware_id}' contradicts the recorded device kind '{env['device_kind']}'.")
        total = ((env.get("device") or {}).get("total_memory_gb"))
    else:
        total = None
    peak = run.metrics.peak_memory_gb
    if peak is not None:
        _need(math.isfinite(peak) and peak >= 0, f"Peak memory {peak} GB is not a valid amount.")
        if _is_num(total) and total > 0:
            _need(peak <= total * 1.1, f"Peak memory ({peak:.2f} GB) exceeds the device's total memory ({total:.2f} GB); the value is wrong.")
    try:
        again = compute_metrics(run.samples, peak_memory_gb=peak)
    except ValueError as exc:
        raise ImportRejected(f"The samples are invalid: {exc}") from exc
    for name, value in again.to_dict().items():
        if name == "memory_utilization":
            continue  # depends on the device memory total, which is recorded separately
        if not _close(value, getattr(run.metrics, name)):
            raise ImportRejected(f"The stored metric '{name}' ({getattr(run.metrics, name)}) does not match the value "
                                 f"recomputed from the samples ({value}). The file was edited or damaged.")
    if run.data_source == DataSource.MEASURED:
        if again.latency_mean_ms < 1.0:
            warnings.append(f"Mean latency is {again.latency_mean_ms:.3f} ms, faster than a text-generation call normally is. "
                            "Check that the values are in milliseconds.")
        if again.throughput_tokens_per_s > 1e6:
            warnings.append(f"Throughput of {again.throughput_tokens_per_s:,.0f} tokens/s is implausibly high; check the units.")
    return warnings


def parse_run_with_warnings(text: str | bytes) -> ImportResult:
    """Parse and validate one exported run. Raises ImportRejected; never touches the database."""
    raw = text.encode("utf-8") if isinstance(text, str) else text
    _need(len(raw) <= MAX_IMPORT_BYTES, f"The file is larger than {MAX_IMPORT_BYTES // 1_000_000} MB.")
    try:
        payload = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError) as exc:
        raise ImportRejected(f"This is not a valid JSON file ({exc}).") from exc
    data = payload.get("run", payload) if isinstance(payload, dict) else None
    _need(isinstance(data, dict) and "run_id" in data and "config" in data,
          "This does not look like a VOLTIX run export (no 'run' with 'run_id' and 'config').")
    _check_structure(data)
    try:
        run = BenchmarkRun.from_dict(data)
    except (KeyError, TypeError, ValueError) as exc:
        raise ImportRejected(f"The run data is incomplete or malformed: {type(exc).__name__}: {exc}") from exc
    warnings = _check_semantics(run)
    run.name = sanitize_name(run.name)
    run.notes = sanitize_notes(run.notes)
    run.tags = sorted({*run.tags, IMPORT_TAG})
    return ImportResult(run, warnings)


def parse_run(text: str | bytes) -> BenchmarkRun:
    return parse_run_with_warnings(text).run


def import_run_with_warnings(repo: RunRepository, text: str | bytes) -> ImportResult:
    """Validate and save one exported run. An existing run with the same id is never overwritten."""
    result = parse_run_with_warnings(text)
    if repo.exists(result.run.run_id):
        raise ImportRejected(f"A run with id {result.run.run_id} is already in your history; nothing was changed.")
    repo.save(result.run)
    return result


def import_run(repo: RunRepository, text: str | bytes) -> BenchmarkRun:
    return import_run_with_warnings(repo, text).run
