"""Run-to-run comparison logic (shared by the UI and exports)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Sequence

from .catalog import hardware_label, model_label
from .metrics import METRIC_SPECS, metric_value, pct_change
from .schemas import BenchmarkRun, RunStatus


class ComparisonError(ValueError):
    pass


CONFIG_FIELDS = [
    ("model_id", "Model"),
    ("hardware_id", "Hardware"),
    ("precision", "Precision"),
    ("batch_size", "Batch size"),
    ("prompt_tokens", "Prompt tokens"),
    ("output_tokens", "Output tokens"),
    ("iterations", "Iterations"),
    ("warmup_iterations", "Warmup"),
    ("backend", "Backend"),
]


@dataclass
class MetricComparison:
    key: str
    label: str
    unit: str
    higher_is_better: bool
    values: dict[str, Optional[float]]  # run_id -> value
    deltas_pct: dict[str, Optional[float]]  # run_id -> % change vs baseline (None for baseline)
    verdicts: dict[str, Optional[str]]  # run_id -> "better" | "worse" | "same" | None


def _verdict(delta: Optional[float], higher_is_better: bool, tolerance_pct: float = 0.5) -> Optional[str]:
    if delta is None:
        return None
    if abs(delta) < tolerance_pct:
        return "same"
    improved = delta > 0 if higher_is_better else delta < 0
    return "better" if improved else "worse"


def build_comparison(runs: Sequence[BenchmarkRun], baseline_id: Optional[str] = None) -> list[MetricComparison]:
    """Compare completed runs metric by metric against a baseline run."""
    if len(runs) < 2:
        raise ComparisonError("Select at least two runs to compare.")
    ids = [r.run_id for r in runs]
    if len(set(ids)) != len(ids):
        raise ComparisonError("The same run was selected more than once.")
    bad = [r.name for r in runs if r.status != RunStatus.COMPLETED or r.metrics is None]
    if bad:
        raise ComparisonError("Failed runs have no metrics and cannot be compared: " + ", ".join(bad))
    baseline_id = baseline_id or ids[0]
    if baseline_id not in ids:
        raise ComparisonError("Baseline run is not among the selected runs.")
    baseline = next(r for r in runs if r.run_id == baseline_id)

    out: list[MetricComparison] = []
    for spec in METRIC_SPECS:
        base_val = metric_value(baseline.metrics, spec.key)  # type: ignore[arg-type]
        values: dict[str, Optional[float]] = {}
        deltas: dict[str, Optional[float]] = {}
        verdicts: dict[str, Optional[str]] = {}
        for r in runs:
            v = metric_value(r.metrics, spec.key)  # type: ignore[arg-type]
            values[r.run_id] = v
            if r.run_id == baseline_id:
                deltas[r.run_id] = None
                verdicts[r.run_id] = None
            else:
                d = pct_change(base_val, v)
                deltas[r.run_id] = d
                verdicts[r.run_id] = _verdict(d, spec.higher_is_better)
        out.append(MetricComparison(spec.key, spec.label, spec.unit, spec.higher_is_better, values, deltas, verdicts))
    return out


def comparison_warnings(runs: Sequence[BenchmarkRun]) -> list[str]:
    """Flag comparisons that are not like-for-like or mix data sources."""
    warnings: list[str] = []
    sources = {r.data_source.value for r in runs}
    if len(sources) > 1:
        warnings.append("These runs mix simulated and measured data. Do not draw conclusions across them.")
    elif "simulated" in sources:
        warnings.append("All selected runs are simulated. Differences reflect the analytic model, not real hardware.")
    for key, label in (("model_id", "models"), ("hardware_id", "hardware"), ("prompt_tokens", "prompt lengths"),
                       ("output_tokens", "output lengths")):
        if len({getattr(r.config, key) for r in runs}) > 1:
            warnings.append(f"Runs use different {label}; differences are not attributable to a single change.")
    names = {r.environment.get("device", {}).get("name") for r in runs if not r.is_simulated and r.environment.get("device")}
    if len(names) > 1:
        warnings.append("Measured runs were taken on different devices: " + "; ".join(sorted(str(n) for n in names)) + ".")
    return warnings


def config_diff_rows(runs: Sequence[BenchmarkRun]) -> list[dict[str, Any]]:
    """Rows of config fields; ``differs`` marks fields that are not identical across runs."""
    rows: list[dict[str, Any]] = []
    for key, label in CONFIG_FIELDS:
        raw = []
        for r in runs:
            v = getattr(r.config, key)
            v = getattr(v, "value", v)
            raw.append(v)
        row: dict[str, Any] = {"field": label, "differs": len(set(raw)) > 1}
        for r, v in zip(runs, raw):
            if key == "model_id":
                v = model_label(str(v))
            elif key == "hardware_id":
                v = hardware_label(v)
            row[r.run_id] = v
        rows.append(row)
    return rows


def comparison_rows(runs: Sequence[BenchmarkRun], comparison: Sequence[MetricComparison]) -> list[dict[str, Any]]:
    """Flat rows for CSV export: one row per metric per run.

    ``point_estimate_verdict`` compares single numbers and ignores measurement noise. For verdicts that
    account for uncertainty use ``voltix.optimize.analyze_pair`` (shown on Compare Runs and Optimize).
    """
    rows: list[dict[str, Any]] = []
    for mc in comparison:
        for r in runs:
            rows.append(
                {
                    "metric_key": mc.key,
                    "metric": mc.label,
                    "unit": mc.unit,
                    "run_id": r.run_id,
                    "run_name": r.name,
                    "data_source": r.data_source.value,
                    "value": mc.values[r.run_id],
                    "delta_vs_baseline_pct": mc.deltas_pct[r.run_id],
                    "point_estimate_verdict": mc.verdicts[r.run_id],
                }
            )
    return rows
