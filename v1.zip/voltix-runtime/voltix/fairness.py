"""Is this a fair comparison, and what can it support?

Two runs can only be compared meaningfully if they do the same work. This module inspects
the SETUP of two runs (never their results) and classifies the pair:

  controlled        exactly one setting differs (precision, batch size or hardware), so a
                    measured difference can reasonably be credited to it.
  replicate         identical setup: the pair measures run-to-run noise, not an effect.
  multi_factor      several settings differ; numbers are reported but no single cause can be named.
  not_like_for_like the runs do different work or come from different kinds of data (different
                    model, prompt/output length, backend, or simulated vs measured). No metric is
                    compared.

Issues refine the picture. A ``blocker`` makes the pair not like-for-like; a ``warning`` weakens
the conclusion (e.g. different software versions); a ``note`` is context the reader needs.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from .catalog import hardware_label
from .schemas import BenchmarkRun


class Comparability(str, Enum):
    CONTROLLED = "controlled"
    REPLICATE = "replicate"
    MULTI_FACTOR = "multi_factor"
    NOT_LIKE_FOR_LIKE = "not_like_for_like"


# Levels for which metrics are still computed and shown.
REPORTABLE = frozenset({Comparability.CONTROLLED, Comparability.REPLICATE, Comparability.MULTI_FACTOR})

LEVEL_LABEL = {
    Comparability.CONTROLLED: "Controlled comparison",
    Comparability.REPLICATE: "Replicate runs (same setup)",
    Comparability.MULTI_FACTOR: "Several settings changed",
    Comparability.NOT_LIKE_FOR_LIKE: "Not like-for-like",
}

# Issue codes other modules rely on.
ENV_CODES = ("env-differs", "model-revision")


@dataclass(frozen=True)
class Issue:
    code: str
    severity: str  # blocker | warning | note
    message: str

    def to_dict(self) -> dict[str, str]:
        return {"code": self.code, "severity": self.severity, "message": self.message}


@dataclass
class ComparabilityReport:
    level: Comparability
    factors_changed: list[str] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)

    @property
    def reportable(self) -> bool:
        return self.level in REPORTABLE

    @property
    def blockers(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == "blocker"]

    def to_dict(self) -> dict[str, Any]:
        return {"level": self.level.value, "reportable": self.reportable, "factors_changed": list(self.factors_changed),
                "issues": [i.to_dict() for i in self.issues], "summary": explain_level(self)}


def device_identity(run: BenchmarkRun) -> str:
    """Name of the hardware the numbers came from (also the key users attach a price to)."""
    if run.is_simulated:
        return f"simulated {hardware_label(run.config.hardware_id)}"
    dev = (run.environment or {}).get("device") or {}
    return str(dev.get("name") or run.config.hardware_id or "unknown device")


def _env(run: BenchmarkRun, *path: str) -> Any:
    node: Any = run.environment or {}
    for key in path:
        node = node.get(key) if isinstance(node, dict) else None
    return node


def _env_differences(base: BenchmarkRun, cand: BenchmarkRun) -> list[str]:
    diffs = []
    for label, path in (("torch", ("software", "torch")), ("transformers", ("software", "transformers"))):
        b, c = _env(base, *path), _env(cand, *path)
        if b != c:
            diffs.append(f"{label} {b} vs {c}")
    if _env(base, "device_kind") == "cpu" and _env(cand, "device_kind") == "cpu":
        b, c = _env(base, "host", "torch_threads"), _env(cand, "host", "torch_threads")
        if b != c:
            diffs.append(f"CPU threads {b} vs {c}")
    return diffs


def assess_comparability(base: BenchmarkRun, cand: BenchmarkRun) -> ComparabilityReport:
    """Classify how comparable two runs are, from their setup alone."""
    issues: list[Issue] = []

    def block(code: str, msg: str) -> None:
        issues.append(Issue(code, "blocker", msg))

    for r in (base, cand):
        if r.metrics is None:
            block("no-metrics", f"'{r.name}' has no metrics (it failed or did not finish).")
    if base.data_source != cand.data_source:
        block("data-source", "One run is simulated and the other measured; their numbers are not comparable.")
    if base.backend != cand.backend:
        block("backend", f"Different backends ({base.backend} vs {cand.backend}).")
    if base.config.model_id != cand.config.model_id:
        block("model", "Different models: choosing a model is not an optimization of the same model.")
    if (base.config.prompt_tokens, base.config.output_tokens) != (cand.config.prompt_tokens, cand.config.output_tokens):
        block("workload", "Different prompt or output lengths: the runs do different amounts of work per request.")
    if any(i.severity == "blocker" for i in issues):
        return ComparabilityReport(Comparability.NOT_LIKE_FOR_LIKE, [], issues)

    factors: list[str] = []
    if base.config.precision != cand.config.precision:
        factors.append(f"precision {base.config.precision.value} → {cand.config.precision.value}")
        issues.append(Issue("precision-quality", "note",
                            "Precision changes the model's arithmetic. This benchmark measures speed and memory, "
                            "not output quality."))
    if base.config.batch_size != cand.config.batch_size:
        factors.append(f"batch size {base.config.batch_size} → {cand.config.batch_size}")
        issues.append(Issue("batch-semantics", "note",
                            "Batch size changes how much work one iteration does: per-iteration latency is not "
                            "per-request latency, so throughput and latency answer different questions here."))
    if device_identity(base) != device_identity(cand):
        factors.append(f"hardware {device_identity(base)} → {device_identity(cand)}")

    if base.is_simulated:
        issues.append(Issue("simulated", "note", "Simulated data: differences come from an analytic model, not hardware."))
    else:
        diffs = _env_differences(base, cand)
        if diffs:
            issues.append(Issue("env-differs", "warning",
                                "Software environment differs between the runs (" + "; ".join(diffs) + "), "
                                "so the difference may not come from the setting you changed."))
        bc, cc = _env(base, "model", "commit_hash"), _env(cand, "model", "commit_hash")
        bp, cp = _env(base, "model", "num_parameters"), _env(cand, "model", "num_parameters")
        if (bc and cc and bc != cc) or (bp and cp and bp != cp):
            issues.append(Issue("model-revision", "warning", "The model files differ between the runs (revision or size)."))

    level = (Comparability.REPLICATE if not factors else
             Comparability.CONTROLLED if len(factors) == 1 else Comparability.MULTI_FACTOR)
    return ComparabilityReport(level, factors, issues)


def environment_matches(report: ComparabilityReport) -> bool:
    """True when no software or model-revision difference was found."""
    return not any(i.code in ENV_CODES for i in report.issues)


def explain_level(report: ComparabilityReport) -> str:
    """One plain-language sentence describing what the comparison can and cannot support."""
    if report.level == Comparability.NOT_LIKE_FOR_LIKE:
        return "These runs cannot be compared: " + " ".join(i.message for i in report.blockers)
    if report.level == Comparability.REPLICATE:
        return "Identical setup: any difference between these runs is run-to-run noise, not an effect."
    if report.level == Comparability.CONTROLLED:
        text = (f"Only one setting differs ({report.factors_changed[0]}), so a measured difference can "
                "reasonably be credited to it.")
        if not environment_matches(report):
            text += " The software environment also differs, which weakens that."
        return text
    return ("Several settings differ (" + "; ".join(report.factors_changed) + "). Numbers are shown, but the "
            "effects of the individual settings cannot be separated.")
