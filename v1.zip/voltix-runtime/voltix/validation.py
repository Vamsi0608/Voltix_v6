"""Input validation for benchmark configurations and user-provided text."""

from __future__ import annotations

import os
import re

from .security import restricted_config_errors

from .catalog import HARDWARE, MODELS
from .schemas import BenchmarkConfig, Precision

LIMITS = {
    "batch_size": (1, 256),
    "prompt_tokens": (1, 32768),
    "output_tokens": (1, 4096),
    "iterations": (1, 1000),
    "warmup_iterations": (0, 50),
    "seed": (0, 2**31 - 1),
}

MAX_NAME_LEN = 80
MAX_NOTES_LEN = 5000

_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
_HF_REPO_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-]{0,95}(/[A-Za-z0-9][A-Za-z0-9_.\-]{0,95})?$")
_DEVICE = re.compile(r"^(auto|cpu|cuda(:\d+)?)$")
TRANSFORMERS_PRECISIONS = (Precision.FP32, Precision.FP16, Precision.BF16)


class ValidationError(ValueError):
    """Raised when user input is invalid. ``errors`` holds every problem found."""

    def __init__(self, errors: list[str]):
        self.errors = list(errors)
        super().__init__("; ".join(self.errors))


def config_limit_errors(config: BenchmarkConfig) -> list[str]:
    """Range checks on the numeric settings only (no filesystem or device checks), usable for imported runs too."""
    errors: list[str] = []
    for field_name, (lo, hi) in LIMITS.items():
        value = getattr(config, field_name)
        if isinstance(value, bool) or not isinstance(value, int):
            errors.append(f"{field_name.replace('_', ' ').capitalize()} must be a whole number.")
        elif not lo <= value <= hi:
            errors.append(
                f"{field_name.replace('_', ' ').capitalize()} must be between {lo:,} and {hi:,} (got {value:,})."
            )
    return errors


def validate_config(config: BenchmarkConfig) -> list[str]:
    """Return a list of human-readable problems (empty list means valid)."""
    errors: list[str] = []

    if not isinstance(config.precision, Precision):
        errors.append("Precision is not a recognised value.")

    errors.extend(config_limit_errors(config))
    errors.extend(revision_errors(config))

    if not config.model_id or not str(config.model_id).strip():
        errors.append("Model must be selected.")
    elif len(config.model_id) > 200:
        errors.append("Model identifier is too long (max 200 characters).")

    if not config.backend:
        errors.append("Backend must be selected.")

    if config.backend == "transformers":
        errors.extend(_validate_transformers(config))
        errors.extend(restricted_config_errors(config.model_id, bool(config.allow_download)))

    if config.backend == "simulated":
        if config.model_id and config.model_id not in MODELS:
            errors.append(f"Unknown model profile '{config.model_id}' for the simulated backend.")
        if not config.hardware_id:
            errors.append("The simulated backend needs a hardware profile.")
        elif config.hardware_id not in HARDWARE:
            errors.append(f"Unknown hardware profile '{config.hardware_id}'.")

    # Context length check (only when the model is known and the ints are sane).
    model = MODELS.get(config.model_id)
    if model and isinstance(config.prompt_tokens, int) and isinstance(config.output_tokens, int):
        total = config.prompt_tokens + config.output_tokens
        if total > model.max_context:
            errors.append(
                f"Prompt + output tokens ({total:,}) exceed {model.display_name}'s context window "
                f"({model.max_context:,})."
            )

    return errors


def _validate_transformers(config: BenchmarkConfig) -> list[str]:
    errors: list[str] = []
    model = (config.model_id or "").strip()
    if model and model != config.model_id:
        errors.append("Model identifier has leading or trailing whitespace.")
    elif model:
        if _CONTROL_CHARS.search(model):
            errors.append("Model identifier contains control characters.")
        elif os.path.isdir(model):
            pass  # local model folder
        elif "://" in model or model.startswith(("/", ".", "~")) or "\\" in model:
            errors.append(f"Local model folder not found: '{model}'.")
        elif not _HF_REPO_ID.match(model):
            errors.append("Model must be a Hugging Face repo id like 'org/name' or an existing local folder.")
    if config.hardware_id is not None and not _DEVICE.match(str(config.hardware_id)):
        errors.append(f"Device '{config.hardware_id}' is not valid. Use auto, cpu, cuda or cuda:N.")
    if isinstance(config.precision, Precision) and config.precision not in TRANSFORMERS_PRECISIONS:
        errors.append(f"Precision {config.precision.value} is not supported by the Transformers backend in this build. "
                      "Use fp32, fp16 or bf16 (int8/int4 quantization is not implemented).")
    if not isinstance(config.allow_download, bool):
        errors.append("Allow-download must be true or false.")
    return errors


_REVISION = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/-]{0,99}$")


def revision_errors(config: BenchmarkConfig) -> list[str]:
    rev = getattr(config, "revision", None)
    if rev is None:
        return []
    if config.backend != "transformers":
        return ["A model revision only applies to the Transformers backend."]
    if not isinstance(rev, str) or not _REVISION.match(rev) or ".." in rev:
        return ["Revision must be a Hugging Face branch, tag or commit id (letters, digits, . _ - /; at most 100 characters)."]
    return []


def ensure_valid(config: BenchmarkConfig) -> None:
    errors = validate_config(config)
    if errors:
        raise ValidationError(errors)


def sanitize_name(name: str | None, default: str = "Untitled run") -> str:
    """Strip control characters, collapse whitespace and cap the length."""
    cleaned = _CONTROL_CHARS.sub("", name or "")
    cleaned = " ".join(cleaned.split())
    if not cleaned:
        return default
    return cleaned[:MAX_NAME_LEN]


def sanitize_notes(notes: str | None) -> str:
    cleaned = _CONTROL_CHARS.sub("", notes or "")
    return cleaned[:MAX_NOTES_LEN]
