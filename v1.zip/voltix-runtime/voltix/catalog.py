"""Model architecture profiles and simulated hardware profiles.

IMPORTANT: these are approximate, rounded figures used only to drive the
simulated backend and analytic memory estimates. They are not measurements.
"""

from __future__ import annotations

from .schemas import HardwareProfile, ModelProfile

MODELS: dict[str, ModelProfile] = {
    m.model_id: m
    for m in [
        ModelProfile("tinyllama-1.1b", "TinyLlama 1.1B", 1.1, 22, 2048, 32, 4, 2048),
        ModelProfile("phi-3-mini-3.8b", "Phi-3 Mini 3.8B", 3.8, 32, 3072, 32, 32, 4096),
        ModelProfile("mistral-7b", "Mistral 7B", 7.24, 32, 4096, 32, 8, 8192),
        ModelProfile("llama-3.1-8b", "Llama 3.1 8B", 8.03, 32, 4096, 32, 8, 8192),
        ModelProfile("llama-3.1-70b", "Llama 3.1 70B", 70.6, 80, 8192, 64, 8, 8192),
    ]
}

HARDWARE: dict[str, HardwareProfile] = {
    h.hw_id: h
    for h in [
        HardwareProfile("t4-16gb", "NVIDIA T4 16GB", 16.0, 320.0, 65.0, False),
        HardwareProfile("a10g-24gb", "NVIDIA A10G 24GB", 24.0, 600.0, 70.0, True),
        HardwareProfile("l4-24gb", "NVIDIA L4 24GB", 24.0, 300.0, 121.0, True),
        HardwareProfile("a100-80gb", "NVIDIA A100 80GB", 80.0, 2039.0, 312.0, True),
        HardwareProfile("h100-80gb", "NVIDIA H100 80GB", 80.0, 3350.0, 989.0, True),
    ]
}

DEFAULT_MODEL_ID = "mistral-7b"
DEFAULT_HARDWARE_ID = "a10g-24gb"


def get_model(model_id: str) -> ModelProfile | None:
    return MODELS.get(model_id)


def get_hardware(hw_id: str | None) -> HardwareProfile | None:
    return HARDWARE.get(hw_id) if hw_id else None


def model_label(model_id: str) -> str:
    """Display name: catalog name, a short name for local folders, or the Hugging Face repo id."""
    m = MODELS.get(model_id)
    if m:
        return m.display_name
    if model_id.startswith(("/", "~", ".")) or ":\\" in model_id[:3]:
        return f"{model_id.replace(chr(92), '/').rstrip('/').rsplit('/', 1)[-1]} (local)"
    return model_id


def hardware_label(hw_id: str | None) -> str:
    h = HARDWARE.get(hw_id) if hw_id else None
    return h.display_name if h else (hw_id or "n/a")
