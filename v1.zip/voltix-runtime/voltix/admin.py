"""Operator commands: health check and database backup.

    python -m voltix.admin health [--url http://127.0.0.1:8501]   exit 0 = healthy, 1 = problem (JSON on stdout)
    python -m voltix.admin backup DEST.db                          consistent copy of the database (safe while the app runs)
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
import urllib.request
from pathlib import Path

from . import __version__
from .backends import all_statuses
from .db import RunRepository, StorageError, resolve_db_path
from .security import configured_token, token_problem


def health_report(url: str | None = None) -> dict:
    checks: dict[str, dict] = {}

    def add(name: str, ok: bool, detail: str) -> None:
        checks[name] = {"ok": ok, "detail": detail}

    try:
        repo = RunRepository()
        n = len(repo.list_with_problems()[0]) if hasattr(repo, "list_with_problems") else 0
        add("database", True, f"{repo.path} opens; {n} readable run(s)")
    except StorageError as exc:
        add("database", False, str(exc))
    tok = token_problem(configured_token())
    add("access_token", tok is None, tok or ("set" if configured_token() else "not set (local-only mode)"))
    st = {s.key: s for s in all_statuses()}
    add("backend_simulated", st["simulated"].available, st["simulated"].detail)
    # informational: real inference being unavailable is not an unhealthy server
    add("backend_transformers", True, "available" if st["transformers"].available else f"not available: {st['transformers'].detail}")
    if url:
        try:
            with urllib.request.urlopen(url.rstrip("/") + "/_stcore/health", timeout=5) as r:  # noqa: S310 - operator-supplied URL
                body = r.read().decode("utf-8", "replace").strip()
            add("web_server", r.status == 200 and body == "ok", f"HTTP {r.status}: {body[:50]}")
        except Exception as exc:  # noqa: BLE001
            add("web_server", False, f"{type(exc).__name__}: {exc}")
    return {"healthy": all(c["ok"] for c in checks.values()), "version": __version__, "checks": checks}


def backup_database(dest: str | Path) -> Path:
    """Consistent snapshot using SQLite's online backup API. Refuses to overwrite an existing file."""
    src = resolve_db_path()
    dest = Path(dest)
    if not src.exists():
        raise StorageError(f"There is no database at {src} to back up.")
    if dest.resolve() == src.resolve():
        raise StorageError("The backup destination is the database itself.")
    if dest.exists():
        raise StorageError(f"{dest} already exists; choose a new file name (backups are never overwritten).")
    dest.parent.mkdir(parents=True, exist_ok=True)
    s = sqlite3.connect(f"file:{src}?mode=ro", uri=True)
    d = sqlite3.connect(dest)
    try:
        s.backup(d)
    finally:
        d.close()
        s.close()
    return dest


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m voltix.admin", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    h = sub.add_parser("health")
    h.add_argument("--url", default=None)
    b = sub.add_parser("backup")
    b.add_argument("dest")
    a = p.parse_args(argv)
    if a.cmd == "health":
        rep = health_report(a.url)
        print(json.dumps(rep, indent=2))
        return 0 if rep["healthy"] else 1
    try:
        print(f"Backup written: {backup_database(a.dest)}")
        return 0
    except StorageError as exc:
        print(f"Backup failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
