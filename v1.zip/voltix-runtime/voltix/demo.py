"""Curated demo experiments (all SIMULATED) so the product is explorable without a GPU."""

from __future__ import annotations

from .db import RunRepository
from .runner import run_benchmark
from .schemas import BenchmarkConfig, Precision

DEMO_TAG = "demo-seed"


def _cfg(model: str, hw: str, precision: Precision, batch: int, seed: int,
         prompt: int = 512, output: int = 128, iterations: int = 40, warmup: int = 3) -> BenchmarkConfig:
    return BenchmarkConfig(
        model_id=model, precision=precision, batch_size=batch, prompt_tokens=prompt, output_tokens=output,
        iterations=iterations, warmup_iterations=warmup, seed=seed, backend="simulated", hardware_id=hw,
    )


def demo_experiments() -> list[tuple[str, BenchmarkConfig]]:
    P = Precision
    return [
        ("Mistral 7B fp16, batch 1 (A10G)", _cfg("mistral-7b", "a10g-24gb", P.FP16, 1, 1001)),
        ("Mistral 7B fp16, batch 8 (A10G)", _cfg("mistral-7b", "a10g-24gb", P.FP16, 8, 1002)),
        ("Mistral 7B fp16, batch 32 (A10G)", _cfg("mistral-7b", "a10g-24gb", P.FP16, 32, 1003)),
        ("Mistral 7B int8, batch 8 (A10G)", _cfg("mistral-7b", "a10g-24gb", P.INT8, 8, 1004)),
        ("Mistral 7B int4, batch 8 (A10G)", _cfg("mistral-7b", "a10g-24gb", P.INT4, 8, 1005)),
        ("Llama 3.1 8B fp16, batch 8 (A100)", _cfg("llama-3.1-8b", "a100-80gb", P.FP16, 8, 1006)),
        ("Llama 3.1 8B fp16, batch 8 (H100)", _cfg("llama-3.1-8b", "h100-80gb", P.FP16, 8, 1007)),
        ("Llama 3.1 8B fp16, long prompt 4096 (H100)", _cfg("llama-3.1-8b", "h100-80gb", P.FP16, 4, 1008, prompt=4096, output=64)),
        ("TinyLlama 1.1B fp32, batch 1 (T4, no warmup)", _cfg("tinyllama-1.1b", "t4-16gb", P.FP32, 1, 1009, warmup=0, iterations=12)),
        ("TinyLlama 1.1B fp16, batch 1 (T4)", _cfg("tinyllama-1.1b", "t4-16gb", P.FP16, 1, 1010)),
        ("Phi-3 Mini 3.8B fp16, batch 16 (L4)", _cfg("phi-3-mini-3.8b", "l4-24gb", P.FP16, 16, 1011)),
        ("Mistral 7B fp16, batch 128 (A10G, expected OOM)", _cfg("mistral-7b", "a10g-24gb", P.FP16, 128, 1012, prompt=1024)),
    ]


def has_demo_runs(repo: RunRepository) -> bool:
    return any(DEMO_TAG in r.tags for r in repo.list_with_problems(include_samples=False)[0])


def seed_demo_runs(repo: RunRepository) -> int:
    """Create and save the demo experiments. Does nothing if they already exist."""
    if has_demo_runs(repo):
        return 0
    count = 0
    for name, config in demo_experiments():
        run = run_benchmark(config, name, tags=[DEMO_TAG])
        repo.save(run)
        count += 1
    return count


def remove_demo_runs(repo: RunRepository) -> int:
    return repo.delete_by_tag(DEMO_TAG)
