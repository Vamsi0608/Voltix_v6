"""Typed data schemas shared by the runner, storage, exports and UI.

Every result carries a ``DataSource`` so simulated numbers can never be
mistaken for measurements.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class DataSource(str, Enum):
    SIMULATED = "simulated"
    MEASURED = "measured"


class RunStatus(str, Enum):
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"  # stopped on request; no metrics
    TIMED_OUT = "timed_out"  # stopped by a time limit; no metrics

    @property
    def is_finished_ok(self) -> bool:
        return self is RunStatus.COMPLETED


class Precision(str, Enum):
    FP32 = "fp32"
    FP16 = "fp16"
    BF16 = "bf16"
    INT8 = "int8"
    INT4 = "int4"


class Severity(str, Enum):
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"


@dataclass(frozen=True)
class ModelProfile:
    """Architecture description used for memory/compute estimation."""

    model_id: str
    display_name: str
    params_billion: float
    num_layers: int
    hidden_size: int
    num_attention_heads: int
    num_kv_heads: int
    max_context: int


@dataclass(frozen=True)
class HardwareProfile:
    """Approximate accelerator spec used ONLY by the simulated backend."""

    hw_id: str
    display_name: str
    memory_gb: float
    memory_bandwidth_gbps: float
    peak_tflops_fp16: float
    supports_bf16: bool


@dataclass
class BenchmarkConfig:
    model_id: str
    precision: Precision
    batch_size: int
    prompt_tokens: int
    output_tokens: int
    iterations: int
    warmup_iterations: int
    seed: int
    backend: str
    hardware_id: Optional[str] = None  # simulated: profile id; transformers: "auto" | "cpu" | "cuda[:N]"
    allow_download: bool = False  # transformers only: permit fetching the model from the Hugging Face Hub
    revision: Optional[str] = None  # transformers only: Hub branch/tag/commit to load (pins the exact weights); None = default branch

    def to_dict(self) -> dict[str, Any]:
        return {
            "model_id": self.model_id,
            "precision": self.precision.value,
            "batch_size": self.batch_size,
            "prompt_tokens": self.prompt_tokens,
            "output_tokens": self.output_tokens,
            "iterations": self.iterations,
            "warmup_iterations": self.warmup_iterations,
            "seed": self.seed,
            "backend": self.backend,
            "hardware_id": self.hardware_id,
            "allow_download": self.allow_download,
            "revision": self.revision,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "BenchmarkConfig":
        return cls(
            model_id=str(d["model_id"]),
            precision=Precision(d["precision"]),
            batch_size=int(d["batch_size"]),
            prompt_tokens=int(d["prompt_tokens"]),
            output_tokens=int(d["output_tokens"]),
            iterations=int(d["iterations"]),
            warmup_iterations=int(d["warmup_iterations"]),
            seed=int(d["seed"]),
            backend=str(d["backend"]),
            hardware_id=d.get("hardware_id"),
            allow_download=bool(d.get("allow_download", False)),
            revision=(None if d.get("revision") is None else str(d["revision"])),
        )


@dataclass
class RequestSample:
    """One measured iteration: a batch of sequences generated together."""

    index: int
    ttft_ms: float
    latency_ms: float
    batch_size: int
    output_tokens_per_seq: int

    @property
    def total_output_tokens(self) -> int:
        return self.batch_size * self.output_tokens_per_seq

    def to_dict(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "ttft_ms": self.ttft_ms,
            "latency_ms": self.latency_ms,
            "batch_size": self.batch_size,
            "output_tokens_per_seq": self.output_tokens_per_seq,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "RequestSample":
        return cls(
            index=int(d["index"]),
            ttft_ms=float(d["ttft_ms"]),
            latency_ms=float(d["latency_ms"]),
            batch_size=int(d["batch_size"]),
            output_tokens_per_seq=int(d["output_tokens_per_seq"]),
        )


@dataclass
class BenchmarkMetrics:
    iterations: int
    latency_mean_ms: float
    latency_p50_ms: float
    latency_p95_ms: float
    latency_p99_ms: float
    latency_min_ms: float
    latency_max_ms: float
    latency_std_ms: float
    ttft_mean_ms: float
    ttft_p50_ms: float
    ttft_p95_ms: float
    tpot_mean_ms: float
    throughput_tokens_per_s: float
    sequences_per_s: float
    total_output_tokens: int
    total_time_s: float
    peak_memory_gb: Optional[float] = None
    memory_utilization: Optional[float] = None  # fraction of device memory, 0..1

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "BenchmarkMetrics":
        return cls(**{k: d.get(k) for k in cls.__dataclass_fields__})  # type: ignore[arg-type]


@dataclass
class Recommendation:
    rule_id: str
    title: str
    severity: Severity
    summary: str
    evidence: list[str]
    action: str
    how_to_verify: str  # what to measure to find out whether the suggestion works; never a predicted gain
    caveat: Optional[str] = None
    basis: str = DataSource.SIMULATED.value  # data source the advice is based on
    # "observation": a fact read directly from this run's numbers.
    # "hypothesis": an untested idea; no benefit is claimed until a comparison run measures one.
    # "caveat": a limit on how to read the results.
    kind: str = "hypothesis"

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "title": self.title,
            "severity": self.severity.value,
            "summary": self.summary,
            "evidence": list(self.evidence),
            "action": self.action,
            "how_to_verify": self.how_to_verify,
            "caveat": self.caveat,
            "basis": self.basis,
            "kind": self.kind,
        }


@dataclass
class BenchmarkRun:
    run_id: str
    name: str
    created_at: str  # ISO-8601 UTC
    status: RunStatus
    data_source: DataSource
    backend: str
    config: BenchmarkConfig
    metrics: Optional[BenchmarkMetrics] = None
    samples: list[RequestSample] = field(default_factory=list)
    environment: dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    notes: str = ""
    tags: list[str] = field(default_factory=list)
    voltix_version: str = ""

    @property
    def is_simulated(self) -> bool:
        return self.data_source == DataSource.SIMULATED

    def to_dict(self, include_samples: bool = True) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "name": self.name,
            "created_at": self.created_at,
            "status": self.status.value,
            "data_source": self.data_source.value,
            "backend": self.backend,
            "config": self.config.to_dict(),
            "metrics": self.metrics.to_dict() if self.metrics else None,
            "samples": [s.to_dict() for s in self.samples] if include_samples else [],
            "environment": self.environment,
            "error": self.error,
            "notes": self.notes,
            "tags": list(self.tags),
            "voltix_version": self.voltix_version,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "BenchmarkRun":
        return cls(
            run_id=str(d["run_id"]),
            name=str(d["name"]),
            created_at=str(d["created_at"]),
            status=RunStatus(d["status"]),
            data_source=DataSource(d["data_source"]),
            backend=str(d["backend"]),
            config=BenchmarkConfig.from_dict(d["config"]),
            metrics=BenchmarkMetrics.from_dict(d["metrics"]) if d.get("metrics") else None,
            samples=[RequestSample.from_dict(s) for s in d.get("samples", [])],
            environment=dict(d.get("environment") or {}),
            error=d.get("error"),
            notes=str(d.get("notes") or ""),
            tags=list(d.get("tags") or []),
            voltix_version=str(d.get("voltix_version") or ""),
        )
