"""Access control and exposure policy (framework-independent; the Streamlit gate lives in ui/auth.py).

Threat model (what this does and does NOT do):
- VOLTIX is a single-tenant tool. By default it listens on 127.0.0.1 only and has no login, because only the person
  at that computer can reach it.
- To serve anyone else, set VOLTIX_ACCESS_TOKEN (one shared secret, at least 16 characters). The app then refuses to
  show anything until the token is entered, and it refuses to start serving on a non-loopback address without one.
- A shared token is NOT per-user identity: everyone holding it sees the same runs and can delete them. Give each
  customer its own deployment and database.
- The token travels in the page session, so serve it over HTTPS (reverse proxy). VOLTIX cannot enforce TLS itself.
- With a token set the app is in RESTRICTED mode: model folders must live under VOLTIX_MODEL_DIR and downloads from
  the Hugging Face Hub are off unless VOLTIX_ALLOW_DOWNLOADS=1, so a remote user cannot probe the server's filesystem
  or make it fetch arbitrary multi-GB repositories.
"""

from __future__ import annotations

import hmac
import ipaddress
import logging
import os
import threading
import time
from pathlib import Path
from typing import Optional

log = logging.getLogger("voltix.security")

MIN_TOKEN_LEN = 16
LOOPBACK_NAMES = {"localhost", ""}  # "" = Streamlit's default meaning "all interfaces" is handled separately
_TRUE = {"1", "true", "yes", "on"}


def configured_token(env: Optional[dict[str, str]] = None) -> Optional[str]:
    e = os.environ if env is None else env
    tok = e.get("VOLTIX_ACCESS_TOKEN")
    return tok if tok else None


def token_problem(token: Optional[str]) -> Optional[str]:
    if token is None:
        return None
    if len(token) < MIN_TOKEN_LEN:
        return f"VOLTIX_ACCESS_TOKEN is too short ({len(token)} characters); use at least {MIN_TOKEN_LEN} random characters."
    if token != token.strip():
        return "VOLTIX_ACCESS_TOKEN must not start or end with whitespace."
    return None


def restricted_mode(env: Optional[dict[str, str]] = None) -> bool:
    e = os.environ if env is None else env
    return configured_token(e) is not None or e.get("VOLTIX_RESTRICTED", "").lower() in _TRUE


def is_loopback_address(address: Optional[str]) -> bool:
    """True only for an address that cannot be reached from another machine. None/empty means 'all interfaces' to Streamlit."""
    if not address:
        return False
    if address.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(address).is_loopback
    except ValueError:
        return False


def exposure_problem(address: Optional[str], env: Optional[dict[str, str]] = None) -> Optional[str]:
    """Reason to refuse to serve, or None. Fail closed: a reachable address without a valid token is refused."""
    tok = configured_token(env)
    bad = token_problem(tok)
    if bad:
        return bad
    if not is_loopback_address(address) and tok is None:
        return (f"VOLTIX is configured to listen on '{address or 'all interfaces'}' without an access token. "
                "Set VOLTIX_ACCESS_TOKEN (16+ characters) and serve it over HTTPS, or bind to 127.0.0.1.")
    return None


def model_root(env: Optional[dict[str, str]] = None) -> Path:
    e = os.environ if env is None else env
    return Path(e.get("VOLTIX_MODEL_DIR") or Path(__file__).resolve().parent.parent / "data" / "models").resolve()


def downloads_allowed(env: Optional[dict[str, str]] = None) -> bool:
    e = os.environ if env is None else env
    return (not restricted_mode(e)) or e.get("VOLTIX_ALLOW_DOWNLOADS", "").lower() in _TRUE


def restricted_config_errors(model_id: str, allow_download: bool, env: Optional[dict[str, str]] = None) -> list[str]:
    """Extra rules for restricted mode. Resolves symlinks and '..' before comparing, so escaping the root is not possible."""
    e = os.environ if env is None else env
    if not restricted_mode(e):
        return []
    errors: list[str] = []
    if allow_download and not downloads_allowed(e):
        errors.append("Downloading models is disabled on this server. Ask the administrator to place the model in the model folder.")
    looks_local = os.path.isabs(model_id) or model_id.startswith((".", "~")) or "\\" in model_id or os.path.isdir(model_id)
    if looks_local:
        try:
            resolved = Path(model_id).expanduser().resolve()
            resolved.relative_to(model_root(e))
        except (ValueError, OSError):
            errors.append("Local models must be inside the server's model folder.")
    return errors


def tokens_match(supplied: str, expected: str) -> bool:
    return hmac.compare_digest(supplied.encode("utf-8"), expected.encode("utf-8"))


class LoginLimiter:
    """Process-wide brake on token guessing: after 5 failures, further attempts are refused for an increasing delay."""

    FREE_ATTEMPTS = 5

    def __init__(self, clock=time.monotonic) -> None:
        self._clock, self._lock = clock, threading.Lock()
        self._failures, self._blocked_until = 0, 0.0

    def wait_seconds(self) -> float:
        with self._lock:
            return max(0.0, self._blocked_until - self._clock())

    def record(self, success: bool) -> None:
        with self._lock:
            if success:
                self._failures, self._blocked_until = 0, 0.0
                return
            self._failures += 1
            if self._failures >= self.FREE_ATTEMPTS:
                delay = min(2 ** (self._failures - self.FREE_ATTEMPTS + 1) * 5, 900)
                self._blocked_until = self._clock() + delay
                log.warning("access token: %d failed attempts; blocking attempts for %ds", self._failures, delay)

    def attempt(self, supplied: str, expected: str) -> tuple[bool, float]:
        """(accepted, seconds_to_wait). While blocked the token is not even compared."""
        wait = self.wait_seconds()
        if wait > 0:
            return False, wait
        ok = tokens_match(supplied, expected)
        self.record(ok)
        return ok, self.wait_seconds()
