"""Validation test matrix: every row is either EXECUTED here and judged, or NOT RUN with the reason. Nothing is filled in.

The matrix defines what we want evidence for; ``run_matrix`` runs only the rows whose hardware/model is actually
available on this machine. Rows needing a GPU or a downloadable model are reported as NOT RUN, never as passed.
"""

from __future__ import annotations

import math
import statistics
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from .fairness import Comparability, assess_comparability
from .runner import run_benchmark
from .schemas import BenchmarkConfig, BenchmarkRun, Precision, RunStatus

REPEATS = 2
MAX_REPEAT_CV_PCT = 15.0  # a row fails if two identical runs differ by more than this in throughput (relative spread)


@dataclass(frozen=True)
class Row:
    row_id: str
    needs: str  # "cpu-tiny" | "cuda" | "hub-model"
    model: str  # "tiny" or a model id
    precision: Precision
    batch: int
    prompt: int
    output: int
    iterations: int = 100
    warmup: int = 2

    def describe(self) -> str:
        return f"{self.model} {self.precision.value} b{self.batch} p{self.prompt}/o{self.output}"


def default_rows() -> list[Row]:
    rows = [Row(f"cpu-tiny-fp32-b{b}-p{p}", "cpu-tiny", "tiny", Precision.FP32, b, p, 16) for b in (1, 2, 4) for p in (32, 128)]
    rows.append(Row("cpu-tiny-bf16-b1-p32", "cpu-tiny", "tiny", Precision.BF16, 1, 32, 16))
    for b in (1, 8):
        rows.append(Row(f"gpu-qwen05b-fp16-b{b}", "cuda", "Qwen/Qwen2.5-0.5B", Precision.FP16, b, 128, 64, iterations=30, warmup=3))
    rows.append(Row("gpu-qwen05b-bf16-b1", "cuda", "Qwen/Qwen2.5-0.5B", Precision.BF16, 1, 128, 64, iterations=30, warmup=3))
    rows.append(Row("cpu-qwen05b-fp32-b1", "hub-model", "Qwen/Qwen2.5-0.5B", Precision.FP32, 1, 64, 16))
    return rows


@dataclass
class RowResult:
    row: Row
    outcome: str  # PASS | FAIL | NOT RUN
    detail: str
    throughput: Optional[list[float]] = None
    p50_ms: Optional[list[float]] = None
    repeat_spread_pct: Optional[float] = None
    comparability: Optional[str] = None
    device: Optional[str] = None


def availability(row: Row, tiny_path: Optional[str], hub_model_ok: Callable[[str], bool]) -> Optional[str]:
    """None if the row can run here, else the reason it cannot."""
    try:
        import torch
    except Exception as exc:  # noqa: BLE001
        return f"PyTorch is not usable here ({type(exc).__name__})"
    if row.needs == "cuda":
        return None if torch.cuda.is_available() else "no CUDA GPU on this machine"
    if row.needs == "hub-model":
        return None if hub_model_ok(row.model) else f"model {row.model} is not in the local cache and downloads are not used by the matrix"
    return None if tiny_path else "tiny test model could not be created"


def _config(row: Row, tiny_path: Optional[str]) -> BenchmarkConfig:
    on_cuda = row.needs == "cuda"
    return BenchmarkConfig(model_id=tiny_path if row.model == "tiny" else row.model, precision=row.precision, batch_size=row.batch,
                           prompt_tokens=row.prompt, output_tokens=row.output, iterations=row.iterations, warmup_iterations=row.warmup,
                           seed=1, backend="transformers", hardware_id="cuda" if on_cuda else "cpu", allow_download=False)


def judge(runs: list[BenchmarkRun], row: Row) -> RowResult:
    """PASS needs: every repeat completed with metrics, repeats comparable, throughput spread within MAX_REPEAT_CV_PCT."""
    bad = [r for r in runs if r.status != RunStatus.COMPLETED or r.metrics is None]
    if bad:
        return RowResult(row, "FAIL", f"{len(bad)} of {len(runs)} repeat(s) did not complete: {bad[0].error}")
    thr = [r.metrics.throughput_tokens_per_s for r in runs]
    p50 = [r.metrics.latency_p50_ms for r in runs]
    if not all(math.isfinite(x) and x > 0 for x in thr + p50):
        return RowResult(row, "FAIL", "non-finite or non-positive metric", thr, p50)
    mean = statistics.fmean(thr)
    spread = (max(thr) - min(thr)) / mean * 100.0
    rep = assess_comparability(runs[0], runs[1]) if len(runs) > 1 else None
    level = rep.level.value if rep else None
    dev = (runs[0].environment.get("device") or {}).get("name")
    if rep is not None and rep.level != Comparability.REPLICATE:
        return RowResult(row, "FAIL", f"identical repeats were judged '{level}' instead of 'replicate'", thr, p50, spread, level, dev)
    if spread > MAX_REPEAT_CV_PCT:
        return RowResult(row, "FAIL", f"repeat throughput differs by {spread:.1f}% (limit {MAX_REPEAT_CV_PCT:.0f}%)", thr, p50, spread, level, dev)
    return RowResult(row, "PASS", f"{len(runs)} repeats completed; throughput spread {spread:.1f}%", thr, p50, spread, level, dev)


def run_matrix(rows: list[Row], tiny_path: Optional[str], hub_model_ok: Callable[[str], bool] = lambda m: False,
               progress: Callable[[str], None] = lambda s: None) -> list[RowResult]:
    out: list[RowResult] = []
    for row in rows:
        why = availability(row, tiny_path, hub_model_ok)
        if why:
            out.append(RowResult(row, "NOT RUN", why))
            continue
        progress(f"running {row.row_id}")
        runs = [run_benchmark(_config(row, tiny_path), f"{row.row_id} #{k + 1}") for k in range(REPEATS)]
        out.append(judge(runs, row))
    return out


def to_markdown(results: list[RowResult], machine: str) -> str:
    ran = [r for r in results if r.outcome != "NOT RUN"]
    lines = [f"# VOLTIX validation matrix results", "", f"Machine: {machine}", "",
             f"Rows: {len(results)} defined, {len(ran)} executed ({sum(r.outcome == 'PASS' for r in ran)} PASS, "
             f"{sum(r.outcome == 'FAIL' for r in ran)} FAIL), {len(results) - len(ran)} NOT RUN.", "",
             "A PASS means only: every repeat completed, the repeats were judged comparable, and throughput of two identical "
             f"repeats agreed within {MAX_REPEAT_CV_PCT:.0f}%. It is not a performance claim. `tiny` is a random-weight pipeline-check "
             "model; its speed says nothing about real models.", "",
             "| Row | Configuration | Result | Throughput tok/s (repeats) | Detail |", "|---|---|---|---|---|"]
    for r in results:
        thr = ", ".join(f"{x:,.1f}" for x in r.throughput) if r.throughput else "–"
        lines.append(f"| {r.row.row_id} | {r.row.describe()} | **{r.outcome}** | {thr} | {r.detail} |")
    return "\n".join(lines) + "\n"
