"""Evidence-based optimization analysis.

Rules this module follows, deliberately:

1. **Only measured differences are reported.** Every number comes from two saved runs, or is
   simple arithmetic on them (a cost derived from a price the user typed in). There is no model
   that predicts what a change "would" save. A configuration nobody measured gets no number.
2. **Uncertainty travels with every number.** Metrics recorded per iteration get a bootstrap
   confidence interval; a change is only called an improvement or regression when that interval
   excludes zero and the effect is larger than a minimum size.
3. **Trade-offs are never hidden.** A pair is classified ``win`` only if it improved something
   and regressed nothing assessed; otherwise it is a ``trade_off`` and both sides are listed.
4. **Confidence is explicit and explainable.** Each check that raised or lowered it is listed.
5. **Simulated data is not evidence.** Simulated pairs are analysed so the demo works, but their
   confidence level is ``simulated`` and cost figures are refused.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Optional, Sequence

import numpy as np

from .fairness import (
    REPORTABLE,
    Comparability,
    ComparabilityReport,
    assess_comparability,
    device_identity,
    environment_matches,
    explain_level,
)
from .schemas import BenchmarkRun, RunStatus
from .stats import (
    DEFAULT_CONFIDENCE,
    DEFAULT_MIN_EFFECT_PCT,
    DEFAULT_RESAMPLES,
    ChangeEstimate,
    bootstrap_ratio,
    classify_change,
    classify_scalar_change,
    coefficient_of_variation,
    lag1_autocorrelation,
    stat_mean,
    stat_percentile,
)

MAX_STUDY_RUNS = 12

# Sample-size requirements per statistic (iterations needed before we will assess it).
MIN_SAMPLES = {"mean": 5, "p50": 5, "p95": 20, "p99": 100}
N_GOOD, N_OK, N_MIN = 30, 20, 5
CV_GOOD, CV_OK = 0.15, 0.30
AUTOCORR_LIMIT = 0.5
CI_WIDTH_GOOD, CI_WIDTH_OK = 10.0, 25.0  # half-width of the throughput CI, in percent

COST_KEY = "cost_per_million_tokens"


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

@dataclass
class MetricResult:
    key: str
    label: str
    unit: str
    higher_is_better: bool
    baseline: Optional[float]
    candidate: Optional[float]
    change_pct: Optional[float] = None
    ci_low_pct: Optional[float] = None
    ci_high_pct: Optional[float] = None
    verdict: str = "not_assessed"  # improved | regressed | negligible | no_detectable_change | not_assessed
    has_ci: bool = False
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


class ConfidenceLevel(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INSUFFICIENT = "insufficient"
    SIMULATED = "simulated"  # model output, not evidence


@dataclass(frozen=True)
class Check:
    name: str
    status: str  # pass | warn | fail | info
    detail: str


@dataclass
class Confidence:
    level: ConfidenceLevel
    checks: list[Check]
    summary: str

    def to_dict(self) -> dict[str, Any]:
        return {"level": self.level.value, "summary": self.summary,
                "checks": [{"name": c.name, "status": c.status, "detail": c.detail} for c in self.checks]}


@dataclass
class PairAnalysis:
    baseline_id: str
    candidate_id: str
    baseline_name: str
    candidate_name: str
    data_source: str
    comparability: ComparabilityReport
    metrics: dict[str, MetricResult]
    confidence: Confidence
    classification: str  # win | trade_off | regression | no_detectable_difference | replicate | insufficient_data | not_comparable
    headline: str
    improvements: list[str] = field(default_factory=list)  # metric keys
    regressions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "baseline_id": self.baseline_id, "candidate_id": self.candidate_id,
            "baseline_name": self.baseline_name, "candidate_name": self.candidate_name,
            "data_source": self.data_source, "classification": self.classification, "headline": self.headline,
            "improvements": list(self.improvements), "regressions": list(self.regressions),
            "comparability": self.comparability.to_dict(), "confidence": self.confidence.to_dict(),
            "metrics": {k: m.to_dict() for k, m in self.metrics.items()},
        }


@dataclass
class Finding:
    kind: str  # win | trade_off | regression | no_difference | dominated | no_improvement
    title: str
    statement: str
    evidence: list[str]
    tradeoffs: list[str]
    confidence: ConfidenceLevel
    run_ids: list[str]
    basis: str  # data source of the runs

    def to_dict(self) -> dict[str, Any]:
        d = dict(self.__dict__)
        d["confidence"] = self.confidence.value
        return d


@dataclass(frozen=True)
class Dominance:
    dominated_id: str
    by_id: str
    improved: tuple[str, ...]
    confidence: ConfidenceLevel


@dataclass
class Coverage:
    precisions: list[str]
    batch_sizes: list[int]
    devices: list[str]


@dataclass
class Experiment:
    factor: str
    suggestion: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


@dataclass
class Study:
    baseline_id: str
    data_source: str
    workload: dict[str, Any]
    analyses: list[PairAnalysis]
    excluded: list[tuple[str, str]]  # (run name, reason)
    run_ids: list[str]
    frontier: list[str]
    dominated: list[Dominance]
    findings: list[Finding]
    coverage: Coverage
    next_experiments: list[Experiment]
    notes: list[str]
    cost_enabled: bool = False
    noise: Optional[NoiseFloor] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "baseline_id": self.baseline_id, "data_source": self.data_source, "workload": self.workload,
            "analyses": [a.to_dict() for a in self.analyses],
            "excluded": [{"run": n, "reason": r} for n, r in self.excluded],
            "run_ids": list(self.run_ids), "frontier": list(self.frontier),
            "dominated": [{"dominated_id": d.dominated_id, "by_id": d.by_id, "improved": list(d.improved),
                           "confidence": d.confidence.value} for d in self.dominated],
            "findings": [f.to_dict() for f in self.findings],
            "coverage": self.coverage.__dict__,
            "next_experiments": [e.to_dict() for e in self.next_experiments],
            "notes": list(self.notes), "cost_enabled": self.cost_enabled,
            "run_to_run_noise": self.noise.to_dict() if self.noise else None,
        }


# ---------------------------------------------------------------------------
# Per-run helpers
# ---------------------------------------------------------------------------

def comparable_memory(run: BenchmarkRun) -> tuple[Optional[float], bool, str]:
    """(value in GB, reliable, note). CPU process memory is not a clean per-configuration signal."""
    if run.metrics is None or run.metrics.peak_memory_gb is None:
        return None, False, "memory was not recorded"
    if run.is_simulated:
        return run.metrics.peak_memory_gb, True, "estimated by the analytic model"
    if run.environment.get("device_kind") == "cpu":
        above = (run.environment.get("measurement") or {}).get("memory_above_baseline_gb")
        value = above if above is not None else run.metrics.peak_memory_gb
        return value, False, ("CPU memory is the peak of the whole Python process, which also reflects earlier runs "
                              "in the same process; it is shown for information and not used for verdicts")
    return run.metrics.peak_memory_gb, True, "peak GPU tensor memory (excludes CUDA context and cache)"


def _arrays(run: BenchmarkRun) -> tuple[np.ndarray, np.ndarray, float]:
    lat = np.array([s.latency_ms for s in run.samples], dtype=float)
    ttft = np.array([s.ttft_ms for s in run.samples], dtype=float)
    tokens = float(np.mean([s.total_output_tokens for s in run.samples])) if run.samples else 0.0
    return lat, ttft, tokens


def cost_per_million_tokens(throughput_tokens_per_s: float, price_per_hour: float) -> float:
    """Price to generate 1M output tokens at full utilization of a device costing ``price_per_hour``."""
    if throughput_tokens_per_s <= 0 or price_per_hour < 0:
        raise ValueError("throughput must be positive and price non-negative")
    return price_per_hour / (throughput_tokens_per_s * 3600.0) * 1e6


NOISE_KEYS = ("throughput_tokens_per_s", "latency_p50_ms", "latency_p95_ms", "latency_p99_ms",
              "ttft_mean_ms", "tpot_mean_ms")


@dataclass(frozen=True)
class NoiseFloor:
    """Largest difference seen between SEPARATE runs of the SAME setup, per metric (percent).

    A within-run interval only sees iteration-to-iteration noise. Separate runs of one setup also
    differ because of thermal state, other processes and cache state, and that is often larger.
    Measuring it takes nothing but replicate runs the user already has; no model is involved.
    """

    by_metric: Mapping[str, float]
    pairs: int  # number of replicate pairs behind these numbers

    def to_dict(self) -> dict[str, Any]:
        return {"by_metric": dict(self.by_metric), "replicate_pairs": self.pairs}


def _same_workload(a: BenchmarkRun, b: BenchmarkRun) -> bool:
    ca, cb = a.config, b.config
    return (a.data_source == b.data_source and a.backend == b.backend and ca.model_id == cb.model_id
            and ca.prompt_tokens == cb.prompt_tokens and ca.output_tokens == cb.output_tokens)


def replicate_noise(runs: Sequence[BenchmarkRun], like: Optional[BenchmarkRun] = None) -> NoiseFloor:
    """Measure run-to-run variability from runs that share an identical setup.

    Only measured runs count. ``like`` restricts the search to that run's workload (same model,
    prompt and output length), so noise from an unrelated workload is not borrowed.
    """
    arms: dict[tuple, list[BenchmarkRun]] = {}
    for r in runs:
        if r.metrics is None or r.is_simulated or (like is not None and not _same_workload(like, r)):
            continue
        c = r.config
        key = (r.backend, c.model_id, c.prompt_tokens, c.output_tokens, c.precision.value, c.batch_size, device_identity(r))
        arms.setdefault(key, []).append(r)
    floor: dict[str, float] = {}
    pairs = 0
    for members in arms.values():
        for i, a in enumerate(members):
            for b in members[i + 1:]:
                pairs += 1
                for k in NOISE_KEYS:
                    va, vb = getattr(a.metrics, k, None), getattr(b.metrics, k, None)
                    if va and vb:
                        floor[k] = max(floor.get(k, 0.0), abs(vb / va - 1.0) * 100.0)
                (ma, oka, _), (mb, okb, _) = comparable_memory(a), comparable_memory(b)
                if ma and mb and oka and okb:
                    floor["peak_memory_gb"] = max(floor.get("peak_memory_gb", 0.0), abs(mb / ma - 1.0) * 100.0)
    return NoiseFloor(floor, pairs)


def _apply_noise_floor(metrics: dict[str, "MetricResult"], noise: Optional[NoiseFloor]) -> None:
    """Demote 'improved'/'regressed' to 'no_detectable_change' when the change is no bigger than the
    difference already seen between replicate runs of one setup."""
    if noise is None or noise.pairs == 0:
        return
    for k, m in metrics.items():
        floor = noise.by_metric.get(k)
        if floor is None or m.verdict not in ("improved", "regressed") or m.change_pct is None:
            continue
        if abs(m.change_pct) <= floor:
            m.verdict = "no_detectable_change"
            extra = f"within the {floor:.1f}% difference seen between replicate runs of one setup"
            m.note = f"{m.note}; {extra}" if m.note else extra


def _tag(base: BenchmarkRun, cand: BenchmarkRun, key: str) -> str:
    return f"{base.run_id}|{cand.run_id}|{key}"


def _from_estimate(spec: tuple[str, str, str, bool], b: float, c: float, est: ChangeEstimate,
                   min_effect_pct: float, note: str = "") -> MetricResult:
    key, label, unit, hib = spec
    if not est.has_interval:
        note = "too few iterations to estimate uncertainty (at least 5 per run needed)"
    return MetricResult(key, label, unit, hib, b, c, est.change_pct, est.ci_low_pct, est.ci_high_pct,
                        classify_change(est, hib, min_effect_pct), est.has_interval, note)


SPECS = {
    "throughput_tokens_per_s": ("throughput_tokens_per_s", "Throughput", "tok/s", True),
    "latency_p50_ms": ("latency_p50_ms", "Latency p50", "ms", False),
    "latency_p95_ms": ("latency_p95_ms", "Latency p95", "ms", False),
    "latency_p99_ms": ("latency_p99_ms", "Latency p99", "ms", False),
    "ttft_mean_ms": ("ttft_mean_ms", "Time to first token (mean)", "ms", False),
    "tpot_mean_ms": ("tpot_mean_ms", "Time per output token (mean)", "ms", False),
    "peak_memory_gb": ("peak_memory_gb", "Peak memory", "GB", False),
    COST_KEY: (COST_KEY, "Cost per 1M output tokens", "price units", False),
}


def _metric_results(base: BenchmarkRun, cand: BenchmarkRun, min_effect_pct: float, resamples: int,
                    prices: Optional[Mapping[str, float]]) -> dict[str, MetricResult]:
    out: dict[str, MetricResult] = {}
    thr_est: Optional[ChangeEstimate] = None
    bl, bt, btok = _arrays(base)
    cl, ct, ctok = _arrays(cand)
    n = min(bl.size, cl.size)

    def not_assessed(key: str, b: Optional[float], c: Optional[float], why: str) -> MetricResult:
        k, label, unit, hib = SPECS[key]
        change = None if (b in (None, 0) or c is None) else (c / b - 1.0) * 100.0
        return MetricResult(k, label, unit, hib, b, c, change, None, None, "not_assessed", False, why)

    if bl.size < 2 or cl.size < 2:
        why = "per-iteration samples were not loaded or too few to estimate uncertainty"
        for key in ("throughput_tokens_per_s", "latency_p50_ms", "latency_p95_ms", "latency_p99_ms", "ttft_mean_ms"):
            out[key] = not_assessed(key, getattr(base.metrics, key), getattr(cand.metrics, key), why)
    else:
        # Throughput = tokens per iteration / mean latency (the run's aggregate definition).
        thr_est = bootstrap_ratio(bl, cl, lambda a, t=btok: t * 1000.0 / a.mean(axis=1),
                                  lambda a, t=ctok: t * 1000.0 / a.mean(axis=1),
                                  tag=_tag(base, cand, "thr"), resamples=resamples)
        out["throughput_tokens_per_s"] = _from_estimate(
            SPECS["throughput_tokens_per_s"], base.metrics.throughput_tokens_per_s,
            cand.metrics.throughput_tokens_per_s, thr_est, min_effect_pct)

        for key, q, need_key in (("latency_p50_ms", 50, "p50"), ("latency_p95_ms", 95, "p95"), ("latency_p99_ms", 99, "p99")):
            b, c = getattr(base.metrics, key), getattr(cand.metrics, key)
            if n < MIN_SAMPLES[need_key]:
                out[key] = not_assessed(key, b, c, f"needs at least {MIN_SAMPLES[need_key]} iterations per run to estimate "
                                                   f"{need_key} reliably (smaller run has {n})")
                continue
            est = bootstrap_ratio(bl, cl, stat_percentile(q), tag=_tag(base, cand, key), resamples=resamples)
            out[key] = _from_estimate(SPECS[key], b, c, est, min_effect_pct)
        est = bootstrap_ratio(bt, ct, stat_mean, tag=_tag(base, cand, "ttft"), resamples=resamples)
        out["ttft_mean_ms"] = _from_estimate(SPECS["ttft_mean_ms"], base.metrics.ttft_mean_ms, cand.metrics.ttft_mean_ms,
                                             est, min_effect_pct, "includes generate() setup, prefill and the first decode step")

        if base.config.output_tokens > 1 and cand.config.output_tokens > 1 and base.metrics.tpot_mean_ms and cand.metrics.tpot_mean_ms:
            b_tp = (bl - bt) / (base.config.output_tokens - 1)
            c_tp = (cl - ct) / (cand.config.output_tokens - 1)
            if np.all(b_tp > 0) and np.all(c_tp > 0):
                est = bootstrap_ratio(b_tp, c_tp, stat_mean, tag=_tag(base, cand, "tpot"), resamples=resamples)
                out["tpot_mean_ms"] = _from_estimate(SPECS["tpot_mean_ms"], base.metrics.tpot_mean_ms,
                                                     cand.metrics.tpot_mean_ms, est, min_effect_pct)

    # Memory: one number per run, so no interval.
    bm, b_ok, b_note = comparable_memory(base)
    cm, c_ok, c_note = comparable_memory(cand)
    if bm is not None and cm is not None and bm > 0:
        change = (cm / bm - 1.0) * 100.0
        reliable = b_ok and c_ok
        verdict = classify_scalar_change(change, False, min_effect_pct) if reliable else "not_assessed"
        note = "single measurement per run, so no uncertainty estimate" if reliable else (b_note if not b_ok else c_note)
        out["peak_memory_gb"] = MetricResult("peak_memory_gb", "Peak memory", "GB", False, bm, cm, change, None, None, verdict, False, note)

    # Cost: derived from the user's own prices and the measured throughput; never from a prediction.
    if prices and thr_est is not None and thr_est.ratio_samples is not None and not base.is_simulated:
        pb, pc = prices.get(device_identity(base)), prices.get(device_identity(cand))
        if pb is not None and pc is not None and pb > 0 and pc > 0:
            cb = cost_per_million_tokens(base.metrics.throughput_tokens_per_s, pb)
            cc = cost_per_million_tokens(cand.metrics.throughput_tokens_per_s, pc)
            ratios = (pc / pb) / thr_est.ratio_samples
            lo, hi = np.quantile(ratios, [(1 - DEFAULT_CONFIDENCE) / 2, 1 - (1 - DEFAULT_CONFIDENCE) / 2])
            est = ChangeEstimate((cc / cb - 1.0) * 100.0, (float(lo) - 1.0) * 100.0, (float(hi) - 1.0) * 100.0,
                                 DEFAULT_CONFIDENCE, int(ratios.size))
            out[COST_KEY] = _from_estimate(
                SPECS[COST_KEY], cb, cc, est, min_effect_pct,
                "derived from your hourly prices and measured throughput; assumes the device is fully busy, "
                "and excludes model load time, idle time and any other cost")
    return out


# ---------------------------------------------------------------------------
# Confidence
# ---------------------------------------------------------------------------

def assess_confidence(base: BenchmarkRun, cand: BenchmarkRun, report: ComparabilityReport,
                      metrics: Mapping[str, MetricResult], noise: Optional[NoiseFloor] = None) -> Confidence:
    checks: list[Check] = []
    simulated = base.is_simulated

    if not report.reportable:
        return Confidence(ConfidenceLevel.INSUFFICIENT, [Check("Comparable", "fail", report.blockers[0].message if report.blockers else "not comparable")],
                          "These runs cannot be compared meaningfully.")

    # 1. Attribution
    if report.level == Comparability.CONTROLLED:
        checks.append(Check("Attribution", "pass", f"Exactly one setting changed ({report.factors_changed[0]})."))
    elif report.level == Comparability.MULTI_FACTOR:
        checks.append(Check("Attribution", "fail", "Several settings changed at once, so no single cause can be named."))
    else:
        checks.append(Check("Attribution", "info", "Same configuration: this pair measures noise."))

    # 2. Sample size
    n = min(len(base.samples), len(cand.samples))
    if n < 2:
        checks.append(Check("Sample size", "fail", "Per-iteration samples are unavailable, so uncertainty cannot be estimated."))
    elif n >= N_GOOD:
        checks.append(Check("Sample size", "pass", f"{n} measured iterations in the smaller run (>= {N_GOOD})."))
    elif n >= N_OK:
        checks.append(Check("Sample size", "warn", f"{n} iterations in the smaller run; {N_GOOD}+ gives tighter estimates."))
    else:
        checks.append(Check("Sample size", "fail", f"Only {n} iterations in the smaller run (< {N_OK}); intervals are wide and tail metrics unreliable."))

    # 3. Noise and independence
    for run, label in ((base, "baseline"), (cand, "candidate")):
        lat = [s.latency_ms for s in run.samples]
        if len(lat) >= 2:
            cv = coefficient_of_variation(lat)
            if cv is not None:
                status = "pass" if cv <= CV_GOOD else "warn" if cv <= CV_OK else "fail"
                checks.append(Check(f"Noise ({label})", status, f"Latency varies by {cv * 100:.0f}% (std/mean) across iterations."))
            ac = lag1_autocorrelation(lat)
            if ac is not None and abs(ac) > AUTOCORR_LIMIT:
                checks.append(Check(f"Independence ({label})", "warn",
                                    f"Consecutive iterations are correlated (r = {ac:.2f}); the run may be drifting "
                                    "(thermal throttling, caching), so intervals are likely too narrow."))

    # 4. Warm-up and environment
    cold = [label for run, label in ((base, "baseline"), (cand, "candidate")) if run.config.warmup_iterations == 0]
    checks.append(Check("Warm-up", "fail" if cold else "pass",
                        f"No warm-up in the {' and '.join(cold)} run, so cold-start iterations are included." if cold
                        else "Both runs excluded warm-up iterations."))
    if not simulated:
        ok = environment_matches(report)
        checks.append(Check("Environment", "pass" if ok else "fail",
                            "Software versions and host match." if ok else
                            "; ".join(i.message for i in report.issues if i.code in ("env-differs", "model-revision"))))

    # 4b. Run-to-run variability (what a within-run interval cannot see)
    if not simulated:
        if noise is not None and noise.pairs > 0:
            thr_floor = noise.by_metric.get("throughput_tokens_per_s")
            where = f" (throughput up to {thr_floor:.1f}%)" if thr_floor is not None else ""
            checks.append(Check("Replication", "pass",
                                f"{noise.pairs} replicate pair(s) of one setup differ by{where}; changes no bigger "
                                "than a metric's replicate difference are not reported as effects."))
        else:
            checks.append(Check("Replication", "warn",
                                "No two runs share an identical setup, so run-to-run variability is unknown. The interval "
                                "only reflects noise inside each run and is probably too optimistic across separate runs. "
                                "Repeat one configuration to measure it."))

    # 5. Precision of the headline estimate
    thr = metrics.get("throughput_tokens_per_s")
    if thr is not None and thr.has_ci and thr.ci_low_pct is not None and thr.ci_high_pct is not None:
        half = (thr.ci_high_pct - thr.ci_low_pct) / 2.0
        status = "pass" if half <= CI_WIDTH_GOOD else "warn" if half <= CI_WIDTH_OK else "fail"
        checks.append(Check("Precision", status, f"Throughput change is known to within about ±{half:.1f} percentage points (95% CI)."))

    # Level
    if simulated:
        return Confidence(ConfidenceLevel.SIMULATED, checks,
                          "Simulated data: this describes the analytic model, not real hardware, and is not evidence.")
    if n < N_MIN:
        return Confidence(ConfidenceLevel.INSUFFICIENT, checks, f"Fewer than {N_MIN} iterations in one run: not enough data.")
    fails = [c for c in checks if c.status == "fail"]
    warns = [c for c in checks if c.status == "warn"]
    if fails:
        level, why = ConfidenceLevel.LOW, "Low: " + "; ".join(c.name.lower() for c in fails) + "."
    elif warns:
        level, why = ConfidenceLevel.MEDIUM, "Medium: " + "; ".join(c.name.lower() for c in warns) + " could be better."
    else:
        level, why = ConfidenceLevel.HIGH, ("High: controlled comparison with enough low-noise iterations. This holds for this "
                                            "machine, software and workload only.")
    return Confidence(level, checks, why)


# ---------------------------------------------------------------------------
# Pair analysis
# ---------------------------------------------------------------------------

def _decision_keys(metrics: Mapping[str, MetricResult]) -> list[str]:
    keys = ["throughput_tokens_per_s"]
    keys.append("latency_p95_ms" if metrics.get("latency_p95_ms") and metrics["latency_p95_ms"].verdict != "not_assessed"
                else "latency_p50_ms")
    keys += ["ttft_mean_ms", "peak_memory_gb", COST_KEY]
    return [k for k in keys if k in metrics]


def describe_metric(m: MetricResult) -> str:
    """Plain-language description using only observed numbers."""
    if m.baseline is None or m.candidate is None:
        return f"{m.label.lower()}: n/a"
    vals = f"{m.baseline:,.2f} -> {m.candidate:,.2f} {m.unit}" if abs(m.baseline) < 100 else f"{m.baseline:,.0f} -> {m.candidate:,.0f} {m.unit}"
    if m.change_pct is None:
        return f"{m.label.lower()} {vals}"
    if m.has_ci and m.ci_low_pct is not None and m.ci_high_pct is not None:
        return f"{m.label.lower()} {m.change_pct:+.1f}% (95% CI {m.ci_low_pct:+.1f}% to {m.ci_high_pct:+.1f}%; {vals})"
    return f"{m.label.lower()} {m.change_pct:+.1f}% ({vals}; no uncertainty estimate)"


def analyze_pair(
    baseline: BenchmarkRun,
    candidate: BenchmarkRun,
    *,
    min_effect_pct: float = DEFAULT_MIN_EFFECT_PCT,
    resamples: int = DEFAULT_RESAMPLES,
    prices: Optional[Mapping[str, float]] = None,
    noise: Optional[NoiseFloor] = None,
) -> PairAnalysis:
    """Compare ``candidate`` against ``baseline``. Both must be saved runs (samples loaded for intervals).

    ``noise`` (see ``replicate_noise``) is the run-to-run difference observed between replicate runs;
    effects no larger than it are not reported.
    """
    report = assess_comparability(baseline, candidate)
    source = baseline.data_source.value

    def shell(cls: str, headline: str, metrics: Optional[dict[str, MetricResult]] = None,
              conf: Optional[Confidence] = None) -> PairAnalysis:
        return PairAnalysis(baseline.run_id, candidate.run_id, baseline.name, candidate.name, source, report,
                            metrics or {}, conf or assess_confidence(baseline, candidate, report, metrics or {}, noise), cls, headline)

    if not report.reportable:
        return shell("not_comparable", explain_level(report))

    metrics = _metric_results(baseline, candidate, min_effect_pct, resamples, prices)
    if report.level == Comparability.REPLICATE:
        # Same setup: any difference is run-to-run noise. Keep the numbers (they ARE the noise) but never
        # call them an improvement or a regression.
        for m in metrics.values():
            if m.verdict in ("improved", "regressed"):
                m.verdict = "no_detectable_change"
                m.note = "same setup: this difference is run-to-run noise, not an effect"
    else:
        _apply_noise_floor(metrics, noise)
    conf = assess_confidence(baseline, candidate, report, metrics, noise)
    keys = _decision_keys(metrics)
    assessed = [k for k in keys if metrics[k].verdict != "not_assessed"]
    improvements = [k for k in assessed if metrics[k].verdict == "improved"]
    regressions = [k for k in assessed if metrics[k].verdict == "regressed"]

    pa = shell("insufficient_data", "Not enough data to assess any metric.", metrics, conf)
    pa.improvements, pa.regressions = improvements, regressions
    if not assessed:
        return pa
    names = lambda ks: ", ".join(metrics[k].label.lower() for k in ks)  # noqa: E731
    if report.level == Comparability.REPLICATE:
        worst = max((abs(metrics[k].change_pct or 0.0), k) for k in assessed)
        pa.classification = "replicate"
        pa.headline = (f"Replicate runs differ by up to {worst[0]:.1f}% on {metrics[worst[1]].label.lower()}. "
                       "Treat changes of this size between configurations as noise.")
    elif improvements and not regressions:
        pa.classification, pa.headline = "win", f"Better on {names(improvements)}; nothing assessed got worse."
    elif improvements and regressions:
        pa.classification, pa.headline = "trade_off", f"Better on {names(improvements)}, but worse on {names(regressions)}."
    elif regressions:
        pa.classification, pa.headline = "regression", f"Worse on {names(regressions)}; nothing assessed improved."
    else:
        pa.classification, pa.headline = "no_detectable_difference", "No difference detectable outside measurement noise."
    return pa


# ---------------------------------------------------------------------------
# Findings
# ---------------------------------------------------------------------------

def _pair_evidence(pa: PairAnalysis) -> list[str]:
    lines = []
    for key in _decision_keys(pa.metrics):
        m = pa.metrics[key]
        if key == "peak_memory_gb" and m.verdict == "not_assessed":
            continue  # whole-process CPU RAM: shown in the metric table with its note, never as evidence in a finding
        tag = {"improved": "better", "regressed": "worse", "negligible": "negligible change",
               "no_detectable_change": "no detectable change", "not_assessed": "not assessed"}[m.verdict]
        lines.append(f"{describe_metric(m)}: {tag}")
    return lines


def _tradeoffs(pa: PairAnalysis) -> list[str]:
    out = []
    for k in pa.regressions:
        m = pa.metrics[k]
        out.append(f"Cost of this change: {describe_metric(m)}.")
    notes = [i.message for i in pa.comparability.issues if i.code == "batch-semantics"]
    return out + notes


def _finding_from_pair(pa: PairAnalysis) -> Optional[Finding]:
    if pa.classification in ("not_comparable", "insufficient_data"):
        return None
    what = "; ".join(pa.comparability.factors_changed) or "same configuration"
    kind = {"win": "win", "trade_off": "trade_off", "regression": "regression",
            "no_detectable_difference": "no_difference", "replicate": "no_difference"}[pa.classification]
    caveat = " (single comparison on one machine)" if pa.data_source == "measured" else " (SIMULATED: describes the model, not hardware)"
    statement = f"{pa.headline}{caveat}"
    if pa.classification == "no_detectable_difference":
        statement += " This is not proof the change has no effect: only that this data cannot detect one."
    return Finding(kind, f"{what}: {pa.candidate_name} vs {pa.baseline_name}", statement, _pair_evidence(pa),
                   _tradeoffs(pa), pa.confidence.level, [pa.baseline_id, pa.candidate_id], pa.data_source)


def supported_precisions(run: BenchmarkRun) -> list[str]:
    """Precisions that could be benchmarked for this run's target (no promise about their performance)."""
    if run.is_simulated:
        return ["fp32", "fp16", "bf16", "int8", "int4"]
    kind = run.environment.get("device_kind")
    if kind == "cpu":
        return ["fp32", "bf16"]
    out = ["fp32", "fp16"]
    cc = ((run.environment.get("device") or {}).get("compute_capability") or "0.0").split(".")[0]
    if cc.isdigit() and int(cc) >= 8:
        out.append("bf16")
    return out


def _coverage_and_experiments(baseline: BenchmarkRun, group: Sequence[BenchmarkRun]) -> tuple[Coverage, list[Experiment]]:
    precisions = sorted({r.config.precision.value for r in group})
    batches = sorted({r.config.batch_size for r in group})
    devices = sorted({device_identity(r) for r in group})
    exps: list[Experiment] = []
    for p in supported_precisions(baseline):
        if p not in precisions:
            exps.append(Experiment("precision", f"Benchmark {p}",
                                   f"No saved run of this workload uses {p}. Its effect is unknown until measured."))
    b = baseline.config.batch_size
    for cand in sorted({max(1, b // 2), b * 2}):
        if cand != b and cand not in batches:
            exps.append(Experiment("batch size", f"Benchmark batch size {cand}",
                                   f"No saved run of this workload uses batch {cand}. Its effect on throughput and "
                                   "latency is unknown until measured."))
    if len(devices) == 1:
        exps.append(Experiment("hardware", "Benchmark the same workload on a different device",
                               "Every run so far used the same device, so nothing can be said about other hardware."))
    if min(len(r.samples) for r in group) < N_GOOD:
        exps.append(Experiment("sample size", f"Re-run with at least {N_GOOD} iterations",
                               f"Some runs have fewer than {N_GOOD} iterations, which widens every interval."))
    return Coverage(precisions, batches, devices), exps


def _group_runs(baseline: BenchmarkRun, runs: Sequence[BenchmarkRun]) -> tuple[list[BenchmarkRun], list[tuple[str, str]]]:
    group, excluded = [baseline], []
    for r in runs:
        if r.run_id == baseline.run_id:
            continue
        rep = assess_comparability(baseline, r)
        if not rep.reportable:
            excluded.append((r.name, explain_level(rep)))
        elif len(group) >= MAX_STUDY_RUNS:
            excluded.append((r.name, f"study is limited to {MAX_STUDY_RUNS} runs"))
        else:
            group.append(r)
    return group, excluded


def build_study(
    baseline: BenchmarkRun,
    runs: Sequence[BenchmarkRun],
    *,
    prices: Optional[Mapping[str, float]] = None,
    min_effect_pct: float = DEFAULT_MIN_EFFECT_PCT,
    resamples: int = DEFAULT_RESAMPLES,
) -> Study:
    """Analyse every run that is a fair comparison with ``baseline`` and summarize what the data supports."""
    if baseline.status != RunStatus.COMPLETED or baseline.metrics is None:
        raise ValueError("The baseline run failed or has no metrics.")
    usable = [r for r in runs if r.status == RunStatus.COMPLETED and r.metrics is not None]
    group, excluded = _group_runs(baseline, usable)
    noise = replicate_noise(group, like=baseline) if not baseline.is_simulated else None

    analyses = [analyze_pair(baseline, r, min_effect_pct=min_effect_pct, resamples=resamples, prices=prices, noise=noise)
                for r in group[1:]]

    # Dominance across the whole group (not only vs. the baseline). Replicates never dominate.
    dominated: list[Dominance] = []
    by_ids = {r.run_id: r for r in group}
    for i, a in enumerate(group):
        for b in group[i + 1:]:
            pa = next((x for x in analyses if x.baseline_id == a.run_id and x.candidate_id == b.run_id), None) \
                or analyze_pair(a, b, min_effect_pct=min_effect_pct, resamples=resamples, noise=noise)
            if pa.comparability.level == Comparability.REPLICATE or pa.confidence.level == ConfidenceLevel.INSUFFICIENT:
                continue
            if pa.classification == "win":
                dominated.append(Dominance(a.run_id, b.run_id, tuple(pa.improvements), pa.confidence.level))
            elif pa.classification == "regression":
                dominated.append(Dominance(b.run_id, a.run_id, tuple(pa.regressions), pa.confidence.level))
    dominated_ids = {d.dominated_id for d in dominated}
    frontier = [r.run_id for r in group if r.run_id not in dominated_ids]

    findings: list[Finding] = [f for pa in analyses if (f := _finding_from_pair(pa)) is not None]
    for d in dominated:
        a, b = by_ids[d.dominated_id], by_ids[d.by_id]
        labels = ", ".join(SPECS[k][1].lower() for k in d.improved)
        findings.append(Finding(
            "dominated", f"{a.name} is outperformed by {b.name}",
            f"{b.name} is better on {labels} and not worse on anything assessed, in a like-for-like comparison.",
            [], [], d.confidence, [a.run_id, b.run_id], baseline.data_source.value))
    if not any(d.by_id == baseline.run_id for d in dominated) and baseline.run_id in frontier and len(group) > 1 \
            and not any(f.kind == "win" for f in findings):
        findings.append(Finding(
            "no_improvement", "No measured configuration clearly beats the baseline",
            "Among the comparable runs, none improved on the baseline without giving something up. "
            "That reflects the configurations tried so far, not a limit of the hardware.",
            [], [], ConfidenceLevel.SIMULATED if baseline.is_simulated else ConfidenceLevel.MEDIUM,
            [baseline.run_id], baseline.data_source.value))

    coverage, experiments = _coverage_and_experiments(baseline, group)
    notes = [
        "Every figure is a difference between saved runs, or arithmetic on them. Nothing here is a prediction.",
        "Intervals are 95% bootstrap intervals that treat iterations as independent; they describe measurement noise on this machine only.",
        "Results do not transfer to other hardware, models, prompt lengths or real traffic patterns.",
        "Speed is measured, output quality is not: check quality yourself before adopting a lower precision.",
    ]
    if baseline.is_simulated:
        notes.insert(0, "SIMULATED DATA: the runs come from an analytic model. These findings illustrate the workflow and are not evidence.")
    workload = {"model_id": baseline.config.model_id, "prompt_tokens": baseline.config.prompt_tokens,
                "output_tokens": baseline.config.output_tokens, "backend": baseline.backend}
    return Study(baseline.run_id, baseline.data_source.value, workload, analyses, excluded, [r.run_id for r in group],
                 frontier, dominated, findings, coverage, experiments, notes,
                 cost_enabled=bool(prices) and not baseline.is_simulated, noise=noise)


def price_keys(runs: Sequence[BenchmarkRun]) -> list[str]:
    """Distinct device identities of measured runs: the devices the user may price."""
    return sorted({device_identity(r) for r in runs if not r.is_simulated})


def suggest_baseline(runs: Sequence[BenchmarkRun]) -> Optional[BenchmarkRun]:
    """Default baseline: the run with the most fair comparisons available, measured data first.

    Uses only configuration comparability (no statistics), so it is cheap and cannot favour a flattering result.
    Ties go to the OLDEST run: in a sweep the first configuration measured is normally the reference.
    """
    usable = [r for r in runs if r.status == RunStatus.COMPLETED and r.metrics is not None]
    best: Optional[tuple[tuple[int, int], BenchmarkRun]] = None
    # Callers list newest first; reverse so that timestamp ties (timestamps have one-second resolution and a
    # sweep can finish several runs per second) also resolve to the run that was saved first.
    for r in sorted(reversed(usable), key=lambda x: x.created_at):
        peers = sum(1 for o in usable if o.run_id != r.run_id and assess_comparability(r, o).reportable)
        key = (0 if r.is_simulated else 1, peers)  # measured beats simulated; then most peers; oldest wins ties
        if best is None or key > best[0]:
            best = (key, r)
    return best[1] if best else None
