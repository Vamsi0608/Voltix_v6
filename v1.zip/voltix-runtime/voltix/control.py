"""Run control: cooperative cancellation and time limits.

How it works. A run can be asked to stop (``CancelToken.cancel``) or can exceed a time limit
(``RunLimits``). Neither interrupts the process: the runner and the backend ask ``AbortCheck`` at safe
points and raise ``RunAborted``, which unwinds the run and frees the model.

Safe points: before and after model loading, between iterations, and (Transformers backend) after every
generated token inside an iteration. What cannot be interrupted: ``from_pretrained`` while it is loading or
downloading, and a single GPU kernel that hangs. A time limit during loading is therefore noticed only when
loading returns, and a cancel during loading takes effect right after it.

A cancelled or timed-out run has no metrics and is never compared: a partial run is not a valid observation
set (it would silently change the iteration count the statistics assume).
"""

from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass
from typing import Callable, Optional

from .backends.base import BackendError

DEFAULT_MAX_ITERATION_SECONDS = 300.0
DEFAULT_MAX_RUN_SECONDS = 1800.0


class RunAborted(BackendError):
    """The run was stopped on request (``cancelled``) or by a time limit (``timed_out``)."""

    def __init__(self, kind: str, reason: str) -> None:
        super().__init__(reason)
        self.kind = kind
        self.reason = reason


class CancelToken:
    """Thread-safe 'please stop' flag (set from another thread, e.g. a UI button or Ctrl+C)."""

    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()


def _parse_limit(text: Optional[str], default: Optional[float], name: str) -> Optional[float]:
    if text is None or text.strip() == "":
        return default
    if text.strip().lower() in ("0", "none", "off", "unlimited"):
        return None
    try:
        value = float(text)
    except ValueError:
        raise ValueError(f"{name} must be a number of seconds, 0 or 'none' (got {text!r}).") from None
    if not value > 0 or value != value or value == float("inf"):
        raise ValueError(f"{name} must be a positive number of seconds (got {text!r}).")
    return value


@dataclass(frozen=True)
class RunLimits:
    """Time limits in seconds; ``None`` disables a limit."""

    max_run_seconds: Optional[float] = DEFAULT_MAX_RUN_SECONDS
    max_iteration_seconds: Optional[float] = DEFAULT_MAX_ITERATION_SECONDS

    def __post_init__(self) -> None:
        for name in ("max_run_seconds", "max_iteration_seconds"):
            v = getattr(self, name)
            if v is not None and not (v > 0 and v != float("inf") and v == v):
                raise ValueError(f"{name} must be a positive number of seconds or None (got {v!r}).")

    @classmethod
    def from_env(cls, env: Optional[dict[str, str]] = None) -> "RunLimits":
        e = os.environ if env is None else env
        return cls(max_run_seconds=_parse_limit(e.get("VOLTIX_MAX_RUN_SECONDS"), DEFAULT_MAX_RUN_SECONDS, "VOLTIX_MAX_RUN_SECONDS"),
                   max_iteration_seconds=_parse_limit(e.get("VOLTIX_MAX_ITERATION_SECONDS"), DEFAULT_MAX_ITERATION_SECONDS,
                                                      "VOLTIX_MAX_ITERATION_SECONDS"))

    def to_dict(self) -> dict[str, Optional[float]]:
        return {"max_run_seconds": self.max_run_seconds, "max_iteration_seconds": self.max_iteration_seconds}


AbortCheck = Callable[[], None]


class RunGuard:
    """Raises ``RunAborted`` when the token is set or a limit is exceeded. Cheap enough to call per token."""

    def __init__(self, token: Optional[CancelToken], limits: RunLimits, clock: Callable[[], float] = time.monotonic) -> None:
        self.token, self.limits, self._clock = token, limits, clock
        self._run_start = clock()
        self._iter_start: Optional[float] = None
        self.where = "starting"

    def begin_iteration(self, where: str) -> None:
        self._iter_start = self._clock()
        self.where = where

    def end_iteration(self) -> None:
        self._iter_start = None

    def elapsed(self) -> float:
        return self._clock() - self._run_start

    def __call__(self) -> None:
        if self.token is not None and self.token.cancelled:
            raise RunAborted("cancelled", f"Cancelled on request during {self.where}, {self.elapsed():.1f} s into the run.")
        now = self._clock()
        lim = self.limits
        if lim.max_run_seconds is not None and now - self._run_start > lim.max_run_seconds:
            raise RunAborted("timed_out", f"Stopped: the run exceeded its {lim.max_run_seconds:g} s time limit during {self.where}. "
                                          "Raise VOLTIX_MAX_RUN_SECONDS (or the --max-run-seconds option) or reduce the workload.")
        if lim.max_iteration_seconds is not None and self._iter_start is not None and now - self._iter_start > lim.max_iteration_seconds:
            raise RunAborted("timed_out", f"Stopped: one iteration exceeded its {lim.max_iteration_seconds:g} s limit ({self.where}). "
                                          "Raise VOLTIX_MAX_ITERATION_SECONDS (or --max-iteration-seconds) or reduce batch size / output tokens.")
