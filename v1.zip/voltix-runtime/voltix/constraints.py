"""Customer-defined requirements (latency / throughput / memory limits) checked against saved runs.

Rules:
- A limit is checked only against a statistic the run actually supports (p95 needs >= 20 iterations; see metrics.py).
- Memory limits are checked only against comparable memory (GPU tensors, or the analytic estimate of a simulated run).
  CPU process RSS is never compared with a device-memory limit.
- A run is ELIGIBLE only if every set limit was assessed and passed. A limit that could not be assessed makes the run
  UNKNOWN, never eligible.
- Runs are only ranked against alternatives with the same data source, model and prompt/output length. Simulated and
  measured runs are never ranked together, and nothing is extrapolated to workloads or hardware that were not run.
- A pass within MARGIN_PCT of its limit is flagged as marginal: run-to-run noise can flip it.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Sequence

from .metrics import metric_value, unsupported_reason
from .optimize import comparable_memory
from .schemas import BenchmarkRun, DataSource, Recommendation, RunStatus, Severity

MARGIN_PCT = 5.0


class Verdict(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    NOT_ASSESSED = "not_assessed"


class Eligibility(str, Enum):
    ELIGIBLE = "eligible"
    VIOLATES = "violates"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class Constraints:
    max_latency_p95_ms: Optional[float] = None
    max_ttft_ms: Optional[float] = None  # mean time to first token
    min_throughput_tokens_per_s: Optional[float] = None
    max_memory_gb: Optional[float] = None

    def __post_init__(self) -> None:
        for name, v in self.items():
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0:
                raise ValueError(f"{name} must be a positive number or unset (got {v!r}).")

    def items(self) -> list[tuple[str, float]]:
        return [(k, v) for k, v in self.__dict__.items() if v is not None]

    @property
    def empty(self) -> bool:
        return not self.items()


@dataclass(frozen=True)
class ConstraintResult:
    name: str
    label: str
    unit: str
    limit: float
    measured: Optional[float]
    verdict: Verdict
    reason: str  # why it passed/failed/could not be assessed
    marginal: bool = False


@dataclass
class RunEvaluation:
    run: BenchmarkRun
    results: list[ConstraintResult] = field(default_factory=list)

    @property
    def eligibility(self) -> Eligibility:
        if any(r.verdict == Verdict.FAIL for r in self.results):
            return Eligibility.VIOLATES
        if not self.results or any(r.verdict == Verdict.NOT_ASSESSED for r in self.results):
            return Eligibility.UNKNOWN
        return Eligibility.ELIGIBLE


def _check(name: str, label: str, unit: str, limit: float, value: Optional[float], upper: bool, why_missing: str) -> ConstraintResult:
    if value is None:
        return ConstraintResult(name, label, unit, limit, None, Verdict.NOT_ASSESSED, why_missing)
    ok = value <= limit if upper else value >= limit
    margin = abs(value - limit) / limit * 100.0
    word = "at most" if upper else "at least"
    return ConstraintResult(name, label, unit, limit, value, Verdict.PASS if ok else Verdict.FAIL,
                            f"measured {value:,.2f} {unit}; limit {word} {limit:,.2f} {unit}", marginal=ok and margin < MARGIN_PCT)


def evaluate(run: BenchmarkRun, constraints: Constraints) -> RunEvaluation:
    ev = RunEvaluation(run)
    if run.status != RunStatus.COMPLETED or run.metrics is None:
        for name, limit in constraints.items():
            ev.results.append(ConstraintResult(name, name, "", limit, None, Verdict.NOT_ASSESSED, f"the run did not complete ({run.status.value})"))
        return ev
    m = run.metrics
    c = constraints
    if c.max_latency_p95_ms is not None:
        ev.results.append(_check("max_latency_p95_ms", "Latency p95", "ms", c.max_latency_p95_ms, metric_value(m, "latency_p95_ms"), True,
                                 unsupported_reason(m, "latency_p95_ms") or "not recorded"))
    if c.max_ttft_ms is not None:
        ev.results.append(_check("max_ttft_ms", "Time to first token (mean)", "ms", c.max_ttft_ms, metric_value(m, "ttft_mean_ms"), True, "not recorded"))
    if c.min_throughput_tokens_per_s is not None:
        ev.results.append(_check("min_throughput_tokens_per_s", "Throughput", "tok/s", c.min_throughput_tokens_per_s,
                                 metric_value(m, "throughput_tokens_per_s"), False, "not recorded"))
    if c.max_memory_gb is not None:
        value, reliable, note = comparable_memory(run)
        ev.results.append(_check("max_memory_gb", "Peak memory", "GB", c.max_memory_gb, value if reliable else None, True,
                                 note if not reliable else "not recorded"))
    return ev


@dataclass
class Selection:
    key: tuple  # (data_source, model_id, prompt_tokens, output_tokens)
    data_source: str
    evaluations: list[RunEvaluation]  # ranked: eligible (best first), unknown, violates
    best: Optional[RunEvaluation]
    note: str


OBJECTIVES = {"throughput": ("throughput_tokens_per_s", False), "latency_p95": ("latency_p95_ms", True), "memory": ("peak_memory_gb", True)}


def select(runs: Sequence[BenchmarkRun], constraints: Constraints, objective: str = "throughput") -> list[Selection]:
    """Group comparable runs and pick, per group, the best ELIGIBLE run by the objective. Never mixes data sources."""
    if objective not in OBJECTIVES:
        raise ValueError(f"unknown objective {objective!r}")
    if constraints.empty:
        raise ValueError("Set at least one requirement first.")
    key_metric, lower_better = OBJECTIVES[objective]
    groups: dict[tuple, list[RunEvaluation]] = {}
    for r in runs:
        if r.status != RunStatus.COMPLETED or r.metrics is None:
            continue
        k = (r.data_source.value, r.config.model_id, r.config.prompt_tokens, r.config.output_tokens)
        groups.setdefault(k, []).append(evaluate(r, constraints))
    out: list[Selection] = []
    for k, evs in sorted(groups.items()):
        def score(e: RunEvaluation) -> float:
            v = metric_value(e.run.metrics, key_metric)
            return math.inf if v is None else (v if lower_better else -v)
        order = {Eligibility.ELIGIBLE: 0, Eligibility.UNKNOWN: 1, Eligibility.VIOLATES: 2}
        evs.sort(key=lambda e: (order[e.eligibility], score(e)))
        best = evs[0] if evs[0].eligibility == Eligibility.ELIGIBLE and score(evs[0]) != math.inf else None
        if k[0] == DataSource.SIMULATED.value:
            note = "SIMULATED runs: illustrative only. Re-run on real hardware before choosing anything."
        elif best is None:
            note = "No saved measured run satisfies every requirement. This does not show that no configuration can; only the runs saved here were tried."
        else:
            note = ("Best of the saved runs that meet every requirement. Other configurations, batch sizes or devices were not measured"
                    + (", and at least one limit is met by a thin margin" if any(r.marginal for r in best.results) else "") + ".")
        out.append(Selection(k, k[0], evs, best, note))
    return out


def constraint_recommendations(run: BenchmarkRun, constraints: Constraints) -> list[Recommendation]:
    if constraints.empty:
        return []
    ev = evaluate(run, constraints)
    basis = run.data_source.value
    recs: list[Recommendation] = []
    for r in ev.results:
        if r.verdict == Verdict.FAIL:
            recs.append(Recommendation(
                rule_id="requirement-violated", title=f"{r.label} requirement not met", severity=Severity.WARNING, summary=r.reason,
                evidence=[r.reason], action="Try a different configuration (batch size, precision, device) and measure again; "
                "no change is predicted to fix this.", how_to_verify="Run the alternative and compare it to the same limit.",
                basis=basis, kind="observation"))
        elif r.verdict == Verdict.NOT_ASSESSED:
            recs.append(Recommendation(
                rule_id="requirement-not-assessed", title=f"{r.label} requirement could not be checked", severity=Severity.INFO,
                summary=r.reason, evidence=[r.reason], action="Collect the missing evidence before relying on this run for that requirement.",
                how_to_verify="Re-run with enough iterations / on a device with comparable memory reporting.", basis=basis, kind="caveat"))
        elif r.marginal:
            recs.append(Recommendation(
                rule_id="requirement-marginal", title=f"{r.label} passes by a thin margin", severity=Severity.INFO, summary=r.reason,
                evidence=[r.reason], action="Repeat the run to see whether it stays within the limit.",
                how_to_verify=f"Repeat at least twice; a pass within {MARGIN_PCT:.0f}% of the limit can flip with noise.", basis=basis, kind="caveat"))
    return recs
