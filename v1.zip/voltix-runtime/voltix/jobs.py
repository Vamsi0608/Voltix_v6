"""Background benchmark jobs: one at a time, cancellable, observable from any thread.

A benchmark runs on its own thread so the interface stays responsive and can offer Cancel. Only ONE job may run
at a time in the whole process: two concurrent benchmarks compete for the same CPU/GPU and distort each other's
timings, so refusing the second is a correctness rule, not a convenience.

This module knows nothing about Streamlit; the page polls ``Job.snapshot()``.
"""

from __future__ import annotations

import logging
import threading
import time
import traceback
from dataclasses import dataclass
from typing import Optional

from .backends import BackendError, BackendNotImplemented, BackendUnavailable
from .control import CancelToken, RunLimits
from .runner import run_benchmark
from .schemas import BenchmarkConfig, BenchmarkRun
from .validation import ValidationError

log = logging.getLogger("voltix.jobs")


class JobBusy(RuntimeError):
    """Another benchmark is already running."""


@dataclass(frozen=True)
class JobSnapshot:
    job_id: str
    name: str
    state: str  # "running" | "finished"
    done: int
    total: int
    label: str
    elapsed_s: float
    cancel_requested: bool
    run: Optional[BenchmarkRun]
    error: Optional[str]  # set when no run could be produced (invalid config, missing dependencies, unexpected error)


class Job:
    def __init__(self, job_id: str, config: BenchmarkConfig, name: Optional[str], limits: RunLimits) -> None:
        self.job_id, self.config, self.name, self.limits = job_id, config, name or "", limits
        self.token = CancelToken()
        self._lock = threading.Lock()
        self._done, self._total, self._label = 0, config.warmup_iterations + config.iterations, "starting"
        self._run: Optional[BenchmarkRun] = None
        self._error: Optional[str] = None
        self._finished = False
        self._started = time.monotonic()
        self._ended: Optional[float] = None
        self.thread = threading.Thread(target=self._work, name=f"voltix-job-{job_id}", daemon=True)

    def _progress(self, done: int, total: int, label: str) -> None:
        with self._lock:
            self._done, self._total, self._label = done, total, label

    def _work(self) -> None:
        log.info("job %s started: backend=%s model=%s precision=%s iterations=%d+%d", self.job_id, self.config.backend,
                 self.config.model_id, self.config.precision.value, self.config.warmup_iterations, self.config.iterations)
        try:
            run = run_benchmark(self.config, self.name or None, progress=self._progress, cancel=self.token, limits=self.limits)
            with self._lock:
                self._run = run
            log.info("job %s finished: status=%s", self.job_id, run.status.value)
        except ValidationError as exc:
            self._fail("; ".join(exc.errors))
        except (BackendNotImplemented, BackendUnavailable, BackendError) as exc:
            self._fail(str(exc))
        except BaseException as exc:  # noqa: BLE001 - a background thread must never die silently
            log.error("benchmark job %s crashed:\n%s", self.job_id, traceback.format_exc())
            self._fail(f"Unexpected error ({type(exc).__name__}): {str(exc)[:300]}. Details are in the application log.")
        finally:
            with self._lock:
                self._finished = True
                self._ended = time.monotonic()

    def _fail(self, message: str) -> None:
        log.warning("job %s failed before producing a run: %s", self.job_id, message[:300])
        with self._lock:
            self._error = message

    def cancel(self) -> None:
        log.info("job %s: cancel requested", self.job_id)
        self.token.cancel()

    def snapshot(self) -> JobSnapshot:
        with self._lock:
            end = self._ended if self._ended is not None else time.monotonic()
            return JobSnapshot(self.job_id, self.name, "finished" if self._finished else "running", self._done, self._total,
                               self._label, end - self._started, self.token.cancelled, self._run, self._error)

    @property
    def running(self) -> bool:
        with self._lock:
            return not self._finished


class JobManager:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._current: Optional[Job] = None
        self._counter = 0

    def start(self, config: BenchmarkConfig, name: Optional[str] = None, limits: Optional[RunLimits] = None) -> Job:
        limits = limits if limits is not None else RunLimits.from_env()
        with self._lock:
            if self._current is not None and self._current.running:
                raise JobBusy("A benchmark is already running. Only one runs at a time because concurrent runs would distort "
                              "each other's timings. Wait for it to finish, or cancel it.")
            self._counter += 1
            job = Job(f"job{self._counter}", config, name, limits)
            self._current = job
        job.thread.start()
        return job

    def current(self) -> Optional[Job]:
        with self._lock:
            return self._current

    def get(self, job_id: str) -> Optional[Job]:
        job = self.current()
        return job if job is not None and job.job_id == job_id else None


_MANAGER = JobManager()


def manager() -> JobManager:
    return _MANAGER
