"""Host memory helpers. GB means 10^9 bytes.

Linux uses /proc. Windows uses kernel32/psapi through ctypes. macOS uses ``sysctl``, ``ps`` and ``resource``.
Every function returns None (never a guess) when its platform source is unavailable. The Windows and macOS
paths could not be run in the environment this was built in; they are covered only by structure-size and
fallback-logic tests, so treat those platforms' memory figures as unverified until checked on a real machine.
"""

from __future__ import annotations

import os
import subprocess
import sys
from typing import Optional

_PROC_STATUS = "/proc/self/status"
_PROC_STATM = "/proc/self/statm"
_PROC_CLEAR_REFS = "/proc/self/clear_refs"


def _is_windows() -> bool:
    return sys.platform.startswith("win")


def _run(*cmd: str) -> Optional[str]:
    try:
        import subprocess

        out = subprocess.run(cmd, capture_output=True, text=True, timeout=5, check=False)
        return out.stdout.strip() if out.returncode == 0 else None
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


# ---- Windows (ctypes) ---------------------------------------------------------------------------

def _win_structs():
    import ctypes
    from ctypes import wintypes

    class MemoryStatusEx(ctypes.Structure):
        _fields_ = [("dwLength", ctypes.c_uint32), ("dwMemoryLoad", ctypes.c_uint32),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

    class ProcessMemoryCounters(ctypes.Structure):
        _fields_ = [("cb", ctypes.c_uint32), ("PageFaultCount", ctypes.c_uint32),
                    ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]

    return MemoryStatusEx, ProcessMemoryCounters


def _win_memory_status() -> Optional[object]:
    try:
        import ctypes

        status_cls, _ = _win_structs()
        st = status_cls()
        st.dwLength = ctypes.sizeof(st)
        return st if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)) else None  # type: ignore[attr-defined]
    except (OSError, AttributeError, ImportError, ValueError):
        return None


def _win_process_counters() -> Optional[object]:
    try:
        import ctypes
        from ctypes import wintypes

        _, pmc_cls = _win_structs()
        pmc = pmc_cls()
        pmc.cb = ctypes.sizeof(pmc)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
        psapi = ctypes.WinDLL("psapi", use_last_error=True)  # type: ignore[attr-defined]
        kernel32.GetCurrentProcess.restype = wintypes.HANDLE
        psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(pmc_cls), wintypes.DWORD]
        psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
        ok = psapi.GetProcessMemoryInfo(kernel32.GetCurrentProcess(), ctypes.byref(pmc), pmc.cb)
        return pmc if ok else None
    except (OSError, AttributeError, ImportError, ValueError):
        return None


# ---- public API -----------------------------------------------------------------------------------

def total_ram_gb() -> Optional[float]:
    if _is_windows():
        st = _win_memory_status()
        return st.ullTotalPhys / 1e9 if st is not None else None  # type: ignore[attr-defined]
    try:
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1e9
    except (ValueError, OSError, AttributeError):
        pass
    if sys.platform == "darwin":
        out = _run("sysctl", "-n", "hw.memsize")
        try:
            return int(out) / 1e9 if out else None
        except ValueError:
            return None
    return None


def available_ram_gb() -> Optional[float]:
    """Memory the OS says can be handed to a new process without swapping (None when unknown)."""
    if _is_windows():
        st = _win_memory_status()
        return st.ullAvailPhys / 1e9 if st is not None else None  # type: ignore[attr-defined]
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) * 1024 / 1e9
    except (OSError, ValueError, IndexError):
        pass
    return None


def current_rss_gb() -> Optional[float]:
    if _is_windows():
        pmc = _win_process_counters()
        return pmc.WorkingSetSize / 1e9 if pmc is not None else None  # type: ignore[attr-defined]
    try:
        with open(_PROC_STATM) as f:
            pages = int(f.read().split()[1])
        return pages * os.sysconf("SC_PAGE_SIZE") / 1e9
    except (OSError, ValueError, IndexError, AttributeError):
        pass
    if sys.platform == "darwin":
        out = _run("ps", "-o", "rss=", "-p", str(os.getpid()))
        try:
            return int(out) * 1024 / 1e9 if out else None
        except ValueError:
            return None
    return None


def reset_peak_rss() -> bool:  # Linux only; Windows/macOS have no equivalent, so their peak is process-lifetime
    """Reset the kernel's peak-RSS counter so the next peak reflects only what follows.

    Returns False when unsupported (non-Linux, restricted /proc); the peak is then
    the process-lifetime peak, which callers must disclose.
    """
    try:
        with open(_PROC_CLEAR_REFS, "w") as f:
            f.write("5")
        return True
    except OSError:
        return False


def peak_rss_gb() -> Optional[float]:
    if _is_windows():
        pmc = _win_process_counters()
        return pmc.PeakWorkingSetSize / 1e9 if pmc is not None else None  # type: ignore[attr-defined]
    try:
        with open(_PROC_STATUS) as f:
            for line in f:
                if line.startswith("VmHWM:"):
                    return int(line.split()[1]) * 1024 / 1e9
    except (OSError, ValueError, IndexError):
        pass
    try:
        import resource  # POSIX only

        raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return (raw if sys.platform == "darwin" else raw * 1024) / 1e9
    except (ImportError, OSError, ValueError):
        return None


def cpu_model_name() -> str:
    if _is_windows():
        try:
            import winreg  # type: ignore[import-not-found]

            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as key:
                name = str(winreg.QueryValueEx(key, "ProcessorNameString")[0]).strip()
                if name:
                    return name
        except (OSError, ImportError):
            pass
    elif sys.platform == "darwin":
        brand = _run("sysctl", "-n", "machdep.cpu.brand_string")
        if brand:
            return brand
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.lower().startswith("model name"):
                    return line.split(":", 1)[1].strip()
    except OSError:
        pass
    import platform

    return platform.processor() or platform.machine() or "unknown CPU"
