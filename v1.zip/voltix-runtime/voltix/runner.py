"""Benchmark runner: backend-agnostic orchestration.

The runner validates the config, drives warmup and measured iterations, turns
samples into metrics, and tags the result with the correct ``DataSource``.
"""

from __future__ import annotations

import dataclasses
import time
import uuid
from datetime import datetime, timezone
from typing import Callable, Optional

from . import __version__
from .backends import BackendError, create_backend
from .control import CancelToken, RunAborted, RunGuard, RunLimits
from .metrics import compute_metrics
from .schemas import (
    BenchmarkConfig,
    BenchmarkRun,
    DataSource,
    RequestSample,
    RunStatus,
)
from .validation import ensure_valid, sanitize_name

ProgressCallback = Callable[[int, int, str], None]


def new_run_id() -> str:
    return f"run_{uuid.uuid4().hex[:10]}"


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


PROCEDURE_VERSION = 1


def measurement_procedure(config: BenchmarkConfig, limits: RunLimits, *, started_at: str, finished_at: str, wall_clock_s: float,
                          simulated: bool, iterations_done: int, total_steps: int) -> dict:
    """The fixed measurement recipe applied to a run, recorded with the result so two runs can be judged comparable.

    Describes what the runner did (see MEASUREMENT.md); it is not a claim about hardware state the runner cannot observe
    (clock speeds, thermal state, other processes).
    """
    return {
        "procedure_version": PROCEDURE_VERSION,
        "voltix_version": __version__,
        "started_at": started_at,
        "finished_at": finished_at,
        "wall_clock_s": round(wall_clock_s, 3),
        "warmup_iterations": config.warmup_iterations,
        "measured_iterations": config.iterations,
        "iterations_completed": iterations_done,
        "iterations_planned": total_steps,
        "order": "model loaded once per run; warm-up iterations first (discarded); then measured iterations, one at a time",
        "inputs": "synthetic, seeded; identical for every iteration of a run" if not simulated else "none (analytic model)",
        "seed": config.seed,
        "limits": limits.to_dict(),
        "executed": not simulated,
    }


def run_benchmark(
    config: BenchmarkConfig,
    name: str | None = None,
    *,
    tags: Optional[list[str]] = None,
    progress: Optional[ProgressCallback] = None,
    cancel: Optional[CancelToken] = None,
    limits: Optional[RunLimits] = None,
) -> BenchmarkRun:
    """Run a benchmark and return the result (NOT yet persisted).

    Raises ``ValidationError`` for an invalid config, ``BackendNotImplemented`` for
    placeholder backends and ``BackendUnavailable`` when a backend's dependencies are
    missing (nothing is measured in those cases, so no run is created). Recoverable backend problems
    such as (simulated) out-of-memory produce a ``FAILED`` run with an error message.

    ``cancel`` and ``limits`` (default: ``RunLimits.from_env()``) stop the run cooperatively; a stopped run is
    returned with status ``CANCELLED`` or ``TIMED_OUT``, an explanatory ``error``, and no samples or metrics
    (see ``voltix.control`` for the safe points and what cannot be interrupted).
    """
    ensure_valid(config)
    backend = create_backend(config.backend)  # raises BackendNotImplemented if not real yet
    data_source = DataSource.SIMULATED if backend.is_simulated else DataSource.MEASURED

    run = BenchmarkRun(
        run_id=new_run_id(),
        name=sanitize_name(name, default=f"{config.model_id} {config.precision.value}"),
        created_at=utc_now_iso(),
        status=RunStatus.COMPLETED,
        data_source=data_source,
        backend=config.backend,
        config=config,
        tags=list(tags or []),
        voltix_version=__version__,
    )

    total_steps = config.warmup_iterations + config.iterations
    started_at = utc_now_iso()
    t_start = time.monotonic()
    limits = limits if limits is not None else RunLimits.from_env()
    guard = RunGuard(cancel, limits)
    backend.set_abort_check(guard)
    phase = {"done": 0, "label": "loading model"}

    def report(done: int, label: str) -> None:
        if progress is not None:
            progress(done, total_steps, label)

    try:
        report(0, "loading model")
        guard.where = "model loading"
        guard()
        backend.load(config)
        guard.where = "after model loading"
        guard()
        resolved = backend.resolved_hardware_id()
        if resolved and resolved != config.hardware_id:
            run.config = dataclasses.replace(config, hardware_id=resolved)  # record the device actually used
        done = 0
        for i in range(config.warmup_iterations):
            guard.begin_iteration(f"warm-up iteration {i + 1} of {config.warmup_iterations}")
            guard()
            backend.run_iteration(config, i, warmup=True)
            guard.end_iteration()
            done += 1
            phase.update(done=done, label="warmup")
            report(done, "warmup")

        samples: list[RequestSample] = []
        for i in range(config.iterations):
            guard.begin_iteration(f"measured iteration {i + 1} of {config.iterations}")
            guard()
            samples.append(backend.run_iteration(config, i, warmup=False))
            guard.end_iteration()
            done += 1
            phase.update(done=done, label="measuring")
            report(done, "measuring")

        run.samples = samples
        run.metrics = compute_metrics(
            samples,
            peak_memory_gb=backend.peak_memory_gb(),
            device_memory_gb=backend.device_memory_gb(),
        )
        run.environment = backend.environment()
    except RunAborted as exc:
        run.status = RunStatus.CANCELLED if exc.kind == "cancelled" else RunStatus.TIMED_OUT
        run.samples, run.metrics = [], None
        run.error = (f"{exc.reason} {phase['done']} of {total_steps} iterations (warm-up included) had finished. "
                     "A stopped run has no metrics and is never compared.")
        run.environment = backend.environment()
    except BackendError as exc:
        run.status = RunStatus.FAILED
        run.error = str(exc)
        run.environment = backend.environment()
    finally:
        backend.unload()

    run.environment = {**(run.environment or {}), "procedure": measurement_procedure(
        config, limits, started_at=started_at, finished_at=utc_now_iso(), wall_clock_s=time.monotonic() - t_start,
        simulated=backend.is_simulated, iterations_done=phase["done"], total_steps=total_steps)}
    return run
