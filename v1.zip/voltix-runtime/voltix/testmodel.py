"""Create a tiny, randomly initialised causal LM on local disk.

PURPOSE: exercise the real inference pipeline (load, generate, timing, memory)
without downloading anything. The weights are random, so the model produces
meaningless text and its speed says nothing about real models. Never present
runs of this model as representative performance.
"""

from __future__ import annotations

from pathlib import Path

DEFAULT_TINY_MODEL_DIR = Path(__file__).resolve().parent.parent / "data" / "models" / "voltix-tiny-random"

README_TEXT = (
    "This is a TINY RANDOMLY INITIALISED model created by VOLTIX Runtime for pipeline testing.\n"
    "It has no trained knowledge. Do not use it to judge real model performance or quality.\n"
)


def create_tiny_model(path: str | Path = DEFAULT_TINY_MODEL_DIR, *, seed: int = 0, vocab_size: int = 2048,
                      hidden_size: int = 64, layers: int = 2, heads: int = 4, kv_heads: int = 2,
                      max_positions: int = 512) -> Path:
    """Build and save the model (needs torch + transformers). Returns the folder."""
    import torch
    from transformers import AutoModelForCausalLM, LlamaConfig

    out = Path(path)
    out.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(seed)
    cfg = LlamaConfig(vocab_size=vocab_size, hidden_size=hidden_size, intermediate_size=hidden_size * 2,
                      num_hidden_layers=layers, num_attention_heads=heads, num_key_value_heads=kv_heads,
                      max_position_embeddings=max_positions)
    AutoModelForCausalLM.from_config(cfg).save_pretrained(out)
    (out / "README.txt").write_text(README_TEXT)
    return out
