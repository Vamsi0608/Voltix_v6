"""Seeded bootstrap statistics for comparing benchmark runs.

Every number the optimization engine reports about a *difference* comes from here: a percent
change with a 95% bootstrap confidence interval, and a verdict that says "improved" or
"regressed" only when the interval excludes zero AND the change is at least the minimum
effect size. Nothing here predicts anything; it only describes samples that were measured.

The bootstrap resamples each configuration's per-iteration samples independently, so the
interval reflects iteration-to-iteration noise within a run. It cannot see variation BETWEEN
runs (thermal state, background load); ``voltix.optimize.replicate_noise`` measures that
separately from replicate runs.

Statistic functions take a 2-D array of resamples (one row per resample) and reduce along
axis 1, so thousands of resamples are computed in one vectorised call.
"""

from __future__ import annotations

import zlib
from dataclasses import dataclass, field
from typing import Callable, Optional, Sequence

import numpy as np

DEFAULT_RESAMPLES = 2000
DEFAULT_CONFIDENCE = 0.95
DEFAULT_MIN_EFFECT_PCT = 2.0  # smaller changes are not treated as practically meaningful
MIN_BOOTSTRAP_SAMPLES = 5  # fewer iterations per run than this: no interval is attempted

VERDICTS = ("improved", "regressed", "negligible", "no_detectable_change", "not_assessed")

StatFn = Callable[[np.ndarray], np.ndarray]


def stable_seed(*parts: object) -> int:
    """Deterministic across processes and sessions (unlike ``hash``), so results are reproducible."""
    return zlib.crc32("|".join(str(p) for p in parts).encode("utf-8"))


@dataclass(frozen=True)
class ChangeEstimate:
    """Percent change of a candidate relative to a baseline, with its bootstrap interval.

    ``ratio_samples`` holds candidate/baseline for every resample, so quantities derived from the
    ratio (cost = price ratio / throughput ratio) can reuse the same resamples instead of
    inventing a second source of randomness.
    """

    change_pct: Optional[float]
    ci_low_pct: Optional[float]
    ci_high_pct: Optional[float]
    confidence: float
    n_resamples: int
    ratio_samples: Optional[np.ndarray] = field(default=None, repr=False, compare=False)

    @property
    def has_interval(self) -> bool:
        return self.ci_low_pct is not None and self.ci_high_pct is not None


# ---- statistics over resample matrices -----------------------------------------------------

def stat_mean(a: np.ndarray) -> np.ndarray:
    return a.mean(axis=1)


def stat_percentile(q: float) -> StatFn:
    """Linear-interpolated percentile (same definition as ``voltix.metrics.percentile``)."""
    return lambda a: np.percentile(a, q, axis=1)


# ---- bootstrap -----------------------------------------------------------------------------------

def bootstrap_ratio(
    base: Sequence[float] | np.ndarray,
    cand: Sequence[float] | np.ndarray,
    stat_base: StatFn,
    stat_cand: Optional[StatFn] = None,
    *,
    tag: str = "",
    resamples: int = DEFAULT_RESAMPLES,
    confidence: float = DEFAULT_CONFIDENCE,
) -> ChangeEstimate:
    """Percent change of ``stat(cand)`` vs ``stat(base)`` with a percentile-bootstrap interval.

    ``tag`` seeds the random generator, so the same pair of runs always yields the same interval.
    The point estimate always comes from the real samples, never from the resamples. With fewer
    than ``MIN_BOOTSTRAP_SAMPLES`` samples in either run the point estimate is returned without an
    interval rather than a misleadingly narrow one.
    """
    b = np.asarray(base, dtype=float)
    c = np.asarray(cand, dtype=float)
    if b.size == 0 or c.size == 0:
        raise ValueError("bootstrap_ratio() requires at least one sample per run")
    stat_cand = stat_cand or stat_base
    b_point = float(stat_base(b[None, :])[0])
    c_point = float(stat_cand(c[None, :])[0])
    if not np.isfinite(b_point) or not np.isfinite(c_point) or b_point == 0:
        return ChangeEstimate(None, None, None, confidence, 0)
    change = (c_point / b_point - 1.0) * 100.0
    if min(b.size, c.size) < MIN_BOOTSTRAP_SAMPLES:
        return ChangeEstimate(change, None, None, confidence, 0)

    rng = np.random.default_rng(stable_seed(tag))
    b_stats = stat_base(b[rng.integers(0, b.size, size=(resamples, b.size))])
    c_stats = stat_cand(c[rng.integers(0, c.size, size=(resamples, c.size))])
    ok = np.isfinite(b_stats) & np.isfinite(c_stats) & (b_stats != 0)
    ratios = c_stats[ok] / b_stats[ok]
    if ratios.size < max(10, resamples // 2):
        return ChangeEstimate(change, None, None, confidence, int(ratios.size))
    tail = (1.0 - confidence) / 2.0
    lo, hi = np.quantile(ratios, [tail, 1.0 - tail])
    return ChangeEstimate(change, (float(lo) - 1.0) * 100.0, (float(hi) - 1.0) * 100.0, confidence,
                          int(ratios.size), ratios)


# ---- verdicts ------------------------------------------------------------------------------------

def classify_change(est: ChangeEstimate, higher_is_better: bool,
                    min_effect_pct: float = DEFAULT_MIN_EFFECT_PCT) -> str:
    """Verdict for a metric that has a bootstrap interval.

    improved / regressed:  the interval excludes zero and the point estimate is at least
                           ``min_effect_pct`` in that direction.
    negligible:            the whole interval lies within +/- ``min_effect_pct``: a real null
                           result, not a lack of data.
    no_detectable_change:  anything else: the data cannot separate the change from noise.
    not_assessed:          no interval could be estimated (too few iterations).
    """
    if est.change_pct is None or not est.has_interval:
        return "not_assessed"
    point, low, high = est.change_pct, est.ci_low_pct, est.ci_high_pct
    if low > -min_effect_pct and high < min_effect_pct:
        return "negligible"
    if low > 0 and point >= min_effect_pct:
        return "improved" if higher_is_better else "regressed"
    if high < 0 and point <= -min_effect_pct:
        return "regressed" if higher_is_better else "improved"
    return "no_detectable_change"


def classify_scalar_change(change_pct: Optional[float], higher_is_better: bool,
                           min_effect_pct: float = DEFAULT_MIN_EFFECT_PCT) -> str:
    """Verdict for a metric with ONE value per run (e.g. peak GPU memory): no interval exists."""
    if change_pct is None:
        return "not_assessed"
    if abs(change_pct) < min_effect_pct:
        return "negligible"
    return "improved" if (change_pct > 0) == higher_is_better else "regressed"


# ---- run quality ---------------------------------------------------------------------------------

def coefficient_of_variation(values: Sequence[float]) -> Optional[float]:
    """Sample standard deviation divided by the mean. None when it is undefined."""
    a = np.asarray(values, dtype=float)
    if a.size < 2:
        return None
    mean = float(a.mean())
    return float(a.std(ddof=1)) / mean if mean > 0 else None


def lag1_autocorrelation(values: Sequence[float]) -> Optional[float]:
    """Correlation between consecutive iterations. Values far from 0 mean the run drifts
    (thermal throttling, caching), which makes a bootstrap that assumes independence too optimistic."""
    a = np.asarray(values, dtype=float)
    if a.size < 4:
        return None
    d = a - a.mean()
    denom = float((d * d).sum())
    return float((d[:-1] * d[1:]).sum()) / denom if denom > 0 else None
