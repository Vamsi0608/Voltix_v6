"""Analytic memory and timing model.

This is a first-order roofline-style estimate, NOT a measurement. It is used
(1) by the simulated backend to generate demo data and (2) by the recommendation
engine to reason about memory composition. Every constant is an assumption and
is listed in ``ASSUMPTIONS`` so the UI can display it.
"""

from __future__ import annotations

from dataclasses import dataclass

from .schemas import HardwareProfile, ModelProfile, Precision

BYTES_PER_PARAM: dict[Precision, float] = {
    Precision.FP32: 4.0,
    Precision.FP16: 2.0,
    Precision.BF16: 2.0,
    Precision.INT8: 1.0,
    Precision.INT4: 0.5,
}

# KV cache is assumed to stay in fp16 when weights are quantized.
KV_BYTES: dict[Precision, float] = {
    Precision.FP32: 4.0,
    Precision.FP16: 2.0,
    Precision.BF16: 2.0,
    Precision.INT8: 2.0,
    Precision.INT4: 2.0,
}

# Relative compute throughput vs fp16 tensor-core peak.
COMPUTE_FACTOR: dict[Precision, float] = {
    Precision.FP32: 0.25,
    Precision.FP16: 1.0,
    Precision.BF16: 1.0,
    Precision.INT8: 1.0,
    Precision.INT4: 1.0,
}

# Achieved fraction of peak memory bandwidth (dequantization costs efficiency).
BANDWIDTH_EFFICIENCY: dict[Precision, float] = {
    Precision.FP32: 0.70,
    Precision.FP16: 0.70,
    Precision.BF16: 0.70,
    Precision.INT8: 0.60,
    Precision.INT4: 0.50,
}

PREFILL_MFU = 0.45
DECODE_MFU = 0.30
KERNEL_LAUNCH_MS_PER_LAYER = 0.03
PREFILL_FIXED_OVERHEAD_MS = 8.0
RUNTIME_OVERHEAD_GB = 0.8
RUNTIME_OVERHEAD_WEIGHT_FRACTION = 0.05

ASSUMPTIONS: dict[str, str] = {
    "Memory model": (
        "weights = params x bytes/param; KV cache = 2 x layers x kv_heads x head_dim x "
        "tokens x batch x 2 bytes (fp16; 4 for fp32); runtime overhead = "
        f"{RUNTIME_OVERHEAD_GB} GB + {int(RUNTIME_OVERHEAD_WEIGHT_FRACTION * 100)}% of weights."
    ),
    "Prefill time": (
        f"2 x params x batch x prompt tokens / (peak fp16 TFLOPS x {PREFILL_MFU} MFU x precision "
        f"factor) + {PREFILL_FIXED_OVERHEAD_MS} ms fixed overhead."
    ),
    "Decode step time": (
        "max(memory time, compute time) + per-layer launch overhead. Memory time = (weights + KV "
        "bytes read) / (peak bandwidth x precision efficiency). "
        f"Compute uses {DECODE_MFU} MFU."
    ),
    "Precision factors": (
        "fp32 compute at 0.25x of fp16 peak; int8/int4 are weight-only (fp16 compute) with "
        "bandwidth efficiency 0.60 / 0.50 vs 0.70 for fp16."
    ),
    "Run-to-run noise": (
        "Seeded log-normal jitter (~3-4%), ~3% chance of a 1.4-2.2x latency spike, and a "
        "1.8x cold-start penalty on the first iteration when no warmup is configured."
    ),
    "Hardware specs": "Rounded, approximate public specs. Real kernels, batching and drivers differ.",
}


@dataclass(frozen=True)
class MemoryBreakdown:
    weights_gb: float
    kv_cache_gb: float
    overhead_gb: float

    @property
    def total_gb(self) -> float:
        return self.weights_gb + self.kv_cache_gb + self.overhead_gb


def kv_bytes_per_token(model: ModelProfile, precision: Precision) -> float:
    head_dim = model.hidden_size / model.num_attention_heads
    return 2.0 * model.num_layers * model.num_kv_heads * head_dim * KV_BYTES[precision]


def memory_breakdown(
    model: ModelProfile,
    precision: Precision,
    batch_size: int,
    prompt_tokens: int,
    output_tokens: int,
) -> MemoryBreakdown:
    weights_gb = model.params_billion * BYTES_PER_PARAM[precision]
    tokens = batch_size * (prompt_tokens + output_tokens)
    kv_gb = tokens * kv_bytes_per_token(model, precision) / 1e9
    overhead = RUNTIME_OVERHEAD_GB + RUNTIME_OVERHEAD_WEIGHT_FRACTION * weights_gb
    return MemoryBreakdown(weights_gb, kv_gb, overhead)


def prefill_ms(
    model: ModelProfile,
    hw: HardwareProfile,
    precision: Precision,
    batch_size: int,
    prompt_tokens: int,
) -> float:
    flops = 2.0 * model.params_billion * 1e9 * batch_size * prompt_tokens
    eff = hw.peak_tflops_fp16 * 1e12 * COMPUTE_FACTOR[precision] * PREFILL_MFU
    return flops / eff * 1e3 + PREFILL_FIXED_OVERHEAD_MS + model.num_layers * KERNEL_LAUNCH_MS_PER_LAYER


def decode_step_ms(
    model: ModelProfile,
    hw: HardwareProfile,
    precision: Precision,
    batch_size: int,
    context_tokens: float,
) -> float:
    weight_bytes = model.params_billion * 1e9 * BYTES_PER_PARAM[precision]
    kv_read = batch_size * context_tokens * kv_bytes_per_token(model, precision)
    mem_s = (weight_bytes + kv_read) / (
        hw.memory_bandwidth_gbps * 1e9 * BANDWIDTH_EFFICIENCY[precision]
    )
    flops = 2.0 * model.params_billion * 1e9 * batch_size
    comp_s = flops / (hw.peak_tflops_fp16 * 1e12 * COMPUTE_FACTOR[precision] * DECODE_MFU)
    return max(mem_s, comp_s) * 1e3 + model.num_layers * KERNEL_LAUNCH_MS_PER_LAYER
