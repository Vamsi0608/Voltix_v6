"""VOLTIX Runtime: AI inference benchmarking and optimization."""

__version__ = "0.5.0"
APP_NAME = "VOLTIX Runtime"
