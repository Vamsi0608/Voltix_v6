"""Detect the local environment without importing heavy ML libraries."""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
from importlib import metadata
from typing import Any

PACKAGES = ["torch", "transformers", "accelerate", "bitsandbytes", "vllm", "streamlit", "plotly", "pandas", "numpy"]


def _package_version(name: str) -> str | None:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        return None


def detect_gpus(timeout_s: float = 5.0) -> dict[str, Any]:
    """Query nvidia-smi if present. Never raises."""
    exe = shutil.which("nvidia-smi")
    if exe is None:
        return {"available": False, "gpus": [], "detail": "nvidia-smi not found: no NVIDIA GPU or driver detected."}
    try:
        out = subprocess.run(
            [exe, "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=timeout_s, check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"available": False, "gpus": [], "detail": f"nvidia-smi failed: {exc}"}
    if out.returncode != 0:
        return {"available": False, "gpus": [], "detail": f"nvidia-smi exited with {out.returncode}: {out.stderr.strip()[:200]}"}
    gpus = []
    for line in out.stdout.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) == 3:
            try:
                mem_gb = round(float(parts[1]) / 1024.0, 1)
            except ValueError:
                mem_gb = None
            gpus.append({"name": parts[0], "memory_gb": mem_gb, "driver": parts[2]})
    return {"available": bool(gpus), "gpus": gpus, "detail": f"{len(gpus)} GPU(s) detected." if gpus else "No GPUs reported."}


from . import hostmem  # noqa: E402


def _ram_gb() -> float | None:
    value = hostmem.total_ram_gb()
    return round(value, 1) if value else None


def collect_system_info() -> dict[str, Any]:
    return {
        "os": f"{platform.system()} {platform.release()}",
        "machine": platform.machine(),
        "python": platform.python_version(),
        "cpu_count": os.cpu_count(),
        "ram_gb": _ram_gb(),
        "gpu": detect_gpus(),
        "packages": {name: _package_version(name) for name in PACKAGES},
    }
