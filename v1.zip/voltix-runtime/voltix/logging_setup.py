"""Application logging: rotating file + stderr, secrets redacted. Configure once, safe to call repeatedly."""

from __future__ import annotations

import logging
import logging.handlers
import os
from pathlib import Path

_MARK = "_voltix_handler"
DEFAULT_LOG_PATH = Path(__file__).resolve().parent.parent / "data" / "voltix.log"


class RedactSecrets(logging.Filter):
    """Defence in depth: if a secret value ever reaches a log message, it is replaced before being written."""

    def filter(self, record: logging.LogRecord) -> bool:
        secret = os.environ.get("VOLTIX_ACCESS_TOKEN")
        if secret and len(secret) >= 8:
            msg = record.getMessage()
            if secret in msg:
                record.msg, record.args = msg.replace(secret, "[redacted]"), None
        return True


def configure_logging(level: str | None = None, path: str | os.PathLike[str] | None = None) -> Path | None:
    """Attach handlers to the 'voltix' logger. Returns the log file path, or None if the file could not be opened
    (the app then logs to stderr only; logging problems must never stop the app)."""
    root = logging.getLogger("voltix")
    lvl = getattr(logging, (level or os.environ.get("VOLTIX_LOG_LEVEL") or "INFO").upper(), logging.INFO)
    root.setLevel(lvl)
    root.propagate = False
    for h in list(root.handlers):
        if getattr(h, _MARK, False):
            root.removeHandler(h)
            h.close()
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    filt = RedactSecrets()
    handlers: list[logging.Handler] = [logging.StreamHandler()]
    log_path: Path | None = Path(path or os.environ.get("VOLTIX_LOG_FILE") or DEFAULT_LOG_PATH)
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.handlers.RotatingFileHandler(log_path, maxBytes=1_000_000, backupCount=3, encoding="utf-8"))
    except OSError:
        log_path = None
    for h in handlers:
        h.setFormatter(fmt)
        h.addFilter(filt)
        setattr(h, _MARK, True)
        root.addHandler(h)
    return log_path
