"""Best-effort resource telemetry captured while a benchmark runs.

* CPU: process CPU time divided by wall time (always available, no dependencies).
* GPU: ``nvidia-smi`` streamed at a fixed interval, only when a CUDA device is in use and
  nvidia-smi exists. If it is missing or fails, the result says so instead of guessing.

Telemetry is a side observation, not a precise profiler: it samples at ~0.5 s and
nvidia-smi itself adds a little host overhead. GPU sampling has been unit-tested with
recorded output formats but NOT yet exercised against a physical GPU.
"""

from __future__ import annotations

import os
import shutil
import statistics
import subprocess
import threading
import time
from typing import Any, Optional, Sequence

GPU_QUERY_FIELDS = ["index", "utilization.gpu", "memory.used", "power.draw", "temperature.gpu", "clocks.sm"]
_FIELD_KEYS = ["index", "utilization_pct", "memory_used_mib", "power_w", "temperature_c", "sm_clock_mhz"]


def _num(token: str) -> Optional[float]:
    token = token.strip()
    if not token or token.startswith("[") or token.upper() in {"N/A", "NA", "NOT SUPPORTED"}:
        return None
    try:
        return float(token)
    except ValueError:
        return None


def parse_gpu_line(line: str) -> Optional[dict[str, Optional[float]]]:
    """Parse one csv,noheader,nounits line from the GPU query. Returns None if malformed."""
    parts = [p for p in line.strip().split(",")]
    if len(parts) != len(_FIELD_KEYS):
        return None
    values = [_num(p) for p in parts]
    if values[0] is None:  # no usable GPU index
        return None
    return dict(zip(_FIELD_KEYS, values))


def summarize_gpu_samples(samples: Sequence[dict[str, Optional[float]]]) -> dict[str, Any]:
    """Mean and max per metric; metrics the GPU never reported are left out."""
    summary: dict[str, Any] = {"samples": len(samples)}
    for key in _FIELD_KEYS[1:]:
        vals = [s[key] for s in samples if s.get(key) is not None]
        if vals:
            summary[f"{key}_mean"] = round(statistics.fmean(vals), 2)
            summary[f"{key}_max"] = round(max(vals), 2)
    return summary


def gpu_stream_command(interval_ms: int = 500) -> Optional[list[str]]:
    exe = shutil.which("nvidia-smi")
    if exe is None:
        return None
    return [exe, f"--query-gpu={','.join(GPU_QUERY_FIELDS)}", "--format=csv,noheader,nounits", "-lms", str(interval_ms)]


class ResourceSampler:
    """Context manager that records CPU utilisation and (optionally) streams GPU telemetry."""

    def __init__(self, gpu_index: Optional[int] = None, gpu_command: Optional[list[str]] = None, enable_gpu: bool = True):
        self.gpu_index = gpu_index
        self._cmd = gpu_command if gpu_command is not None else (gpu_stream_command() if (enable_gpu and gpu_index is not None) else None)
        self._wanted_gpu = enable_gpu and gpu_index is not None
        self._samples: list[dict[str, Optional[float]]] = []
        self._proc: Optional[subprocess.Popen] = None
        self._thread: Optional[threading.Thread] = None
        self._gpu_error: Optional[str] = None
        self._wall0 = self._cpu0 = 0.0
        self._wall = self._cpu = 0.0

    def __enter__(self) -> "ResourceSampler":
        if self._wanted_gpu:
            if self._cmd is None:
                self._gpu_error = "nvidia-smi not found; GPU utilisation/power/temperature not recorded."
            else:
                try:
                    self._proc = subprocess.Popen(self._cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
                    self._thread = threading.Thread(target=self._read, daemon=True)
                    self._thread.start()
                except OSError as exc:
                    self._gpu_error = f"Could not start nvidia-smi: {exc}"
        self._wall0, self._cpu0 = time.perf_counter(), time.process_time()
        return self

    def _read(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        for line in self._proc.stdout:
            row = parse_gpu_line(line)
            if row is not None and (self.gpu_index is None or int(row["index"]) == self.gpu_index):  # type: ignore[arg-type]
                self._samples.append(row)

    def __exit__(self, *exc: object) -> None:
        self._wall = time.perf_counter() - self._wall0
        self._cpu = time.process_time() - self._cpu0
        if self._proc is not None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self._proc.kill()
        if self._thread is not None:
            self._thread.join(timeout=2)

    def result(self) -> dict[str, Any]:
        cores = os.cpu_count() or 1
        busy = self._cpu / self._wall if self._wall > 0 else None
        out: dict[str, Any] = {
            "cpu": {
                "logical_cores": cores,
                "process_cpu_seconds": round(self._cpu, 3),
                "wall_seconds": round(self._wall, 3),
                "avg_busy_cores": round(busy, 2) if busy is not None else None,
                "avg_utilization_pct_of_all_cores": round(100 * busy / cores, 1) if busy is not None else None,
                "note": "This Python process only (includes all of its threads).",
            }
        }
        if self._wanted_gpu:
            if self._gpu_error:
                out["gpu"] = {"available": False, "reason": self._gpu_error}
            elif not self._samples:
                out["gpu"] = {"available": False, "reason": "nvidia-smi produced no usable samples during the run."}
            else:
                out["gpu"] = {"available": True, "sampling_interval_s": 0.5, **summarize_gpu_samples(self._samples)}
        return out
