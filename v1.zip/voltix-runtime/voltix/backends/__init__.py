"""Backend registry."""

from __future__ import annotations

from .base import BackendError, BackendNotImplemented, BackendStatus, BackendUnavailable, InferenceBackend
from .simulated import SimulatedBackend
from .transformers_backend import TransformersBackend
from .vllm_backend import VLLMBackend

BACKENDS: dict[str, type[InferenceBackend]] = {
    SimulatedBackend.key: SimulatedBackend,
    TransformersBackend.key: TransformersBackend,
    VLLMBackend.key: VLLMBackend,
}


def create_backend(key: str) -> InferenceBackend:
    """Instantiate a backend that can actually run.

    Raises BackendNotImplemented for placeholders and BackendUnavailable when the
    backend exists but its dependencies are missing on this machine.
    """
    cls = BACKENDS.get(key)
    if cls is None:
        raise KeyError(f"Unknown backend '{key}'. Known: {', '.join(BACKENDS)}")
    status = cls.status()
    if not status.implemented:
        raise BackendNotImplemented(f"Backend '{key}' is not implemented yet: {status.detail}")
    if not status.available:
        raise BackendUnavailable(f"Backend '{key}' cannot run here: {status.detail}")
    return cls()


def all_statuses() -> list[BackendStatus]:
    return [cls.status() for cls in BACKENDS.values()]


__all__ = [
    "BACKENDS",
    "BackendError",
    "BackendNotImplemented",
    "BackendStatus",
    "BackendUnavailable",
    "InferenceBackend",
    "SimulatedBackend",
    "TransformersBackend",
    "VLLMBackend",
    "all_statuses",
    "create_backend",
]
