"""vLLM backend: OPTIONAL FUTURE BACKEND (not planned before Phase 3).

Placeholder only. It never runs inference and always reports itself as
unimplemented.
"""

from __future__ import annotations

from importlib.util import find_spec
from typing import Optional

from ..schemas import BenchmarkConfig, RequestSample
from .base import BackendNotImplemented, BackendStatus, InferenceBackend


class VLLMBackend(InferenceBackend):
    key = "vllm"
    display_name = "vLLM (optional, future)"
    is_simulated = False

    @classmethod
    def status(cls) -> BackendStatus:
        found = find_spec("vllm") is not None
        return BackendStatus(
            key=cls.key,
            display_name=cls.display_name,
            implemented=False,
            available=False,
            is_simulated=False,
            detail=f"Not implemented (optional future backend). vllm package {'found' if found else 'not installed'}.",
        )

    def load(self, config: BenchmarkConfig) -> None:
        raise BackendNotImplemented("The vLLM backend is not implemented yet.")

    def run_iteration(self, config: BenchmarkConfig, index: int, warmup: bool = False) -> RequestSample:
        raise BackendNotImplemented("The vLLM backend is not implemented yet.")

    def peak_memory_gb(self) -> Optional[float]:
        return None
