"""Hugging Face Transformers backend: REAL inference with measured timings.

What is measured, and how
-------------------------
* Each iteration runs ``model.generate`` on a batch of seeded synthetic prompts
  (random token ids, no tokenizer) with greedy decoding and EXACTLY
  ``output_tokens`` new tokens (EOS is suppressed via ``min_new_tokens``).
* Latency: wall-clock from before ``generate`` to after it returns, with a CUDA
  synchronize on both sides when running on a GPU.
* TTFT: a stopping criterion is invoked after every generated token; the first
  invocation (after a CUDA synchronize) timestamps the first token. TTFT
  therefore covers prefill plus first-token sampling plus generate() setup.
* Peak memory: ``torch.cuda.max_memory_allocated`` on GPU (tensor allocator
  peak; excludes the CUDA context and allocator cache), or the process peak RSS
  on CPU (reset before loading when the OS allows it).

What is NOT done: no quantization (int8/int4 are refused), no
``trust_remote_code``, no sampling, no output-quality evaluation. The CUDA code
path has only been exercised against a fake device in unit tests, never on a real GPU.
"""

from __future__ import annotations

import gc
import os
import platform
import time
from importlib import metadata
from importlib.util import find_spec
from typing import Any, Optional

from .. import hostmem
from ..schemas import BenchmarkConfig, RequestSample
from .base import BackendError, BackendStatus, BackendUnavailable, InferenceBackend
from .devices import (
    AcceleratorProbe,
    ResolvedDevice,
    UnsupportedConfiguration,
    check_precision,
    probe_from_torch,
    resolve_device,
)

REQUIRED_PACKAGES = ("torch", "transformers")
DTYPE_KWARG_MIN_VERSION = (4, 56)  # transformers renamed torch_dtype -> dtype


def _version(name: str) -> Optional[str]:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        return None


def _version_tuple(v: Optional[str]) -> tuple[int, int]:
    try:
        parts = (v or "0.0").split(".")
        return int(parts[0]), int("".join(ch for ch in parts[1] if ch.isdigit()) or 0)
    except (ValueError, IndexError):
        return (0, 0)


def missing_dependencies() -> list[str]:
    return [p for p in REQUIRED_PACKAGES if find_spec(p) is None]


def is_oom(exc: BaseException, torch: Any) -> bool:
    cuda_oom = getattr(getattr(torch, "cuda", None), "OutOfMemoryError", None)
    if cuda_oom is not None and isinstance(exc, cuda_oom):
        return True
    return isinstance(exc, MemoryError) or "out of memory" in str(exc).lower()


# ---------------------------------------------------------------------------
# Accelerators: the only place device-specific timing/memory calls live.
# ---------------------------------------------------------------------------

INSTALL_HINT = ("Install them in the same environment that runs the app: open a terminal in the VOLTIX folder, activate the "
                "virtual environment, run `pip install -r requirements-hf.txt`, then stop and restart the app.")
_WEIGHT_SUFFIXES = (".safetensors", ".bin", ".pt", ".pth", ".gguf")


def weights_exceed_memory(model_ref: str, available_gb: Optional[float], margin: float = 0.9) -> Optional[str]:
    """Pre-flight for a LOCAL model folder: refuse when its weight files alone are larger than the free RAM.

    This is a lower bound (loading can need more than the file size, e.g. fp16 files loaded as fp32), so passing
    the check does not guarantee the model fits. Hub ids are not checked: their size is unknown offline.
    """
    if available_gb is None or not os.path.isdir(model_ref):
        return None
    total = 0
    try:
        for entry in os.scandir(model_ref):
            if entry.is_file() and entry.name.lower().endswith(_WEIGHT_SUFFIXES):
                total += entry.stat().st_size
    except OSError:
        return None
    size_gb = total / 1e9
    if size_gb > available_gb * margin:
        return (f"The model files in '{model_ref}' are {size_gb:.1f} GB but only {available_gb:.1f} GB of RAM is free. "
                "Loading would likely exhaust memory and could stop the whole app. Close other programs, or choose a smaller model.")
    return None


class CpuAccelerator:
    kind = "cpu"
    memory_kind = "process_peak_rss"

    def __init__(self) -> None:
        self.peak_is_scoped = False

    def reset_peak(self) -> None:
        self.peak_is_scoped = hostmem.reset_peak_rss()

    def sync(self) -> None:
        return None

    def peak_memory_gb(self) -> Optional[float]:
        return hostmem.peak_rss_gb()

    def total_memory_gb(self) -> Optional[float]:
        return hostmem.total_ram_gb()

    def memory_scope(self) -> str:
        return ("peak resident memory of the WHOLE process, counted from just before model loading; it still "
                "includes memory already resident then (Python, torch), see memory_above_baseline_gb"
                if self.peak_is_scoped else
                "peak resident memory of the whole process over its entire lifetime (the counter could not be reset)")


class CudaAccelerator:
    kind = "cuda"
    memory_kind = "cuda_max_memory_allocated"

    def __init__(self, torch: Any, index: int) -> None:
        self._torch, self.index = torch, index

    def reset_peak(self) -> None:
        self._torch.cuda.reset_peak_memory_stats(self.index)

    def sync(self) -> None:
        self._torch.cuda.synchronize(self.index)

    def peak_memory_gb(self) -> Optional[float]:
        return self._torch.cuda.max_memory_allocated(self.index) / 1e9

    def total_memory_gb(self) -> Optional[float]:
        return self._torch.cuda.get_device_properties(self.index).total_memory / 1e9

    def memory_scope(self) -> str:
        return "peak bytes held by PyTorch tensors since just before model loading (excludes CUDA context and cache)"


def make_accelerator(torch: Any, device: ResolvedDevice):
    return CudaAccelerator(torch, int(device.index or 0)) if device.kind == "cuda" else CpuAccelerator()


# ---------------------------------------------------------------------------
# Backend
# ---------------------------------------------------------------------------

class TransformersBackend(InferenceBackend):
    key = "transformers"
    display_name = "Hugging Face Transformers"
    is_simulated = False

    def __init__(self) -> None:
        self._torch: Any = None
        self._transformers: Any = None
        self._model: Any = None
        self._accel: Any = None
        self._device: Optional[ResolvedDevice] = None
        self._timer_cls: Any = None
        self._input_ids: Any = None
        self._attention_mask: Any = None
        self._pad_token_id: int = 0
        self._env: dict[str, Any] = {}

    # ---- readiness ---------------------------------------------------------

    @classmethod
    def status(cls) -> BackendStatus:
        missing = missing_dependencies()
        if missing:
            return BackendStatus(
                key=cls.key, display_name=cls.display_name, implemented=True, available=False, is_simulated=False,
                detail=f"Missing dependencies: {', '.join(missing)}. {INSTALL_HINT}")
        detail = (f"torch {_version('torch')}, transformers {_version('transformers')}. "
                  "Runs on CPU or CUDA GPU (fp32/fp16/bf16). Output is MEASURED on this machine.")
        return BackendStatus(cls.key, cls.display_name, implemented=True, available=True, is_simulated=False, detail=detail)

    @classmethod
    def preflight(cls, config: BenchmarkConfig, probe: AcceleratorProbe) -> list[str]:
        """Cheap hardware/precision checks (no model loading). Returns problems found."""
        try:
            device = resolve_device(config.hardware_id, probe)
            check_precision(config.precision, device)
        except BackendError as exc:
            return [str(exc)]
        return []

    # ---- lifecycle ---------------------------------------------------------

    def _import_stack(self) -> None:
        missing = missing_dependencies()
        if missing:
            raise BackendUnavailable(f"Missing dependencies: {', '.join(missing)}. {INSTALL_HINT}")
        try:
            import torch
            import transformers
        except Exception as exc:  # noqa: BLE001 - broken installs raise many error types
            raise BackendUnavailable(f"torch/transformers are installed but failed to import: {type(exc).__name__}: {exc}") from exc
        self._torch, self._transformers = torch, transformers

    def load(self, config: BenchmarkConfig) -> None:
        self._import_stack()
        torch, tf = self._torch, self._transformers
        probe = probe_from_torch(torch)
        # Recorded BEFORE any device/precision check, so a run rejected for unsupported hardware
        # still documents what this machine actually has.
        self._env = self._base_environment(config, probe)
        self._device = resolve_device(config.hardware_id, probe)
        dtype_name = check_precision(config.precision, self._device)
        self._accel = make_accelerator(torch, self._device)
        self._accel.reset_peak()
        rss_before = hostmem.current_rss_gb()

        if self._device.kind == "cpu":
            problem = weights_exceed_memory(config.model_id, hostmem.available_ram_gb())
            if problem:
                self.unload()
                raise BackendError(problem)

        dtype_key = "dtype" if _version_tuple(getattr(tf, "__version__", None)) >= DTYPE_KWARG_MIN_VERSION else "torch_dtype"
        kwargs = {dtype_key: getattr(torch, dtype_name), "local_files_only": not config.allow_download,
                  "trust_remote_code": False}
        if config.revision and not os.path.isdir(config.model_id):
            kwargs["revision"] = config.revision  # pins the exact Hub weights; meaningless for a local folder
        started = time.perf_counter()
        try:
            model = tf.AutoModelForCausalLM.from_pretrained(config.model_id, **kwargs)
            model.eval()
            model.to(self._torch.device(self._device.hardware_id))
        except Exception as exc:  # noqa: BLE001 - translated into an honest, specific message
            self.unload()
            raise BackendError(self._explain_load_error(exc, config)) from exc
        load_s = time.perf_counter() - started
        self._model = model

        max_ctx = getattr(model.config, "max_position_embeddings", None)
        need = config.prompt_tokens + config.output_tokens
        if isinstance(max_ctx, int) and need > max_ctx:
            self.unload()
            raise BackendError(f"Prompt + output tokens ({need:,}) exceed this model's context window ({max_ctx:,}).")

        self._build_inputs(config)
        self._timer_cls = self._make_timer_class()
        self._record_environment(config, load_s, rss_before)

    def _explain_load_error(self, exc: BaseException, config: BenchmarkConfig) -> str:
        if is_oom(exc, self._torch):
            where = "GPU" if self._device and self._device.kind == "cuda" else "host"
            return (f"Out of {where} memory while loading '{config.model_id}' as {config.precision.value}. "
                    "Use a smaller model, a lower precision, or a device with more memory.")
        if isinstance(exc, ImportError):
            return f"Loading '{config.model_id}' needs an optional dependency that is not installed: {exc}"
        if isinstance(exc, OSError) and not config.allow_download and not os.path.isdir(config.model_id):
            return (f"'{config.model_id}' is not in the local Hugging Face cache and downloading is turned off. "
                    "Tick 'Allow downloading from the Hugging Face Hub' to fetch it (needs internet), or point to a local model folder.")
        if isinstance(exc, OSError):
            hint = ("" if config.allow_download else
                    " Downloading is disabled; tick 'Allow downloading from the Hugging Face Hub' or point to a local folder.")
            return f"Could not load model '{config.model_id}': {str(exc).strip()[:300]}.{hint}"
        return f"Could not load model '{config.model_id}' ({type(exc).__name__}): {str(exc).strip()[:300]}"

    def _build_inputs(self, config: BenchmarkConfig) -> None:
        torch, model = self._torch, self._model
        vocab = int(model.get_input_embeddings().num_embeddings)
        gc_cfg, cfg = model.generation_config, model.config
        specials = {int(t) for src in (gc_cfg, cfg) for name in ("bos_token_id", "eos_token_id", "pad_token_id")
                    for t in ([getattr(src, name, None)] if not isinstance(getattr(src, name, None), (list, tuple))
                              else getattr(src, name)) if t is not None}
        safe = next((i for i in range(vocab) if i not in specials), 0)
        gen = torch.Generator().manual_seed(int(config.seed))
        ids = torch.randint(0, vocab, (config.batch_size, config.prompt_tokens), generator=gen)
        if specials:
            ids = torch.where(torch.isin(ids, torch.tensor(sorted(specials))), torch.full_like(ids, safe), ids)
        dev = torch.device(self._device.hardware_id)  # type: ignore[union-attr]
        self._input_ids = ids.to(dev)
        self._attention_mask = torch.ones_like(self._input_ids)
        eos = gc_cfg.eos_token_id
        eos = eos[0] if isinstance(eos, (list, tuple)) and eos else eos
        self._pad_token_id = int(gc_cfg.pad_token_id if gc_cfg.pad_token_id is not None else (eos if eos is not None else 0))
        torch.manual_seed(int(config.seed))

    def _make_timer_class(self) -> Any:
        torch, accel, backend = self._torch, self._accel, self

        class FirstTokenTimer(self._transformers.StoppingCriteria):  # type: ignore[misc, name-defined]
            """Timestamps the first generated token. It never ends generation normally; it only raises
            ``RunAborted`` (through the abort check) when the run is cancelled or over its time limit."""

            def __init__(self) -> None:
                self.first: Optional[float] = None

            def __call__(self, input_ids, scores, **kwargs):  # noqa: ANN001
                if self.first is None:
                    accel.sync()
                    self.first = time.perf_counter()
                check = backend._abort_check
                if check is not None:
                    check()  # a function call and two comparisons per generated token; no device synchronisation
                return torch.zeros(input_ids.shape[0], dtype=torch.bool, device=input_ids.device)

        return FirstTokenTimer

    # ---- measurement -------------------------------------------------------

    def run_iteration(self, config: BenchmarkConfig, index: int, warmup: bool = False) -> RequestSample:
        if self._model is None:
            raise BackendError("Backend not loaded; call load() first.")
        torch, tf = self._torch, self._transformers
        timer = self._timer_cls()
        n = config.output_tokens
        try:
            self._accel.sync()
            t0 = time.perf_counter()
            with torch.inference_mode():
                out = self._model.generate(
                    input_ids=self._input_ids, attention_mask=self._attention_mask,
                    max_new_tokens=n, min_new_tokens=n, do_sample=False,
                    pad_token_id=self._pad_token_id, use_cache=True,
                    stopping_criteria=tf.StoppingCriteriaList([timer]))
            self._accel.sync()
            t1 = time.perf_counter()
        except BackendError:
            raise  # includes RunAborted: cancel/timeout is not a generation failure
        except Exception as exc:  # noqa: BLE001
            if is_oom(exc, torch):
                raise BackendError(
                    f"Out of memory during generation (batch {config.batch_size}, {config.prompt_tokens} prompt + "
                    f"{n} output tokens). Reduce batch size or sequence length.") from exc
            raise BackendError(f"Generation failed ({type(exc).__name__}): {str(exc).strip()[:300]}") from exc

        generated = int(out.shape[1] - self._input_ids.shape[1])
        if generated != n:
            raise BackendError(f"Model generated {generated} tokens per sequence instead of the requested {n}; "
                               "the measurement would be invalid.")
        if timer.first is None:
            raise BackendError("Could not observe the first generated token; TTFT cannot be measured.")
        latency_ms = (t1 - t0) * 1000.0
        ttft_ms = min((timer.first - t0) * 1000.0, latency_ms)
        return RequestSample(index=index, ttft_ms=ttft_ms, latency_ms=latency_ms,
                             batch_size=config.batch_size, output_tokens_per_seq=generated)

    def peak_memory_gb(self) -> Optional[float]:
        return self._accel.peak_memory_gb() if self._accel else None

    def device_memory_gb(self) -> Optional[float]:
        return self._accel.total_memory_gb() if self._accel else None

    def resolved_hardware_id(self) -> Optional[str]:
        return self._device.hardware_id if self._device else None

    # ---- environment record ------------------------------------------------

    def _base_environment(self, config: BenchmarkConfig, probe: AcceleratorProbe) -> dict[str, Any]:
        """Facts known before any model is loaded: software, host and every accelerator torch can see."""
        torch = self._torch
        return {
            "backend": self.key,
            "simulated": False,
            "requested_hardware_id": config.hardware_id or "auto",
            "software": {"python": platform.python_version(), "torch": getattr(torch, "__version__", None),
                         "torch_cuda_build": getattr(getattr(torch, "version", None), "cuda", None),
                         "transformers": getattr(self._transformers, "__version__", None),
                         "os": f"{platform.system()} {platform.release()}"},
            "host": {"cpu_model": hostmem.cpu_model_name(), "cpu_count": os.cpu_count(),
                     "ram_gb": hostmem.total_ram_gb(), "torch_threads": torch.get_num_threads()},
            "accelerators": probe.to_dict(),
        }

    def _record_environment(self, config: BenchmarkConfig, load_s: float, rss_before: Optional[float]) -> None:
        torch, model, dev = self._torch, self._model, self._device
        first_param = next(model.parameters(), None)
        device_info: dict[str, Any] = {"kind": dev.kind, "name": dev.name if dev.kind == "cuda" else hostmem.cpu_model_name(),
                                       "hardware_id": dev.hardware_id, "total_memory_gb": self._accel.total_memory_gb()}
        if dev.kind == "cuda":
            device_info["compute_capability"] = f"{dev.capability[0]}.{dev.capability[1]}" if dev.capability else None
            device_info["driver"] = _nvidia_driver(dev.index or 0)
        self._env = {
            **self._env,  # base: backend, software, host, accelerators
            "device_kind": dev.kind,
            "device": device_info,
            "model": {"id": config.model_id, "class": type(model).__name__,
                      "num_parameters": sum(p.numel() for p in model.parameters()),
                      "parameter_dtype": str(first_param.dtype).replace("torch.", "") if first_param is not None else None,
                      "max_position_embeddings": getattr(model.config, "max_position_embeddings", None),
                      "requested_revision": config.revision if not os.path.isdir(config.model_id) else None,
                      "commit_hash": getattr(model.config, "_commit_hash", None),
                      "load_time_s": round(load_s, 3), "downloads_allowed": config.allow_download, "trust_remote_code": False},
            "measurement": {
                "prompt": "synthetic random token ids (seeded); no tokenizer, no real text",
                "decoding": "greedy; exactly the requested number of new tokens (EOS suppressed)",
                "latency": "wall clock around generate()" + (" with CUDA synchronize before and after" if dev.kind == "cuda" else ""),
                "ttft": "time until the first generated token exists (prefill + first decode step + generate setup)",
                "memory_kind": self._accel.memory_kind,
                "memory_scope": self._accel.memory_scope(),
                "memory_unit": "GB = 10^9 bytes",
            },
            "rss_before_load_gb": rss_before,
        }

    def environment(self) -> dict[str, Any]:
        env = dict(self._env)
        if env and env.get("device_kind") == "cpu" and self._accel is not None:
            peak, base = self._accel.peak_memory_gb(), env.get("rss_before_load_gb")
            if peak is not None and base is not None:
                env["measurement"] = {**env["measurement"], "memory_above_baseline_gb": round(max(peak - base, 0.0), 3)}
        return env

    def unload(self) -> None:
        self._model = None
        self._input_ids = self._attention_mask = None
        gc.collect()
        torch = self._torch
        if torch is not None and self._device is not None and self._device.kind == "cuda":
            try:
                torch.cuda.empty_cache()
            except Exception:  # noqa: BLE001 - cleanup must never mask the real result
                pass


def _nvidia_driver(index: int) -> Optional[str]:
    try:
        from ..sysinfo import detect_gpus

        gpus = detect_gpus().get("gpus", [])
        return gpus[index]["driver"] if index < len(gpus) else None
    except Exception:  # noqa: BLE001
        return None
