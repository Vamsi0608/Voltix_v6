"""Inference backend interface.

A backend knows how to load a model for a ``BenchmarkConfig`` and execute one
timed iteration (a batch of sequences generated together). The runner owns
warmup, iteration counting, aggregation and persistence, so a real backend only
has to implement the four methods below and report honest timings.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable, ClassVar, Optional

from ..schemas import BenchmarkConfig, RequestSample


class BackendError(RuntimeError):
    """A recoverable backend failure (e.g. out of memory). Recorded as a failed run."""


class BackendNotImplemented(NotImplementedError):
    """The backend exists in the architecture but has no working implementation yet."""


class BackendUnavailable(RuntimeError):
    """The backend is implemented but cannot run here (e.g. torch/transformers not installed).

    Deliberately NOT a BackendError: nothing was measured, so no run is recorded.
    """


@dataclass(frozen=True)
class BackendStatus:
    key: str
    display_name: str
    implemented: bool  # does a working implementation exist in this build?
    available: bool  # can it run right now (implemented AND dependencies present)?
    is_simulated: bool
    detail: str


class InferenceBackend(ABC):
    key: ClassVar[str]
    display_name: ClassVar[str]
    is_simulated: ClassVar[bool]
    _abort_check: Optional[Callable[[], None]] = None

    def set_abort_check(self, check: Optional[Callable[[], None]]) -> None:
        """Install a function that raises ``RunAborted`` when the run must stop. Real backends call it at
        fine-grained safe points (for example after every generated token)."""
        self._abort_check = check

    @classmethod
    @abstractmethod
    def status(cls) -> BackendStatus:
        """Report whether this backend can run in the current environment."""

    @abstractmethod
    def load(self, config: BenchmarkConfig) -> None:
        """Prepare the model. Raise BackendError for recoverable failures."""

    @abstractmethod
    def run_iteration(self, config: BenchmarkConfig, index: int, warmup: bool = False) -> RequestSample:
        """Execute one batch. ``index`` counts within warmup or measured phase."""

    @abstractmethod
    def peak_memory_gb(self) -> Optional[float]:
        """Peak accelerator memory observed or estimated, if known."""

    def device_memory_gb(self) -> Optional[float]:
        return None

    def resolved_hardware_id(self) -> Optional[str]:
        """The concrete device actually used (e.g. "cuda:0"), once known."""
        return None

    def environment(self) -> dict[str, Any]:
        return {}

    def unload(self) -> None:  # pragma: no cover - default is a no-op
        return None
