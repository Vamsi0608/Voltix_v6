"""Device discovery, selection and precision support (pure logic, no GPU needed to test).

``probe_from_torch`` reads a torch-like module; tests pass fakes. Nothing here
claims a device works beyond what torch itself reports.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from importlib.util import find_spec
from typing import Any, Optional

from ..schemas import Precision
from .base import BackendError


class UnsupportedConfiguration(BackendError):
    """The requested precision/device combination is not supported here."""


class DeviceUnavailable(BackendError):
    """The requested device does not exist on this machine."""


SUPPORTED_PRECISIONS: tuple[Precision, ...] = (Precision.FP32, Precision.FP16, Precision.BF16)
_DTYPE_NAME = {Precision.FP32: "float32", Precision.FP16: "float16", Precision.BF16: "bfloat16"}
_DEVICE_RE = re.compile(r"^(auto|cpu|cuda(?::(\d+))?)$")


@dataclass(frozen=True)
class CudaDevice:
    index: int
    name: str
    total_memory_bytes: int
    capability: tuple[int, int]

    @property
    def total_gb(self) -> float:
        return self.total_memory_bytes / 1e9

    @property
    def bf16_supported(self) -> bool:
        return self.capability[0] >= 8  # Ampere or newer

    def to_dict(self) -> dict[str, Any]:
        return {"index": self.index, "name": self.name, "total_memory_gb": round(self.total_gb, 2),
                "compute_capability": f"{self.capability[0]}.{self.capability[1]}", "bf16_native": self.bf16_supported}


@dataclass(frozen=True)
class AcceleratorProbe:
    torch_installed: bool
    torch_version: Optional[str] = None
    cuda_build: Optional[str] = None  # CUDA version torch was built against (may be set on CPU-only machines)
    cuda_available: bool = False
    devices: tuple[CudaDevice, ...] = ()
    error: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {"torch_installed": self.torch_installed, "torch_version": self.torch_version,
                "cuda_build": self.cuda_build, "cuda_available": self.cuda_available,
                "devices": [d.to_dict() for d in self.devices], "error": self.error}


@dataclass(frozen=True)
class ResolvedDevice:
    kind: str  # "cpu" | "cuda"
    index: Optional[int] = None
    name: str = "CPU"
    total_memory_gb: Optional[float] = None
    capability: Optional[tuple[int, int]] = None

    @property
    def hardware_id(self) -> str:
        return "cpu" if self.kind == "cpu" else f"cuda:{self.index}"

    @property
    def bf16_native(self) -> bool:
        return self.kind == "cuda" and self.capability is not None and self.capability[0] >= 8


def probe_from_torch(torch: Any) -> AcceleratorProbe:
    """Describe accelerators using a torch-like module."""
    version = getattr(torch, "__version__", None)
    cuda_build = getattr(getattr(torch, "version", None), "cuda", None)
    try:
        available = bool(torch.cuda.is_available())
        devices: list[CudaDevice] = []
        if available:
            for i in range(int(torch.cuda.device_count())):
                props = torch.cuda.get_device_properties(i)
                devices.append(CudaDevice(i, str(props.name), int(props.total_memory), (int(props.major), int(props.minor))))
        return AcceleratorProbe(True, version, cuda_build, available and bool(devices), tuple(devices))
    except Exception as exc:  # noqa: BLE001 - a broken driver must not crash the UI
        return AcceleratorProbe(True, version, cuda_build, False, (), error=f"CUDA probe failed: {type(exc).__name__}: {exc}")


def probe_accelerators() -> AcceleratorProbe:
    """Import torch (slow the first time) and probe it. Never raises."""
    if find_spec("torch") is None:
        return AcceleratorProbe(False, error="torch is not installed")
    try:
        import torch
    except Exception as exc:  # noqa: BLE001 - broken installs raise many error types
        return AcceleratorProbe(True, error=f"torch is installed but failed to import: {type(exc).__name__}: {exc}")
    return probe_from_torch(torch)


def is_valid_device_request(request: Optional[str]) -> bool:
    return request is None or bool(_DEVICE_RE.match(request))


def resolve_device(request: Optional[str], probe: AcceleratorProbe) -> ResolvedDevice:
    """Turn "auto" / "cpu" / "cuda[:N]" into a concrete device or raise honestly."""
    req = (request or "auto").strip().lower()
    m = _DEVICE_RE.match(req)
    if not m:
        raise DeviceUnavailable(f"Unrecognised device '{request}'. Use auto, cpu, cuda or cuda:N.")
    if req == "cpu":
        return ResolvedDevice("cpu")
    if req == "auto":
        if probe.cuda_available and probe.devices:
            d = probe.devices[0]
            return ResolvedDevice("cuda", d.index, d.name, d.total_gb, d.capability)
        return ResolvedDevice("cpu")
    index = int(m.group(2)) if m.group(2) is not None else 0
    if not probe.cuda_available:
        why = probe.error or (
            "torch was built without CUDA support" if not probe.cuda_build else
            f"torch (CUDA {probe.cuda_build} build) reports no usable GPU or driver")
        raise DeviceUnavailable(f"CUDA device requested but none is available: {why}. Choose cpu or auto.")
    match = next((d for d in probe.devices if d.index == index), None)
    if match is None:
        listing = ", ".join(f"cuda:{d.index} ({d.name})" for d in probe.devices)
        raise DeviceUnavailable(f"cuda:{index} does not exist. Available: {listing}.")
    return ResolvedDevice("cuda", match.index, match.name, match.total_gb, match.capability)


def check_precision(precision: Precision, device: ResolvedDevice) -> str:
    """Return the torch dtype name for this precision on this device, or raise."""
    if precision not in SUPPORTED_PRECISIONS:
        raise UnsupportedConfiguration(
            f"Precision {precision.value} is not supported by the Transformers backend in this build "
            "(int8/int4 quantization needs bitsandbytes and is not implemented). Use fp32, fp16 or bf16.")
    if precision == Precision.FP16 and device.kind == "cpu":
        raise UnsupportedConfiguration(
            "fp16 is not supported on CPU by this backend (PyTorch's CPU fp16 support differs between versions "
            "and CPUs, so timings would not be comparable or representative). "
            "Use fp32 or bf16 on CPU, or run on a CUDA GPU.")
    if precision == Precision.BF16 and device.kind == "cuda" and not device.bf16_native:
        cap = f"{device.capability[0]}.{device.capability[1]}" if device.capability else "unknown"
        raise UnsupportedConfiguration(
            f"bf16 needs a GPU with compute capability 8.0 or newer; {device.name} is {cap}. Use fp16 or fp32.")
    return _DTYPE_NAME[precision]
