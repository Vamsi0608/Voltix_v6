"""Run the VOLTIX validation matrix on THIS machine and write MATRIX_RESULTS.md (rows needing absent hardware are NOT RUN).

    python run_matrix.py [--out MATRIX_RESULTS.md]
"""
from __future__ import annotations

import argparse
import platform
import sys
from pathlib import Path

from voltix.matrix import default_rows, run_matrix, to_markdown


def _hub_cached(model: str) -> bool:
    try:
        from huggingface_hub import try_to_load_from_cache
        return isinstance(try_to_load_from_cache(model, "config.json"), str)
    except Exception:  # noqa: BLE001
        return False


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="MATRIX_RESULTS.md")
    a = ap.parse_args(argv)
    tiny = None
    try:
        from voltix.testmodel import create_tiny_model
        tiny = str(create_tiny_model())
    except Exception as exc:  # noqa: BLE001
        print(f"tiny model unavailable: {exc}")
    res = run_matrix(default_rows(), tiny, _hub_cached, progress=lambda s: print(s, flush=True))
    try:
        import torch
        gpu = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "no GPU"
        tv = torch.__version__
    except Exception:  # noqa: BLE001
        gpu, tv = "torch unavailable", "n/a"
    machine = f"{platform.platform()}, Python {platform.python_version()}, torch {tv}, {gpu}"
    Path(a.out).write_text(to_markdown(res, machine), encoding="utf-8")
    print(f"written {a.out}")
    return 1 if any(r.outcome == "FAIL" for r in res) else 0


if __name__ == "__main__":
    sys.exit(main())
